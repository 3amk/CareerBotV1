import swaggerJSDoc from "swagger-jsdoc";

// swagger js doc options and intialization
const options = {
  definition: {
    openapi: "3.0.0",
    info: {
      title: "3AMK AI",
      version: "1.0.0",
      description: `This is a documentaiton of internal REST API for 3AMK AI.
          Please note that all paths are relative to server URLs defined below thats \`domain/api/v1/\`.
          Most of the endpoints or paths require authentication to access, so you must fill the JWT token using **Authorize** button.
          You can also use cURL or other tools and libraries that support HTTP protocol to test the API`,
    },
    basePath: "/",
    components: {
      securitySchemes: {
        bearerToken: {
          type: "http",
          scheme: "bearer",
          bearerFormat: "JWT",
        },
      },
    },
    tags: [{ name: "auth" }, { name: "profile" }, { name: "map" }],
    servers: [
      {
        url: "http://localhost:3000/api/v1",
        description: "Development server",
      },
      {
        url: "https://dev-3amk-ai.rahtiapp.fi/api/v1",
        description: "Deployment server",
      },
    ],
  },
  // Paths to files containing OpenAPI definitions
  apis: ["./routes/*.mjs"],
};
const swaggerSpec = swaggerJSDoc(options);
export default swaggerSpec;

/* eslint-disable no-console */
import dotenv from "dotenv";
import app from "./app.mjs";
import { sequelize } from "./models/index.mjs";

dotenv.config();

sequelize
  .sync()
  .then(() => {
    console.log("Postgre Database is connected!");
  })
  .catch((error) => {
    console.log("error connecting  postgre database", error);
  });

const IP = process.env.IP || "0.0.0.0";
const PORT = process.env.LOCAL_PORT || 8080;

app.listen(PORT, IP, () => {
  console.log(`\nServer running on address ${IP}:${PORT}`);
});

import dotenv from "dotenv";
import express from "express";
import path from "path";
import helmet from "helmet";
import cookieParser from "cookie-parser";

// Note: SwaggerUI is only used to generate API documentation from comments,
// it does not have anything to do with functionality of this application.
import swaggerUi from "swagger-ui-express";
import swaggerSpec from "./swagger.mjs";

// new routes, old routes will be deleted once everything is refactored
import authRouter from "./routes/auth_routes.mjs";
import profileRouter from "./routes/profile_routes.mjs";
import MapRouter from "./routes/map_routes.mjs";
import degreeProgramSuggestionRouter from "./routes/degree_program_suggestion_routes.mjs";
import educationListRouter from "./routes/education_list_routes.mjs";
import skillToEducationRouter from "./routes/skill_to_education_routes.mjs";
import searchCoursesByTextRouter from "./routes/search_courses_by_text_routes.mjs";
import searchCoursesRouter from "./routes/search_courses_routes.mjs";
import semanticSuggestionRouter from "./routes/semantic_suggestion_routes.mjs";
import requestJobsByKeywordsRouter from "./routes/request_jobs_by_keywords_routes.mjs";
import searchRelatedThesisRouter from "./routes/search_related_thesis_routes.mjs";
import searchRelatedArticleRouter from "./routes/search_related_article_routes.mjs";
import getThesisWordStatisticGlobalRouter from "./routes/get_thesis_word_statistic_global_routes.mjs";
import wordCompleteRouter from "./routes/word_complete_routes.mjs";
import getThesisWordStatisticRouter from "./routes/get_thesis_word_statistic_routes.mjs";
import documentToTextRouter from "./routes/document_to_text.mjs";
import exampleMapRouter from "./routes/example_map_routes.mjs";

// config env
dotenv.config();

// on Nodejs modules(es6) __dirname and _filename variables do not exist
global.__dirname = path.resolve(path.dirname(""));

/*
 * init express and pass neccessary middlewares and set static dir
 * NOTE: the cache-control for the static files is set to 1 year here to use aggresive caching,
 * this is absolutely okay, after CRA build all files in build/static folder will have a unique hash appended to the filename, so that
 * the files get updated only when they change
 */
const app = express()
  .use(cookieParser())
  .use(express.json())
  .use(express.urlencoded({ extended: true }))
  .use(
    express.static(path.join(__dirname, "../app/build"), {
      maxAge: 31536000,
    })
  )
  .use(
    helmet({
      contentSecurityPolicy: {
        useDefaults: true,
        directives: {
          "connect-src": [
            "'self'",
            "https://3amkapi.headai.com/microcompetencies",
          ],
        },
      },
    })
  );

// api routes
app
  .use("/api/v1/auth", authRouter)
  .use("/api/v1/profile", profileRouter)
  .use("/api/v1/map", MapRouter)
  .use("/api/v1/degree_program_suggestion", degreeProgramSuggestionRouter)
  .use("/api/v1/education_list", educationListRouter)
  .use("/api/v1/skill_to_education", skillToEducationRouter)
  .use("/api/v1/search_courses_by_text", searchCoursesByTextRouter)
  .use("/api/v1/search_courses", searchCoursesRouter)
  .use("/api/v1/semantic_suggestion", semanticSuggestionRouter)
  .use("/api/v1/request_jobs_by_keywords", requestJobsByKeywordsRouter)
  .use("/api/v1/search_related_thesis", searchRelatedThesisRouter)
  .use("/api/v1/search_related_article", searchRelatedArticleRouter)
  .use("/api/v1/word_complete", wordCompleteRouter)
  .use("/api/v1/get_thesis_word_statistic", getThesisWordStatisticRouter)
  .use("/api/v1/get_thesis_word_statistic_global", getThesisWordStatisticGlobalRouter)
  .use("/api/v1/document_to_text", documentToTextRouter)
  .use("/api/v1/example_maps", exampleMapRouter)

// add documentaion route
app.use("/internal/docs/api/v1", swaggerUi.serve, swaggerUi.setup(swaggerSpec));

// set views path and view engine, only used for LinkedIn login
// TODO: add error view file
app.set("views", path.join(__dirname, "./views/")).set("view engine", "ejs");

// return static file for any other route
app.get("*", (_, res) => {
  try {
    res.sendFile(path.join(__dirname, "../app/build", "index.html"));
  } catch (error) {
    res.send("Server Error!");
  }
});

// handle unknown end points, highly unlikely this will be reached since all unkown endpoints and 404 pages are served/handled from static folder
app.use((_, res) => res.status(404).send({ error: "unknown endpoint" }));

export default app;

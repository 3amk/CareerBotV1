/* This routes will handle user skill profiles, profile data
 */

/**
 * @openapi
 * components:
 *  schemas:
 *    Profile:
 *      title: Profile
 *      description: single item in list of skill profiles
 *      type: object
 *      properties:
 *        id:
 *          type: integer
 *          description: The id of the profile
 *          example: 234
 *        exclude_skills:
 *          type: string
 *          description: List of execluded skill names seprated by comma
 *          example: java, data, management
 *        include_skills:
 *          type: string
 *          description: List of included skill names seprated by commad
 *          example: java, data, management
 *        name:
 *          type: string
 *          description: Name of the profile
 *          example: profile_name
 *        text:
 *          type: string
 *          description: A text value of submitted CV
 *          example: CV text
 *        time:
 *          type: time
 *          description: time of profile creating
 *          example: 2021-03-09 17:52:01.0
 *    ProfileData:
 *      title: ProfileData
 *      description: Data of single skill profile, Note that this does not include all properties, refer to response
 *      type: object
 *      properties:
 *        owner:
 *          type: integer
 *          description: The id of the owner
 *          example: 234
 *          courses:
 *              type: array
 *              description: List of courses added to the profile as completed by course id
 *              example: [563453, 432423]
 *        exclude_skills:
 *          type: array
 *          description: List of execluded skill names as array
 *          example: [java, data, management]
 *        include_skills:
 *          type: array
 *          description: List of included skill names as array
 *          example: [java, data, management]
 *        name:
 *          type: string
 *          description: Name of the profile
 *          example: profile_name
 *        text:
 *          type: string
 *          description: A text value of submitted CV
 *          example: CV text
 *        koski_text:
 *          type: string
 *          description: A text value of submitted Koski data
 *          example: Koski text
 *
 */

 import Router from "express";
 import searchRelatedArticleController from "../controllers/search_related_article_controller.mjs";
 //import AuthController from "../controllers/auth_controller.mjs";
 
 const router = Router();
 
 /**
  *  @openapi
  *  /profile/:
  *  post:
  *      tags:
  *      - profile
  *      security:
  *          bearerToken: []
  *      summary: Create new skill profile
  *      description: This is used to create new skill profile, must be authorized and pass new profile name
  *      requestBody:
  *          required: true
  *          content:
  *              application/json:
  *                  schema:
  *                      type: object
  *                      properties:
  *                          profileName:
  *                              type: string
  *                              description: Name of the new skill profile
  *                              example: profile_name
  *      responses:
  *          201:
  *              description: This will return success message upon successful request
  *              content:
  *                  application/json:
  *                      schema:
  *                        type: object
  *                        properties:
  *                          message:
  *                            type: string
  *                            description: message dscriping status of operation
  *                            example: success
  *          400:
  *              description: Internal server error
  *              content:
  *                  application/json:
  *                      schema:
  *                          $ref: '#/components/schemas/Error'
  */
 
 /**
  *  @openapi
  *  /profile/:
  *  get:
  *      tags:
  *      - profile
  *      security:
  *          bearerToken: []
  *      summary: Get list of user skill profiles
  *      description: This returns a list of skill profiles of currently authenticated user
  *      responses:
  *          200:
  *              description: success reponse for get list of skill profiles
  *              content:
  *                  application/json:
  *                      schema:
  *                        type: object
  *                        properties:
  *                          data:
  *                            type: array
  *                            items:
  *                              $ref: '#/components/schemas/Profile'
  *          400:
  *              description: Bad request maliformed request body
  *              content:
  *                  application/json:
  *                      schema:
  *                          $ref: '#/components/schemas/Error'
  */
 router.get(
   "/",
   //AuthController.authenticateUser,
   searchRelatedArticleController.getSearchRelatedArticle
 );
 
 /**
  *  @openapi
  *  /profile/{profileName}:
  *  get:
  *      tags:
  *      - profile
  *      security:
  *          bearerToken: []
  *      summary: Get a single skill profile data
  *      description: This returns skill prfile data of the supplied profileName
  *      parameters:
  *      - in: path
  *        name: profileName
  *        required: true
  *        description: Name of the skill profile requested.
  *        schema:
  *          type: string
  *      responses:
  *          200:
  *              description: success reponse for get skill profile data
  *              content:
  *                  application/json:
  *                      schema:
  *                        type: object
  *                        properties:
  *                          data:
  *                            type: array
  *                            items:
  *                              $ref: '#/components/schemas/ProfileData'
  *          400:
  *              description: Bad request maliformed request body
  *              content:
  *                  application/json:
  *                      schema:
  *                          $ref: '#/components/schemas/Error'
  */

 
 /**
  *  @openapi
  *  /profile/:
  *  put:
  *      tags:
  *      - profile
  *      security:
  *          bearerToken: []
  *      summary: Update skill profile data
  *      description: Update details of skill profile data
  *      requestBody:
  *          required: true
  *          content:
  *              application/json:
  *                  schema:
  *                      $ref: '#/components/schemas/ProfileData'
  *      responses:
  *          200:
  *              description: Will return skill profile data with updated data
  *              content:
  *                  application/json:
  *                      schema:
  *                          $ref: '#/components/schemas/ProfileData'
  *          400:
  *              description: Bad request maliformed request body
  *              content:
  *                  application/json:
  *                      schema:
  *                          $ref: '#/components/schemas/Error'
  */

 /**
  *  @openapi
  *  /profile/{profileName}:
  *  delete:
  *      tags:
  *      - profile
  *      security:
  *          bearerToken: []
  *      summary: Delete a single skill profile
  *      description: This will deleted the skill profile with the supplied skill profile name
  *      parameters:
  *      - in: path
  *        name: profileName
  *        required: true
  *        description: Name of the skill profile to be deleted.
  *        schema:
  *          type: string
  *      responses:
  *          200:
  *              description: success reponse for delete skill profile
  *              content:
  *                  application/json:
  *                      schema:
  *                        type: object
  *                        properties:
  *                          message:
  *                            type: string
  *                            description: message dscriping status of operation
  *                            example: deleted successfuly
  *          400:
  *              description: Bad request maliformed request body
  *              content:
  *                  application/json:
  *                      schema:
  *                          $ref: '#/components/schemas/Error'
  */

 
 export default router;
 
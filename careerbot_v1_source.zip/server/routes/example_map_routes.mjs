import Router from "express";
import ExampleMapController from "../controllers/example_map_controller.mjs";

const router = Router();

router.get("/refresh", ExampleMapController.refreshExampleMaps);

export default router;

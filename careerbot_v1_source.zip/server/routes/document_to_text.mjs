/* This routes will handle Document Parsing to Plain Text
 */

 import Router from "express";
 import documentToTextController from "../controllers/document_to_text_controller.mjs";
 import AuthController from "../controllers/auth_controller.mjs";
 
 const router = Router();

 import multer from 'multer';
 const upload = multer({ storage: multer.memoryStorage() })


 router.post(
   "/",
   //AuthController.authenticateUser,
   upload.single("file"),
   documentToTextController.documentToText
 );
 
 export default router;
 
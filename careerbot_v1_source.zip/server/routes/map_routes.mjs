/* This routes will handle user skill profiles, profile data
 */

/**
 * @openapi
 * components:
 *  schemas:
 *    Map:
 *      title: Map
 *      description: single item in list of maps, Note that not all properties are included here, check response
 *      type: object
 *      properties:
 *        question:
 *          type: string
 *          description: Name of the map
 *          example: profile_name.2021.02.21.15
 *        map_id:
 *          type: integer
 *          description: The id of the map
 *          example: 234
 *        type:
 *          type: string
 *          description: type of map
 *          example: labor, educational, personal
 *        author:
 *          type: string
 *          description: Name of the user who requested the map
 *          example: Jhon Doe
 *    MapData:
 *      title: MapData
 *      description: Data of single user map or example map
 *      type: object
 *      properties:
 *          finalData:
 *              type: json
 *              description: processed data to be used with d3-force
 *              example: {value: 2929, connected: [ [28, 0.4432], [1, 0.9543], ...], x: 805.432, y: 405.4324, ...}
 *          clusterCount:
 *              type: integer
 *              description: Number of cluster in the nodes array
 *              example: 3
 *          type:
 *              type: string
 *              description: type of map
 *              example: labor, educational, personal
 *          name:
 *              type: string
 *              description: Name of the map
 *              example: profile_name.2021.02.21.15
 *
 */

import Router from "express";
import MapController from "../controllers/map_controller.mjs";
import AuthController from "../controllers/auth_controller.mjs";

const router = Router();

/**
 *  @openapi
 *  /map/examples:
 *  get:
 *      tags:
 *      - map
 *      summary: Get list of example maps
 *      description: This returns a list of example in MapData format with all needed data included
 *      responses:
 *          200:
 *              description: success reponse for get list of example of maps
 *              content:
 *                  application/json:
 *                      schema:
 *                        type: array
 *                        items:
 *                          $ref: '#/components/schemas/MapData'
 *          400:
 *              description: Bad request maliformed request body
 *              content:
 *                  application/json:
 *                      schema:
 *                          $ref: '#/components/schemas/Error'
 */
router.get("/examples/", MapController.getExampleMaps);

/**
 *  @openapi
 *  /map/:
 *  post:
 *      tags:
 *      - map
 *      summary: Request CV map (create map)
 *      description: This is used to request map based on CV
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      type: object
 *                      properties:
 *                          MapName:
 *                              type: string
 *                              description: This value must be one of the profile names of the end user
 *                              example: profile_name
 *      responses:
 *          201:
 *              description: This will return success message upon successful request
 *              content:
 *                  application/json:
 *                      schema:
 *                        type: object
 *                        properties:
 *                          message:
 *                            type: string
 *                            description: message dscriping status of operation
 *                            example: success
 *          400:
 *              description: Internal server error
 *              content:
 *                  application/json:
 *                      schema:
 *                          $ref: '#/components/schemas/Error'
 */
router.post("/", AuthController.authenticateUser, MapController.requestCVMap);

/**
 *  @openapi
 *  /map/:
 *  get:
 *      security:
 *          bearerToken: []
 *      tags:
 *      - map
 *      summary: Get list of user maps
 *      description: This returns a list of maps of currently authenticated user
 *      responses:
 *          200:
 *              description: success reponse for get list of map data
 *              content:
 *                  application/json:
 *                      schema:
 *                        type: object
 *                        properties:
 *                          status:
 *                            type: string
 *                            description: This show status of the map (calculating ... or Ready)
 *                            example: Ready, calculating...
 *                          data:
 *                            type: array
 *                            items:
 *                              $ref: '#/components/schemas/Map'
 *          400:
 *              description: Bad request maliformed request body
 *              content:
 *                  application/json:
 *                      schema:
 *                          $ref: '#/components/schemas/Error'
 */
router.get("/", AuthController.authenticateUser, MapController.getUserMaps);

/**
 *  @openapi
 *  /map/{id}:
 *  get:
 *      security:
 *          bearerToken: []
 *      tags:
 *      - map
 *      summary: Get a single map data
 *      description: This returns map data of with mapId equal to id
 *      parameters:
 *      - in: path
 *        name: id
 *        required: true
 *        description: mapId of the map requested.
 *        schema:
 *          type: integer
 *      responses:
 *          200:
 *              description: success reponse for get map data
 *              content:
 *                  application/json:
 *                      schema:
 *                        $ref: '#/components/schemas/MapData'
 *          400:
 *              description: Bad request maliformed request body
 *              content:
 *                  application/json:
 *                      schema:
 *                          $ref: '#/components/schemas/Error'
 */
router.get(
  "/:id(\\d+)",
  AuthController.authenticateUser,
  MapController.getMapData
);

/**
 *  @openapi
 *  /map/{id}:
 *  delete:
 *      security:
 *          bearerToken: []
 *      tags:
 *      - map
 *      summary: Delete a single map
 *      description: This will delete the map with mapId=id with sucessfull authentication
 *      parameters:
 *      - in: path
 *        name: id
 *        required: true
 *        description: mapId of the map to be deleted.
 *        schema:
 *          type: integer
 *      responses:
 *          200:
 *              description: success reponse for deleting map
 *              content:
 *                  application/json:
 *                      schema:
 *                        type: object
 *                        properties:
 *                          message:
 *                            type: string
 *                            description: message dscriping status of operation
 *                            example: Map (201) removed successfuly
 *          400:
 *              description: Bad request maliformed request body
 *              content:
 *                  application/json:
 *                      schema:
 *                          $ref: '#/components/schemas/Error'
 */
router.delete(
  "/:id(\\d+)",
  AuthController.authenticateUser,
  MapController.deleteMap
);

export default router;

/* This routes will handle user authentication/authorization
 * New user signup, user authentication, update user account details
 * TODO: remove api documentation to separate files since it is take more space than the code and reading the code become harder
 */

/**
 * @openapi
 * components:
 *  schemas:
 *      User:
 *          title: User
 *          description: User profile or user data
 *          type: object
 *          properties:
 *              firstName:
 *                  type: string
 *                  description: The first name of the user
 *                  example: Jhon
 *              lastName:
 *                  type: string
 *                  description: The last name of the user
 *                  example: Doe
 *              email:
 *                  type: string
 *                  description: Email of the user
 *                  example: jhondoe@example.com
 *              signinType:
 *                  type: string
 *                  description: The signin type used by user
 *                  example: google or linkedin
 *
 *      AuthData:
 *          title: Authenticaiton Data
 *          description: Data returned when using Google or LinkedIn authentication, Note the User object is retured as profile here
 *          type: object
 *          properties:
 *                  profile:
 *                      type: object
 *                      description: The contains user details/ data refere to User object
 *                  message:
 *                      type: string
 *                      description: message describing the action to be taken after auth process
 *                      example: Terms and condition, sucess or change auth method
 *                  newSigninMethod:
 *                      type: string
 *                      description: This will be set when a new user sign up with specific oAuth provider e.g Google or LinkedIN
 *                      example: Google or Linkedin
 *                  token:
 *                      type: string
 *                      description: JSON Web Token(jwt)
 *                      example: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c
 *                  state:
 *                      type: string
 *                      description: This is only set when using LinkedIn sigin to protect against CSRF attack
 *                      example: IUzI1NiIsIn or any random string set by client
 *      Error:
 *          title: Error Message
 *          description: This is error message for most routes in this api
 *          type: object
 *          properties:
 *              message:
 *                  type: string
 *                  description: Error message descriping the posible reason and/or where part of the API it happend
 *
 *
 */

import Router from "express";
import AuthController from "../controllers/auth_controller.mjs";
import app from "../app.mjs";

const router = Router();

/**
 *  @openapi
 *  /auth/:
 *  post:
 *      tags:
 *      - auth
 *      summary: create new user
 *      description: Create new user or signup user by providing user details
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      $ref: '#/components/schemas/User'
 *      responses:
 *          201:
 *              description: success reponse for create user
 *              content:
 *                  application/json:
 *                      schema:
 *                          $ref: '#/components/schemas/User'
 *          400:
 *              description: Bad request maliformed request body
 *              content:
 *                  application/json:
 *                      schema:
 *                          $ref: '#/components/schemas/Error'
 */
router.post("/", AuthController.createNewUser);

/**
 *  @openapi
 *  /auth/:
 *  put:
 *      tags:
 *      - auth
 *      security:
 *          bearerToken: []
 *      summary: Update user details
 *      description: Update user details with new data
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      $ref: '#/components/schemas/User'
 *      responses:
 *          200:
 *              description: success reponse for update user details
 *              content:
 *                  application/json:
 *                      schema:
 *                          $ref: '#/components/schemas/User'
 *          400:
 *              description: Bad request maliformed request body
 *              content:
 *                  application/json:
 *                      schema:
 *                          $ref: '#/components/schemas/Error'
 */
router.put("/", AuthController.authenticateUser, AuthController.updateUser);

/**
 * DELETE base_url/auth/
 Note: this route is not tested or used on frontend app,
 it is only here as project was ported to more modular structure
 handle delete user
 */
router.delete("/", AuthController.authenticateUser, AuthController.deleteUser);

/**
 *  @openapi
 *  /auth/google:
 *  post:
 *      tags:
 *      - auth
 *      summary: Sign in using Google token id
 *      description: This is used to signin using Google account, it will return AuthenticatioData with different message depending wether user is new or existing
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      type: object
 *                      properties:
 *                          tokenId:
 *                              type: string
 *                              description: Google token id
 *                              example: dWIiOiIxMjM0NTY3ODkwIiwibmFtZS
 *      responses:
 *          200:
 *              description: success response for google authentication
 *              content:
 *                  application/json:
 *                      schema:
 *                          $ref: '#/components/schemas/AuthData'
 *          400:
 *              description: Bad request maliformed request body
 *              content:
 *                  application/json:
 *                      schema:
 *                          $ref: '#/components/schemas/Error'
 */
router.post("/google", AuthController.googleLogin);

/**
 *  @openapi
 *  /auth/linkedin:
 *  post:
 *      tags:
 *      - auth
 *      summary: Sign in using LinkedIn OAuth 2.0 authorization code
 *      description: This is used to signin using LinkedIn account, it will return AuthenticatioData with different message depending wether user is new or existing
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      type: object
 *                      properties:
 *                          code:
 *                              type: string
 *                              description: OAuth 2.0 authorization code
 *                              example: dWIiOiIxMjM0NTY3ODkwIiwibmFtZS
 *                          state:
 *                              type: string
 *                              description: random string used to prevent CSRF
 *                              example: dWIiOiIxMjM0NTY3ODkwIiwibmFtZS
 *      responses:
 *          200:
 *              description: success response for google authentication
 *              content:
 *                  application/json:
 *                      schema:
 *                          $ref: '#/components/schemas/AuthData'
 *          500:
 *              description: Internal server error
 *              content:
 *                  application/json:
 *                      schema:
 *                          $ref: '#/components/schemas/Error'
 */
router.post("/linkedin", AuthController.linkedInLogin);

/**
 *  @openapi
 *  /auth/redirect/linkedin:
 *  post:
 *      tags:
 *      - auth
 *      summary: Redirect URL for LinkedIn OAuth 2.0
 *      description: This is only used by LinkedIn OAuth to provide the OAuth 2.0 authorization code and state, the values will provided as query parameters
 *      responses:
 *          200:
 *              description: This is an HTML response with OAuth 2.0 authorization code and state inside the script tag using ejs views
 *              content:
 *                  text/plain:
 *          500:
 *              description: Internal server error
 *              content:
 *                  application/json:
 *                      schema:
 *                          $ref: '#/components/schemas/Error'
 */
router.get("/redirect/linkedin", AuthController.linkedInRedirect);

/**
 *  @openapi
 *  /auth/redirect/linkedin:
 *  post:
 *      tags:
 *      - auth
 *      summary: Redirect URL for Google OAuth 2.0
 *      description: This is only used by Google OAuth to provide the OAuth 2.0 authorization code and state, the values will provided as query parameters
 *      responses:
 *          200:
 *              description: This is an HTML response with OAuth 2.0 authorization code and state inside the script tag using ejs views
 *              content:
 *                  text/plain:
 *          500:
 *              description: Internal server error
 *              content:
 *                  application/json:
 *                      schema:
 *                          $ref: '#/components/schemas/Error'
 */
router.get("/redirect/google", AuthController.googleRedirect);

router.get("/logout", AuthController.logOutUser);

router.get("/login", AuthController.hakaLogin);
router.get("/haka", AuthController.getHakaLogin);
router.post("/haka",AuthController.hakaLoginUser);

export default router;

/* eslint-disable no-await-in-loop */
import axios from "axios";
import d3 from "d3";
import netClustering from "netclustering/dist/netClustering.js";
import models from "../models/index.mjs";
import { HEADAI_BASE_URL } from "../constants/index.mjs";

/* Constant variables */
const MAX_CIRCLE_RADIUS = 32; // size of largest node circle (in pixels))
const MAX_NODE_COUNT = 500; // too big is too messy and slow
const CENTER_FORCE_WIDTH = 1400;
const CENTER_FORCE_HEIGHT = 900;
const VELOCITY_DECAY = 0.55;

export const preprocessData = async (mapData) => {
  const realData = { nodeData: [], edgeData: [] };
  const { data } = mapData;

  /* ## Processing map nodes ## */

  // slice nodes if nodes are more than max node count allowed
  if (data.nodes.length > MAX_NODE_COUNT) {
    data.nodes = data.nodes.slice(0, MAX_NODE_COUNT);
  }

  /*
   * sort the nodes according to value property of each node object
   * this will be used to sort and find max value at the same time
   */
  data.nodes.sort((a, b) => b.value - a.value);

  const nodesMaxValue = data.nodes[0].value;

  // re-index nodes (zero-based int without gaps)
  const nodeIds = [];
  realData.nodeData = data.nodes.map((n, i) => {
    nodeIds.push(n.id);
    return {
      ...n,
      id: i,
      total_weight: 0,
      connection_count: 0,
      connected: [],
      label_extra: n.label,
      r: MAX_CIRCLE_RADIUS * Math.sqrt(n.value / nodesMaxValue) + 1.5,
    };
  });

  /* ## Processing map edges ## */

  let maxValue = -1;
  for (let i = 0; i < data.edges.length; i += 1) {
    // new indices
    const source = nodeIds.indexOf(data.edges[i].from);
    const target = nodeIds.indexOf(data.edges[i].to);

    if (data.edges[i].value >= 1 && source > -1 && target > -1) {
      realData.edgeData.push({
        source,
        target,
        value: parseInt(data.edges[i].value, 10),
      });
      maxValue = Math.max(maxValue, parseInt(data.edges[i].value, 10));
    }
  }

  /* ## Rescale weights */
  let minValue = 1;
  for (let i = 0; i < realData.edgeData.length; i += 1) {
    realData.edgeData[i].value /= maxValue; // maximum will be 1.0
    minValue = Math.min(minValue, realData.edgeData[i].value);
    const s = realData.edgeData[i].source;
    const t = realData.edgeData[i].target;
    realData.nodeData[s].total_weight += realData.edgeData[i].value;
    realData.nodeData[t].total_weight += realData.edgeData[i].value;
    realData.nodeData[s].connection_count += 1;
    realData.nodeData[t].connection_count += 1;
    realData.nodeData[t].label_extra = `${realData.nodeData[t].label}\n${String(
      realData.nodeData[t].total_weight.toFixed(1)
    )} (${realData.nodeData[t].connection_count})`;
    realData.nodeData[s].label_extra = `${realData.nodeData[s].label}\n${String(
      realData.nodeData[s].total_weight.toFixed(1)
    )} (${realData.nodeData[s].connection_count})`;
    if (realData.edgeData[i].value > 1.0)
      throw new Error("Weight rescale error: Scaled weight over 1!");
  }

  const edgeValueLimits = [minValue, 1.0]; // limits

  netClustering.cluster(realData.nodeData, realData.edgeData);

  const clusters = new Set();
  for (let i = 0; i < realData.nodeData.length; i += 1) {
    realData.nodeData[i].group = parseInt(realData.nodeData[i].cluster, 10) + 1;
    clusters.add(realData.nodeData[i].group);
  }
  let clusterCount = clusters.size;
  if (clusterCount > 10) {
    // only 10 colors, just put remaining into group 10 (or could add more colors)
    realData.nodeData.forEach((e, i) => {
      realData.nodeData[i].group = 10;
    });
    clusterCount = 10;
  }

  for (let i = 0; i < realData.edgeData.length; i += 1) {
    const edge = realData.edgeData[i];
    realData.edgeData[i].dist =
      realData.nodeData[edge.source].r + realData.nodeData[edge.target].r;
  }

  return { realData, clusterCount, edgeValueLimits };
};

const getSimulation = async (
  nodeData,
  edgeData,
  attractionVal,
  edgestrengthVal
) => {
  const attractForce = d3.forceManyBody().strength(attractionVal).theta(0.8);
  const collisionForce = d3
    .forceCollide()
    .strength(1)
    .iterations(130)
    .radius((d) => d.r);
  const edgeForce = d3
    .forceLink(edgeData)
    .id((d) => d.id)
    .strength((d) => d.value * edgestrengthVal)
    .iterations(5)
    .distance((d) => d.dist);
  const simulation = d3
    .forceSimulation(nodeData)
    .velocityDecay(VELOCITY_DECAY)
    .alphaDecay(0.04)
    .force(
      "center",
      d3.forceCenter(CENTER_FORCE_WIDTH / 2, CENTER_FORCE_HEIGHT / 2)
    )
    .force("attractForce", attractForce)
    .force("edgeForce", edgeForce)
    .force("collisionForce", collisionForce)
    .stop();
  return simulation;
};

// scaling of highlight oca
function rescaleOpacity(w, edgeValueLimits) {
  let temW = w;
  temW = (temW - edgeValueLimits[0]) / edgeValueLimits[1]; // between 0-1
  temW = Math.sin((temW * Math.PI) / 2); // 0-1
  const newW = 0.1 + 0.9 * temW; // cut bottom
  // new_w = (0.1+0.9*w)
  if (newW > 1 && newW < 0) throw new Error("ERROR: edge value outside range");
  return newW;
}

// add field with all connected nodes, needed for highlighting
const addConnected = async (nodedata, edgedata, edgeValueLimits) => {
  for (let i = 0; i < edgedata.length; i += 1) {
    const source = edgedata[i].source.id;
    const target = edgedata[i].target.id;

    nodedata[source].connected.push([
      target,
      rescaleOpacity(edgedata[i].value, edgeValueLimits),
    ]);
    nodedata[target].connected.push([
      source,
      rescaleOpacity(edgedata[i].value, edgeValueLimits),
    ]);
  }
  return nodedata;
};

export const runSimulation = async (preprocssedData) => {
  const { nodeData, edgeData } = preprocssedData.realData;

  /*
   * attraction force strength = 30
   * edge force strength = 2
   */
  const simulation = await getSimulation(nodeData, edgeData, 30, 2);

  const n = Math.ceil(
    Math.log(simulation.alphaMin()) / Math.log(1 - simulation.alphaDecay())
  );
  for (let i = 0; i < n; i += 1) {
    simulation.tick();
  }

  const finalData = await addConnected(
    nodeData,
    edgeData,
    preprocssedData.edgeValueLimits
  );
  return finalData;
};

const calculateMap = async (mapData) => {
  try {
    for (let i = 0; i < mapData.length; i += 1) {
      const config = {
        params: {
          action: "request_map_data",
          token: process.env.EXPRESS_APP_HEADAI_TOKEN,
          map_id: mapData[i].map_id,
        },
        timeout: 10 * 1000,
      };
      const response = await axios.get(HEADAI_BASE_URL, config);

      if (response.data) {
        const { data } = response;
        const {
          realData,
          clusterCount,
          edgeValueLimits,
        } = await preprocessData(data);
        const finalData = await runSimulation({
          realData,
          edgeValueLimits,
        });
        models.Maps.create({
          finalData,
          realData,
          clusterCount,
          mapId: mapData[i].map_id,
          name: data.information.question,
          type: data.information.type,
        });
      }
    }
    return { message: "Map calculation complete!" };
  } catch (error) {
    return { message: "Map calculation error", error: error.message };
  }
};

process.on("message", async (message) => {
  const result = await calculateMap(message.data);
  process.send(result);
});

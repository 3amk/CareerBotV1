import dotenv from "dotenv";
import axios from "axios";
import { HEADAI_BASE_URL } from "../constants/index.mjs";

dotenv.config();

export const searchRelatedThesisService = async (keywords) => {
  try {
    const config = {
      params: {
        action: "search_related_thesis",
        keywords: keywords,
        limit:100,
        token: process.env.EXPRESS_APP_HEADAI_TOKEN,
      },
    };
    const response = await axios.get(HEADAI_BASE_URL, config);
    return response.data;
  } catch (error) {
    throw new Error(`search Courses Service: Internal server error.`);
  }
};
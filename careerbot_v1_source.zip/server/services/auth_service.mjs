/* eslint-disable camelcase */
import google from "google-auth-library";
import axios from "axios";
import CryptoJS from "crypto-js";
import db from "../models/index.mjs";
import { signJWT } from "../utils/jwt_util.mjs";
import {
  HEADAI_BASE_URL,
  LINKEDIN_RIDERECT,
  GOOGLE_RIDERECT,
} from "../constants/index.mjs";

// TODO: replace crypto-js package with crypto NodeJS native module

// initialize googel auth library
const { OAuth2Client } = google;
const client = new OAuth2Client(process.env.EXPRESS_GOOGLE_CLIENT_ID);
const hakaLoginType = "haka";
/* ============= Helper functions ============ */

// TODO: save refresh token to database to obtain new access_token or id_token without repeating OAuth2.0 flow
const requestGoogleAccessToken = async (code) => {
  try {
    const data = {
      code,
      client_id: process.env.EXPRESS_APP_GOOGLE_CLIENT_ID,
      client_secret: process.env.EXPRESS_APP_GOOGLE_CLIENT_SECRET,
      redirect_uri: GOOGLE_RIDERECT,
      grant_type: "authorization_code",
    };
    const response = await axios.post(
        "https://oauth2.googleapis.com/token",
        data
    );
    return response.data.id_token;
  } catch (error) {
    throw new Error(`Google service: Internal server error.`);
  }
};

const requestLinkedInAccessToken = async (code, state) => {
  const data = {
    grant_type: "authorization_code",
    redirect_uri: LINKEDIN_RIDERECT,
    client_id: process.env.EXPRESS_APP_LINKEDIN_ID,
    client_secret: process.env.EXPRESS_APP_LINKEDIN_SECRET,
    code,
    state,
  };
  const token = await axios({
    url: "https://www.linkedin.com/oauth/v2/accessToken",
    method: "POST",
    headers: {
      "Content-type": "application/x-www-urlenconded",
    },
    params: data,
  });
  return token;
};

const requestLinkedInProfile = async (token) => {
  const config = {
    headers: { Authorization: `Bearer ${token}` },
  };

  const profile = await axios.get(
      "https://api.linkedin.com/v2/me?projection=(localizedFirstName,localizedLastName)",
      config
  );
  const emailData = await axios.get(
      "https://api.linkedin.com/v2/emailAddress?q=members&projection=(elements*(handle~))",
      config
  );
  const email = emailData.data.elements[0]["handle~"];
  const fullProfile = { ...profile.data, ...email };
  return fullProfile;
};


const encryptPayload = (obj) => {
  const encrypted = CryptoJS.AES.encrypt(
      JSON.stringify(obj),
      process.env.EXPRESS_APP_ENCRYPT_SECRET
  );
  return encrypted.toString();
};

const dycryptPayload = (data) => {
  const dycrypted = CryptoJS.AES.decrypt(
      data,
      process.env.EXPRESS_APP_ENCRYPT_SECRET
  );
  return JSON.parse(dycrypted.toString(CryptoJS.enc.Utf8));
};


// Gets an existing profile from database
const getUserProfileHaka = async (dbUser, authUser, state) => {

  if (dbUser){
    const profile = dbUser.toJSON();
    const userToken = await signJWT(dbUser.id);
    return {
      profile: {
        firstName: profile.firstName,
        lastName: profile.lastName,
        ptoken: encryptPayload({ id: profile.id }),
        signinType: hakaLoginType,
      },
      message: "SUCCESS",
      newSigninMethod: null,
      token: userToken,
      state,
    };
  } else {
    return {
      profile: {
        firstName: authUser.firstName,
        lastName: authUser.lastName,
        ptoken: encryptPayload({ email: authUser.email }),
        signinType: hakaLoginType,
      },
      message: "TERMS_AND_CONDITION",
      newSigninMethod: null,
      state,
    };
  }


}

const getUserProfile = async (dbUser, authUser, state, verifyService) => {
  // if user exist in database
  if (dbUser) {
    const profile = dbUser.toJSON();
    const modifedProfile = {
      firstName: profile.firstName,
      lastName: profile.lastName,
      ptoken: encryptPayload({ id: profile.id }),
      signinType: profile.signinType,
    };
    const userToken = await signJWT(dbUser.id);
    // if user using the same oAuth service as before return success
    if (dbUser.signinType === verifyService) {
      return {
        profile: modifedProfile,
        message: "SUCESS",
        newSigninMethod: null,
        token: userToken,
        state,
      };
    }
    // else if user using new oAuth service with the same email prompt to change oAuth provider
    return {
      profile: modifedProfile,
      newSigninMethod: verifyService,
      message: "CHANGE_AUTH_METHOD",
      token: userToken,
      state,
    };
  }
  // if user is new, prompt for terms and conditons agreement
  return {
    profile: {
      firstName: authUser.firstName,
      lastName: authUser.lastName,
      ptoken: encryptPayload({ email: authUser.email }),
      signinType: verifyService,
    },
    message: "TERMS_AND_CONDITION",
    newSigninMethod: null,
    state,
  };
};

/* ============= Helper functions end ============ */

/*
This service talks with google oAuth2.0 api to get user data and very token
*/
export const googleVerifyService = async (code, state) => {
  try {
    const tokenId = await requestGoogleAccessToken(code);
    // verify token and exchange it with user profile
    const ticket = await client.verifyIdToken({
      idToken: tokenId,
      audience: process.env.EXPRESS_GOOGLE_CLIENT_ID,
    });
    const {
      email_verified,
      given_name,
      family_name,
      email,
    } = ticket.getPayload();
    // check if user email is verified,
    if (email_verified) {
      // get user from database using email
      const user = await db.Users.findOne({ where: { email } });
      const userProfile = await getUserProfile(
          user,
          {
            firstName: given_name,
            lastName: family_name,
            email,
          },
          state,
          "google"
      );
      return userProfile;
    }
    return null;
  } catch (error) {
    // error from google auth or database
    throw new Error(`Google service: Internal server error.`);
  }
};
// CN and eppn are headers from Apache Shibboleth proxy (used in Haka SAML login)
// cn = full name
// eppn = email
export const hakaVerifyService = async (cn, eppn, state) => {

  // Null if not found
  const user = await db.Users.findOne({
    where: { email: eppn },
  });

  // Split the fullname to first and lastname using space as delimiter
  const firstName = cn.substr(0,cn.indexOf(' '));
  const lastName = cn.substr(cn.indexOf(' ')+1);


  const userProfile = await getUserProfileHaka(
      user,
      {
        firstName: firstName,
        lastName: lastName,
        email: eppn,
      },
      state,
      "haka");

  return userProfile;

}

/* LinkedIn redierct service */
export const linkedInVerifyService = async (code, state) => {
  try {
    const token = await requestLinkedInAccessToken(code, state);

    const linkedinProfile = await requestLinkedInProfile(
        token.data.access_token
    );

    const user = await db.Users.findOne({
      where: { email: linkedinProfile.emailAddress },
    });
    const userProfile = await getUserProfile(
        user,
        {
          firstName: linkedinProfile.localizedFirstName,
          lastName: linkedinProfile.localizedLastName,
          email: linkedinProfile.emailAddress,
        },
        state,
        "linkedIn"
    );
    return userProfile;
  } catch (error) {
    // error from LinkedIn auth or database
    throw new Error(`LinkedIn service: Internal server error.`);
  }
};

/* Create new user after use have agreed to terms */
export const createNewUserService = async (newUser) => {
  try {
    if (
        newUser.firstName &&
        newUser.lastName &&
        newUser.ptoken &&
        newUser.signinType
    ) {
      const deycryptedLoad = dycryptPayload(newUser.ptoken);
      if (deycryptedLoad.email) {
        const idHash = CryptoJS.SHA256(
            deycryptedLoad.email + process.env.EXPRESS_APP_SHA_SALT
        ).toString();

        const user = await db.Users.create({
          firstName: newUser.firstName,
          lastName: newUser.lastName,
          email: deycryptedLoad.email,
          signinType: newUser.signinType,
          idHash,
        });

        const token = await signJWT(user.dataValues.id);
        const config = {
          params: {
            action: "register_end_user",
            token: process.env.EXPRESS_APP_HEADAI_TOKEN,
            end_user_id: idHash,
          },
        };
        await axios.get(HEADAI_BASE_URL, config);
        const profile = user.toJSON();
        const modifedProfile = {
          firstName: profile.firstName,
          lastName: profile.lastName,
          ptoken: encryptPayload({ id: profile.id }),
          signinType: profile.signinType,
        };
        return { profile: modifedProfile, token };
      }
      throw new Error("Invalid data");
    }
    throw new Error("Invalid data");
  } catch (error) {
    throw new Error(`New user service: Internal server error.`);
  }
};

/* Update user data like oAuth authentication type signtype , firstName, email ..... */
export const updateUserService = async (profile) => {
  try {
    const deycryptedLoad = dycryptPayload(profile.ptoken);
    if (deycryptedLoad.id) {
      const updatedProfile = {
        firstName: profile.firstName,
        lastName: profile.lastName,
        signinType: profile.signinType,
      };
      await db.Users.update(updatedProfile, {
        where: { id: deycryptedLoad.id },
      });
      const token = await signJWT(deycryptedLoad.id);
      return { profile: { ...updatedProfile, ptoken: profile.ptoken }, token };
    }
    throw new Error("Invalid data");
  } catch (error) {
    throw new Error(`Update user service: Internal server error.`);
  }
};

/* This service is not used, it is only here as project was ported to more modular structure */
export const deleteUserService = async (profile, userId) => {
  try {
    const deycryptedLoad = dycryptPayload(profile.ptoken);
    if (deycryptedLoad.id && userId) {
      await db.Users.destroy({ where: { id: deycryptedLoad.id } });
      const config = {
        params: {
          action: "delete_end_user",
          token: process.env.EXPRESS_APP_HEADAI_TOKEN,
          end_user_id: userId,
        },
      };
      const response = await axios.get(HEADAI_BASE_URL, config);
      return response.data;
    }
    throw new Error("Invalid data");
  } catch (error) {
    throw new Error(`Delete user service: Internal server error.`);
  }
};

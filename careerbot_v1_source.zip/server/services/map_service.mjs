import dotenv from "dotenv";
import axios from "axios";
import { fork } from "child_process";
import db from "../models/index.mjs";
import { HEADAI_BASE_URL } from "../constants/index.mjs";

dotenv.config();

const sendMapsForCalculation = async (unprocessedMaps) => {
  try {
    const child = fork("./services/map_calculation.mjs");
    setTimeout(() => {
      child.send({ data: unprocessedMaps });
    }, 1000);

    child.on("message", (result) => {
      // eslint-disable-next-line no-console
      console.log(result);
    });
  } catch (error) {
    // eslint-disable-next-line no-console
    console.log("map calculation error", error);
  }
};

export const getUserMapsService = async (userId) => {
  try {
    const config = {
      params: {
        action: "list_maps",
        token: process.env.EXPRESS_APP_HEADAI_TOKEN,
        end_user_id: userId,
      },
    };
    const response = await axios.get(HEADAI_BASE_URL, config);

    const personalMaps = response.data.data.filter(
      (m) => m.type === "personal"
    );

    if (personalMaps.length > 0) {
      let errorMaps = [];
      let validMaps = [];

      /* group personal maps into valid maps and invalid maps (error maps, error maps don't have sufficient data to be calculated)
       * This is already fixed by not calculating empty skill profiles, this is only here to handle old invalid maps
       */
      personalMaps.forEach((m) => {
        if (m.file_location.includes("map_error")) errorMaps.push(m);
        else validMaps.push(m);
      });

      /* add status properry to error maps */
      errorMaps = errorMaps.map((m) => ({
        data: m,
        status: "Error (Not sufficient data to calculate.)",
      }));

      /*
       *if there are more than 0 valid maps check how many are processed and saved in database
       * send unprocessed maps for calucation to child process
       * */
      if (validMaps.length > 0) {
        const mapIds = validMaps.map((m) => m.map_id);
        const mapsInDB = await db.Maps.findAll({
          where: { map_id: mapIds },
          attributes: ["mapId"],
        });

        /* if there are processed maps in database use the list to filter out unprocessed maps, else return all with status calculating */
        if (mapsInDB.length > 0) {
          const proccessedIds = mapsInDB.map((m) => m.dataValues.mapId);

          let unprocessedMaps = [];
          let processedMaps = [];

          validMaps.forEach((m) => {
            if (proccessedIds.includes(m.map_id)) processedMaps.push(m);
            else unprocessedMaps.push(m);
          });

          if (unprocessedMaps.length > 0)
            sendMapsForCalculation(unprocessedMaps);

          unprocessedMaps = unprocessedMaps.map((m) => ({
            data: m,
            status: "Calculating",
          }));

          processedMaps = processedMaps.map((m) => ({
            data: m,
            status: "Ready!",
          }));
          return processedMaps.concat(unprocessedMaps, errorMaps);
        }

        /* if there are no maps in database send all valid maps for calculation */
        sendMapsForCalculation(validMaps);
        validMaps = validMaps.map((m) => ({
          data: m,
          status: "Calculating",
        }));

        return validMaps.concat(errorMaps);
      }
      return errorMaps;
    }
    return [];
  } catch (error) {
    throw new Error(`Get user maps service: Internal server error.`);
  }
};

export const requestCVMapService = async (mapName, userId) => {
  try {
    const config = {
      params: {
        action: "request_cv_map",
        token: process.env.EXPRESS_APP_HEADAI_TOKEN,
        map_name: mapName,
        end_user_id: userId,
      },
    };
    await axios.get(HEADAI_BASE_URL, config);
    return { message: "sucess" };
  } catch (error) {
    throw new Error(`Requst cv map service: Internal server error.`);
  }
};

// TODO: verify owner of map by adding user id to map table on database
export const getMapDataService = async (mapId) => {
  try {
    const mapData = await db.Maps.findOne({ where: { mapId } });
    if (mapData) {
      return mapData;
    }
    throw new Error("Resource not found.");
  } catch (error) {
    throw new Error(`Get map data service: Internal server error.`);
  }
};

export const deleteMapService = async (mapId, userId) => {
  try {
    const map = await db.Maps.findOne({ where: { mapId } });

    if (map) {
      await db.Maps.destroy({ where: { mapId } });
      const config = {
        params: {
          action: "remove_map",
          token: process.env.EXPRESS_APP_HEADAI_TOKEN,
          map_id: mapId,
          end_user_id: userId,
        },
      };
      const response = await axios.get(HEADAI_BASE_URL, config);
      return response.data;
    }
    throw new Error("Resource not found.");
  } catch (error) {
    throw new Error(`Delete map  service: Internal server error.`);
  }
};

export const getExampleMapsService = async () => {
  try {
    const mapData = await db.ExampleMaps.findAll();
    return mapData;
  } catch (error) {
    throw new Error(`Get example maps  service: Internal server error.`);
  }
};

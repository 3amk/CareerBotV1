import dotenv from "dotenv";
import axios from "axios";
import db from "../models/index.mjs";
import { preprocessData, runSimulation } from "../services/map_calculation.mjs"

dotenv.config();

const processMap = async (data) =>{
  const {
    realData,
    clusterCount,
    edgeValueLimits,
  } = await preprocessData(data);

  const finalData = await runSimulation({
    realData,
    edgeValueLimits,
  });
  
  return {
    finalData,
    realData,
    clusterCount,
  }
}

const insertExampleMap = async (data) => {
  const {finalData, clusterCount, type, name} = data;
  const map = await db.ExampleMaps.create({
    finalData,
    clusterCount,
    type,
    name,
  });
  return map;
}

const exampleMapExists = async (title) => {
  const result = await db.ExampleMaps.findOne({ where: { 'name':title } });
  if (result){
    return true;
  } return false;
}

export const refreshExampleMapsService = async () => {
  try {
    const url = "https://3amkapi.headai.com/microcompetencies?action=get_example_maps";
    const response = await axios.get(url);
    const exampleMaps = response.data.data;
    if (!Array.isArray(exampleMaps)) throw new Error();

    const titlesExampleMaps = [];

    for (let i = 0; i < exampleMaps.length; i++) {
      const exampleMap = exampleMaps[i];
      const {title, location, type} = exampleMap;
      titlesExampleMaps.push(title);
      const mapExists = await exampleMapExists(title);
      if (mapExists === true){
        const updated = await updateExampleMapService(location, title, type);
        exampleMap['state'] = (updated === true)? 'updated':'skipped';
        continue;
      }
      const map = await insertExampleMapService(location, title, type);
      exampleMap['state'] = 'inserted';
    }

    const removedTitles = await removeOldExampleMaps(titlesExampleMaps);

    for (let i = 0; i < removedTitles.length; i++) {
      const title = removedTitles[i];
      exampleMaps.push({'title':title,'state':'removed'});
    }

    return exampleMaps;
  } catch (error) {
    throw new Error(`Refresh Example Maps: Internal server error.`);
  }
};

const removeOldExampleMaps = async (desiredTitles) => {
  // Doesnt remove old maps if receives invalid param or if list is small or empty
  if (!Array.isArray(desiredTitles) || desiredTitles.length < 5) return [];

  const removedTitles = [];
  const currentExampleMaps = await db.ExampleMaps.findAll();
  for (let i = 0; i < currentExampleMaps.length; i++) {
    const map = currentExampleMaps[i].dataValues;
    const title = map.name;
    if (desiredTitles.includes(title)) continue;
    await removeExampleMap(title);
    removedTitles.push(title);
  }
  return removedTitles;
}

const removeExampleMap = async (title) => {
  await db.ExampleMaps.destroy({ where: { 'name':title } });
}

export const insertExampleMapService = async (url,name=null,type=null) => {
  try {
    const response = await axios.get(url);
    if (typeof(type) != "string") type = "";
    if (typeof(name) != "string") name = "";

    const {finalData, realData, clusterCount} = await processMap(response.data);
    const mapData = {finalData, clusterCount, type, name};
    const map = await insertExampleMap(mapData);
    return { map };
  } catch (error) {
    throw new Error(`Insert example maps service: Internal server error.`);
  }
};

const updateExampleMapService = async (url, name=null, type=null) => {
  try {
    const response = await axios.get(url);
    if (typeof(type) != "string") type = "";
    if (typeof(name) != "string") name = "";

    const result = await db.ExampleMaps.findOne({ where: { 'name':name } });
    const oldFinalData = JSON.stringify(result.dataValues.finalData);

    const {finalData, realData, clusterCount} = await processMap(response.data);
    
    const newFinalData = JSON.stringify(finalData);

    const hasChanged = (oldFinalData != newFinalData);

    if (!hasChanged) return false;

    // If Has Changed
    const nRowsAffected = await db.ExampleMaps.update(
      { 'finalData' : finalData },
      { 'where': { 'name' : name } }
    );

    return hasChanged;

  } catch (error) {
    throw new Error(`Insert example maps service: Internal server error.`);
  }
}

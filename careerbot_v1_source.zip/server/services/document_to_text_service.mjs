import dotenv from "dotenv";

dotenv.config();

import request from "request";


export const documentToTextService = async (file, callback) => {
  try {
    var token = process.env.EXPRESS_APP_MEGATRON_TOKEN
    var url = "https://megatron.headai.com/Utils?action=document_to_text&token=" + token;

    request({
      uri: url,
      method: "POST",
      formData: {
          "file": {
              value: file.buffer,
              options: {
                  filename: file.originalname,
                  contentType: file.mimetype
              }
          }
      }
    }, (err, resp, body) => {
      var code = resp.statusCode;
      if (typeof(body) == "string"){
        body = JSON.parse(body);
      }
      callback(body, code)
    })
  } catch (error) {
    throw new Error(`Document To Text: Internal server error. ${error}`);
  }
};
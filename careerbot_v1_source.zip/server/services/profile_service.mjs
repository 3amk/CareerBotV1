import dotenv from "dotenv";
import axios from "axios";
import { HEADAI_BASE_URL } from "../constants/index.mjs";

dotenv.config();

export const createNewProfileService = async (profileName, userIdHash) => {
    let data = profileName;
    let buff = new Buffer(data, 'base64');
    let decodedProfileName = buff.toString('ascii');
  try {
    const config = {
      params: {
        action: "save_user_text_new",
        name: decodedProfileName,
        token: process.env.EXPRESS_APP_HEADAI_TOKEN,
        end_user_id: userIdHash,
      },
    };
    const response = await axios.get(HEADAI_BASE_URL, config);
    return response.data;
  } catch (error) {
    throw new Error(`Create profile service: Internal server error.`);
  }
};

export const getUserProfilesService = async (userIdHash) => {
  try {
    const config = {
      params: {
        action: "list_all_user_texts_new",
        token: process.env.EXPRESS_APP_HEADAI_TOKEN,
        end_user_id: userIdHash,
      },
    };
    const response = await axios.get(HEADAI_BASE_URL, config);
    return response.data;
  } catch (error) {
    throw new Error(`Get profiles service: Internal server error.`);
  }
};

export const getProfileDataService = async (profileName, userIdHash) => {
  let data = profileName;
    let buff = new Buffer(data, 'base64');
    let decodedProfileName = buff.toString('ascii');

  try {
    const config = {
      params: {
        action: "get_user_text_new",
        name: decodedProfileName,
        token: process.env.EXPRESS_APP_HEADAI_TOKEN,
        end_user_id: userIdHash,
      },
    };
    const response = await axios.get(HEADAI_BASE_URL, config);
    return response.data;
  } catch (error) {
    throw new Error(`Get profile data service: Internal server error.`);
  }
};

export const updateProfileDataService = async (newProfileData, userIdHash) => {
  try {
    const params = {
      action: "update_user_text_new",
      name: newProfileData.name,
      text: newProfileData.text,
      koski_text: newProfileData.koski_text,
      include_skills: newProfileData.include_skills,
      exclude_skills: newProfileData.exclude_skills,
      courses: newProfileData.courses,
      token: process.env.EXPRESS_APP_HEADAI_TOKEN,
      end_user_id: userIdHash,
    };
    const response = await axios({
      url: HEADAI_BASE_URL,
      method: "post",
      params,
    });
    return response.data;
  } catch (error) {
    throw new Error(`Update profile data service: Internal server error.`);
  }
};

export const deleteProfileService = async (profileName, userIdHash) => {
  let data = profileName;
    let buff = new Buffer(data, 'base64');
    let decodedProfileName = buff.toString('ascii');
  try {
    const config = {
      params: {
        action: "delete_user_text",
        name: decodedProfileName,
        token: process.env.EXPRESS_APP_HEADAI_TOKEN,
        end_user_id: userIdHash,
      },
    };
    const response = await axios.get(HEADAI_BASE_URL, config);
    return response.data;
  } catch (error) {
    throw new Error(`Delete profile service: Internal server error.`);
  }
};

import dotenv from "dotenv";
import axios from "axios";
import { HEADAI_BASE_URL } from "../constants/index.mjs";

dotenv.config();

export const searchCoursesService = async (Text, school, courseId, courseCode) => {
  try {
    const config = {
      params: {
        action: "search_courses",
        text: Text,
        school: school,
        course_id: courseId,
        course_code: courseCode,
        token: process.env.EXPRESS_APP_HEADAI_TOKEN,
      },
    };
    const response = await axios.get(HEADAI_BASE_URL, config);
    return response.data;
  } catch (error) {
    throw new Error(`search Courses Service: Internal server error.`);
  }
};
import dotenv from "dotenv";
import axios from "axios";
import { HEADAI_BASE_URL } from "../constants/index.mjs";

dotenv.config();
// search_courses_by_text is updated with search_courses
export const searchCoursesByTextService = async (text, school) => {
  
  // update the schoolnames if "AMKosaaja" is selected
  let amkSchool=[""];
  let checkFirst=school.includes("AMKosaaja");
  if(checkFirst && school.length>1){
    for (let i=0; i<school.length; i++){
      if(school[i]!="amkosaaja"){
        amkSchool[i]=school[i]+"-amkosaaja";
      }
    }
  }  else if(checkFirst && school.length==1){
    amkSchool=["haaga-helia-amkosaaja,metropolia-amkosaaja,hamk-amkosaaja,laurea-amkosaaja,xamk-amkosaaja"];
    }
    else {
      for (let i=0; i<school.length; i++){
          if(school[i]=="Hamk" || school[i]=="Xamk"){
            amkSchool[i]=school[i]+"-AMKosaaja";
        }
      else {
        amkSchool=school;
        }
    }
  }
  // delete all empty strings
  amkSchool = amkSchool.filter(e => e !== '');
  amkSchool=amkSchool.toString();
  try {
    const config = {
      params: {
        action: "search_courses",
        text: text,
        school: amkSchool,
        token: process.env.EXPRESS_APP_HEADAI_TOKEN,
      },
    };
    const response = await axios.get(HEADAI_BASE_URL, config);
    return response.data;
  } catch (error) {
    throw new Error(`Search Courses By Text Service: Internal server error.`);
  }
};
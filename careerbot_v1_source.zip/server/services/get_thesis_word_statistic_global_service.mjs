import dotenv from "dotenv";
import axios from "axios";
import { HEADAI_BASE_URL } from "../constants/index.mjs";

dotenv.config();

export const thesisWordStatisticGlobalService = async (text) => {
  try {
    const config = {
      params: {
        action: "get_article_word_statistic", // Update the action here
        text: text,
        lang: "fi",
        token: process.env.EXPRESS_APP_HEADAI_TOKEN,
      },
    };
    const response = await axios.get(HEADAI_BASE_URL, config, {timeout: 60 * 60 * 1000});
    return response.data;
  } catch (error) {
    throw new Error(`Search Courses By Text Service: Internal server error.`);
  }
};
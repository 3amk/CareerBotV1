import dotenv from "dotenv";
import axios from "axios";
import { HEADAI_BASE_URL } from "../constants/index.mjs";

dotenv.config();

export const wordCompleteService = async (word, type, language) => {
  try {
    const config = {
      params: {
        action: "word_complete",
        type: type,
        word: word,
        lang: language,
        country_code: "fi",
        token: process.env.EXPRESS_APP_HEADAI_TOKEN,
      },
    };
    const response = await axios.get(HEADAI_BASE_URL, config);
    return response.data;
  } catch (error) {
    throw new Error(`word Complete Service: Internal server error.`);
  }
};
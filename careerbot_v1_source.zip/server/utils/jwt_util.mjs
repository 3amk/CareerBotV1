import jwt from "jsonwebtoken";
import { v4 as uuidv4 } from "uuid";
import models from "../models/index.mjs";

/*
 * Sign jsonwebtoken using user id, a secret and jwt id (jti)
 * using uuid package for generating universal unique id, it is better to use popular and well maintained package for this purpose
 * instead of implementing our own generator
 */
export const signJWT = async (userId) => {
  const payload = { id: userId };
  const finalToken = await new Promise((resolve, reject) => {
    jwt.sign(
      payload,
      process.env.EXPRESS_APP_JWT_SECRET,
      {
        expiresIn: "10h",
        jwtid: uuidv4(),
      },
      (error, token) => {
        if (error) reject(error);
        else resolve(token);
      }
    );
  });
  return finalToken;
};

export const decodeJWT = async (token) => {
  try {
    const decodedToken = jwt.verify(token, process.env.EXPRESS_APP_JWT_SECRET);
    if (decodedToken.id) {
      return decodedToken;
    }
    throw new Error("Error: Unauthorized access");
  } catch (error) {
    throw new Error(`Error unauthorized access`);
  }
};

export const verifyJWT = async (token) => {
  try {
    const decodedToken = jwt.verify(token, process.env.EXPRESS_APP_JWT_SECRET);
    if (decodedToken.id) {
      const user = await models.Users.findOne({
        where: { id: decodedToken.id },
      });
      return user;
    }
    throw new Error("Error: Unauthorized access");
  } catch (error) {
    throw new Error(`Error unauthorized access`);
  }
};

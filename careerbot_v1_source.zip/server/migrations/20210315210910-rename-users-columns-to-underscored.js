module.exports = {
  up: async (queryInterface) => {
    const tables = await queryInterface.showAllTables();
    if (tables.includes("users")) {
      const description = await queryInterface.describeTable("users");
      if (description.updatedAt) {
        const migrations = [
          queryInterface.renameColumn("users", "firstName", "first_name"),
          queryInterface.renameColumn("users", "lastName", "last_name"),
          queryInterface.renameColumn("users", "signinType", "signin_type"),
          queryInterface.renameColumn("users", "idHash", "id_hash"),
          queryInterface.renameColumn("users", "updatedAt", "updated_at"),
          queryInterface.renameColumn("users", "createdAt", "created_at"),
        ];
        return Promise.all(migrations);
      }
      return Promise.resolve();
    }
    return Promise.resolve();
  },

  down: async (queryInterface) =>
    Promise.all([
      queryInterface.renameColumn("users", "updated_at", "updatedAt"),
      queryInterface.renameColumn("users", "created_at", "createdAt"),
      queryInterface.renameColumn("users", "first_name", "firstName"),
      queryInterface.renameColumn("users", "last_name", "lastName"),
      queryInterface.renameColumn("users", "signin_type", "signinType"),
      queryInterface.renameColumn("users", "id_hash", "idHash"),
    ]),
};

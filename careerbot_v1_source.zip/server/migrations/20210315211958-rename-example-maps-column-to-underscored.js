module.exports = {
  up: async (queryInterface, Sequelize) => {
    const tables = await queryInterface.showAllTables();
    if (tables.includes("example_maps")) {
      const description = await queryInterface.describeTable("example_maps");

      const migrations = [];
        
      if (description.finalData) migrations.push(queryInterface.renameColumn("example_maps", "finalData", "final_data"));
      if (description.updatedAt && description.clusterCount)
        migrations.push(
          ...[
            queryInterface.renameColumn(
              "example_maps",
              "clusterCount",
              "cluster_count"
            ),
            queryInterface.renameColumn(
              "example_maps",
              "updatedAt",
              "updated_at"
            ),
            queryInterface.renameColumn(
              "example_maps",
              "createdAt",
              "created_at"
            ),
          ]
        );
      return Promise.all(migrations);
    }
    return Promise.resolve();
  },

  down: async (queryInterface) =>
    Promise.all([
      queryInterface.renameColumn("example_maps", "final_data", "finalData"),
      queryInterface.renameColumn("example_maps", "updated_at", "updatedAt"),
      queryInterface.renameColumn("example_maps", "created_at", "createdAt"),
      queryInterface.renameColumn("example_maps", "cluster_count", "clusterCount"),
    ]),
};

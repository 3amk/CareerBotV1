module.exports = {
  up: async (queryInterface) => {
    const tables = await queryInterface.showAllTables();
    if (tables.includes("ExampleMaps")) {
      await queryInterface.dropTable("example_maps");
      return queryInterface.renameTable("ExampleMaps", "example_maps");
    }
    return Promise.resolve();
  },

  down: async (queryInterface) =>
    queryInterface.renameTable("example_maps", "ExampleMaps"),
};

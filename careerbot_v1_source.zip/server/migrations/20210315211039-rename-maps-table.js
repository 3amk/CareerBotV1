module.exports = {
  up: async (queryInterface) => {
    const tables = await queryInterface.showAllTables();
    if (tables.includes("Maps")) {
      await queryInterface.dropTable("maps");
      return queryInterface.renameTable("Maps", "maps");
    }
    return Promise.resolve();
  },

  down: async (queryInterface) => queryInterface.renameTable("maps", "Maps"),
};

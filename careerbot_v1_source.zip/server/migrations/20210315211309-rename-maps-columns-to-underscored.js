module.exports = {
  up: async (queryInterface, Sequelize) => {
    const tables = await queryInterface.showAllTables();
    if (tables.includes("maps")) {
      const description = await queryInterface.describeTable("maps");

      const migrations = [];

      if (description.finalData) migrations.push(queryInterface.renameColumn("maps", "finalData", "final_data"));
      if (description.realData) migrations.push(queryInterface.renameColumn("maps", "realData", "real_data"));
      if (description.mapId) migrations.push(queryInterface.renameColumn("maps", "mapId", "map_id"));

      if (description.updatedAt)
        migrations.push(
          ...[
            queryInterface.renameColumn("maps", "clusterCount", "cluster_count"),
            queryInterface.renameColumn("maps", "updatedAt", "updated_at"),
            queryInterface.renameColumn("maps", "createdAt", "created_at"),
          ]
        );
      return Promise.all(migrations);
    }
    return Promise.resolve();
  },

  down: async (queryInterface) =>
    Promise.all([
      queryInterface.renameColumn("maps", "final_data", "finalData"),
      queryInterface.renameColumn("maps", "real_data", "realData"),
      queryInterface.renameColumn("maps", "cluster_count", "clusterCount"),
      queryInterface.renameColumn("maps", "updated_at", "updatedAt"),
      queryInterface.renameColumn("maps", "created_at", "createdAt"),
      queryInterface.renameColumn("maps", "map_id", "mapId"),
    ]),
};

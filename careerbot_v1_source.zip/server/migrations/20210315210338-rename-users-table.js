module.exports = {
  up: async (queryInterface) => {
    const tables = await queryInterface.showAllTables();
    if (tables.includes("Users")) {
      await queryInterface.dropTable("users");
      return queryInterface.renameTable("Users", "users");
    }
    return Promise.resolve();
  },

  down: async (queryInterface) => queryInterface.renameTable("users", "Users"),
};

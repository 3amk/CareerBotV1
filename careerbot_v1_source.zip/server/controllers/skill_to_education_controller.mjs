import { createRequire } from 'module';
const require = createRequire(import.meta.url);

import {
    skillToEducationService,
} from "../services/skill_to_education_service.mjs";

const getSkillToEducation = async (req, res) => {
  try {
    let limit= req.query.limit;
    let skill= req.query.skill;
    if (skill) {
      const json = await  skillToEducationService(skill, limit);
      res.status(201).json(json);
    } else {
      res
        .status(400)
        .json({ error: "Search skill is missing on request body." });
    }
  } catch (error) {
    res.status(400).json({
      message: `Error at Skill To Education controller: ${error.message}`,
    });
  }
};

export default {
    getSkillToEducation,

  };
import { createRequire } from 'module';
const require = createRequire(import.meta.url);

import {
    thesisWordStatisticGlobalService,
} from "../services/get_thesis_word_statistic_global_service.mjs";

const getThesisWordStatisticGlobal = async (req, res) => {
  try {
    let text= req.query.text;
    if (text) {
      const json = await thesisWordStatisticGlobalService(text);
      res.status(201).json(json);
    } else {
      res
        .status(400)
        .json({ error: "Search text is missing on request body." });
    }
  } catch (error) {
    res.status(400).json({
      message: `Error at Search Courses controller: ${error.message}`,
    });
  }
};

export default {
    getThesisWordStatisticGlobal
  };
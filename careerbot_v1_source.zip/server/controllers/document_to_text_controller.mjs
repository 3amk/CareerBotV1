import {
    documentToTextService,
} from "../services/document_to_text_service.mjs";


const documentToText = async (req, res) => {
  try {
    if (req.file) {
      function callback(data, status){
        res.status(status).json(data);
      }
      documentToTextService(req.file, callback);
    } else {
      res
        .status(400)
        .json({ error: "File is missing on request body." });
    }
  } catch (error) {
    res.status(400).json({
      message: `Error at DocumentToText controller: ${error.message}`,
    });
  }
};

export default {
    documentToText
  };
/*
 * This controller handles all example maps related operations
 * get list of maps, request map calculation, get single map data ...
 */

import {
    refreshExampleMapsService,
} from "../services/example_map_service.mjs";

const refreshExampleMaps = async (req, res) => {
    try {
        const json = await refreshExampleMapsService();
        res.status(200).json(json);
    } catch (error) {
        res.status(400).json({
        message: `Error at Example Maps controller: ${error.message}`,
        });
    }
};

export default {
    refreshExampleMaps,
};
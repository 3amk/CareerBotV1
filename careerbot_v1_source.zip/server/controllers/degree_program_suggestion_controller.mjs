import { createRequire } from 'module';
const require = createRequire(import.meta.url);

import {
    degreeProgramSuggestionService,
} from "../services/degree_program_suggestion_service.mjs";

const getDegreeProgramSuggestion = async (req, res) => {
  try {
   let  edu_organization= req.query.edu_organization;
   let  search_phrase= req.query.search_phrase;
    if (search_phrase) {
      const json = await degreeProgramSuggestionService(edu_organization, search_phrase);
      res.status(201).json(json);
    } else {
      res
        .status(400)
        .json({ error: "Search text is missing on request body." });
    }
  } catch (error) {
    res.status(400).json({
      message: `Error at Degree Program Suggestion controller: ${error.message}`,
    });
  }
};

export default {
    getDegreeProgramSuggestion
  };
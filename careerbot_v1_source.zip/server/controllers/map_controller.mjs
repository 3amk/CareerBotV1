/*
 * This controller handles all user maps related operations
 * get list of maps, request map calculation, get single map data ...
 */

import {
  getUserMapsService,
  requestCVMapService,
  getMapDataService,
  deleteMapService,
  getExampleMapsService,
} from "../services/map_service.mjs";

const getUserMaps = async (req, res) => {
  try {
    const { user } = req;
    const list = await getUserMapsService(user.idHash);
    res.status(200).json(list);
  } catch (error) {
    res.status(400).json({
      message: `Error at get maps controller: ${error.message}`,
    });
  }
};

const requestCVMap = async (req, res) => {
  try {
    const { mapName } = req.body;
    const { user } = req;
    if (mapName) {
      const message = await requestCVMapService(mapName, user.idHash);
      res.status(201).json(message);
    } else {
      res.state(400).json({ error: "Map name is missing on request body." });
    }
  } catch (error) {
    res.status(400).json({
      message: `Error at request cv maps controller: ${error.message}`,
    });
  }
};

const getMapData = async (req, res) => {
  try {
    const { id } = req.params;
    if (id !== undefined) {
      const intId = parseInt(id, 10);
      const data = await getMapDataService(intId);
      res.status(200).json(data);
    } else {
      res.state(400).json({ error: "Map id is missing on request." });
    }
  } catch (error) {
    res.status(400).json({
      message: `Error at get maps data controller: ${error.message}`,
    });
  }
};

const deleteMap = async (req, res) => {
  try {
    const { id } = req.params;
    const { user } = req;
    if (id !== undefined) {
      const intId = parseInt(id, 10);
      const json = await deleteMapService(intId, user.idHash);
      res.status(200).json(json);
    } else {
      res.state(400).json({ error: "Map id is missing on request." });
    }
  } catch (error) {
    res.status(400).json({
      message: `Error at delete maps controller: ${error.message}`,
    });
  }
};

const getExampleMaps = async (req, res) => {
  try {
    const examples = await getExampleMapsService();
    res.status(200).json(examples);
  } catch (error) {
    res.status(400).json({
      message: `Error at delete maps controller: ${error.message}`,
    });
  }
};

export default {
  getUserMaps,
  requestCVMap,
  getMapData,
  deleteMap,
  getExampleMaps,
};

/*
 * This controller handles all user account related operations
 * signup new user, update user account details, delete user, authenticate user
 */

import crypto from "crypto";

import {
  googleVerifyService,
  linkedInVerifyService,
  createNewUserService,
  updateUserService,
  deleteUserService, hakaVerifyService,
} from "../services/auth_service.mjs";
import { verifyJWT, decodeJWT } from "../utils/jwt_util.mjs";
import {getExampleMapsService} from "../services/map_service.mjs";

// controller for Google redirect route
const googleRedirect = async (req, res) => {
  const nonce = crypto.randomBytes(16).toString("base64");
  try {
    const { code, state } = req.query;
    res.setHeader("Content-Security-Policy", `script-src 'nonce-${nonce}'`);
    res.render("callback", { ...{ code, state }, nonce, type: "GOOGLE" });
  } catch (error) {
    const message = "Internal server error.";
    res.setHeader("Content-Security-Policy", `script-src 'nonce-${nonce}'`);
    res.render("error", { ...{ message }, nonce, type: "ERROR" });
  }
};


// Used to reroute user to app after apache shibboleth login.
const hakaLogin = async (req, res) => {
  const eppn=req.header("eppn");
  const cn=req.header("cn");
  const expires = new Date();
  expires.setSeconds(expires.getSeconds() + 1000);
  const json = {
    name: cn,
    email: eppn
  };
  if (eppn==="" || eppn!==null){
    res.cookie("token",json,{
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      expires: expires
    })

    res.writeHead(302, {
      'Location': '/'
    });
    res.end();
  } else {
    res.status(400).json({
      message: "Haka-login failed"
    })
  }
};

// Used to login haka user to application
const hakaLoginUser= async (req, res) => {
  try{
    const {state} = req.body;

    const eppn=req.header("eppn");
    const cn=req.header("cn");

    // Either user data or request to accept user agreement
    const responseJSON = await hakaVerifyService(cn, eppn, state);

    if (responseJSON.message !== "TERMS_AND_CONDITION") {

      // ????
      const decodedJWT = decodeJWT(responseJSON.token);
      const date = new Date(decodedJWT.exp * 1000);
      res.cookie("token", responseJSON.token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        expires: date,
      });
      delete responseJSON.token;
      res.status(200).json(responseJSON);
    } else {
      res.status(201).json(responseJSON);
    }
  }catch(e){
    res.status(400).json({
      message: "Error in Haka login",
    });
  }
};


// controller for Google login route
const googleLogin = async (req, res) => {
  try {
    const { code, state } = req.body;
    if (code) {
      const json = await googleVerifyService(code, state);
      if (json.message !== "TERMS_AND_CONDITION") {
        const decodedJWT = decodeJWT(json.token);
        const date = new Date(decodedJWT.exp * 1000);
        res.cookie("token", json.token, {
          httpOnly: true,
          secure: process.env.NODE_ENV === "production",
          expires: date,
        });
        delete json.token;
        res.status(200).json(json);
      }
      // if user is new send encrypted payload only and create new user after privacy and terms accepted by user
      else {
        res.status(201).json(json);
      }
    } else {
      res.status(400).json({
        message: "Error at Google controller: Authentication error",
      });
    }
  } catch (error) {
    res.status(400).json({
      message: `Error at Google controller: ${error.message}`,
    });
  }
};


// controller for LinkedIn redirect route
const linkedInRedirect = async (req, res) => {
  const nonce = crypto.randomBytes(16).toString("base64");
  try {
    const { code, state } = req.query;
    res.setHeader("Content-Security-Policy", `script-src 'nonce-${nonce}'`);
    res.render("callback", { ...{ code, state }, nonce, type: "LINKEDIN" });
  } catch (error) {
    const message = "Internal server error.";
    res.setHeader("Content-Security-Policy", `script-src 'nonce-${nonce}'`);
    res.render("error", { ...{ message }, nonce, type: "ERROR" });
  }
};

// controller for LinkedIn login route
const linkedInLogin = async (req, res) => {
  try {
    const { code, state } = req.body;
    if (code) {
      const json = await linkedInVerifyService(code, state);
      if (json.message !== "TERMS_AND_CONDITION") {
        const decodedJWT = decodeJWT(json.token);
        const date = new Date(decodedJWT.exp * 1000);
        res.cookie("token", json.token, {
          httpOnly: true,
          secure: process.env.NODE_ENV === "production",
          expires: date,
        });
        delete json.token;
        res.status(200).json(json);
      }
      // if user is new send encrypted payload only and create new user after privacy and terms accepted by user
      else {
        res.status(201).json(json);
      }
    } else {
      res.status(400).json({
        message: "Error at Google controller: Authentication error",
      });
    }
  } catch (error) {
    res.status(500).json({
      message: `Error at LinkedIn controller: ${error.message}`,
    });
  }
};

// controller for creating new user after user have agreed to terms
const createNewUser = async (req, res) => {
  try {
    const json = await createNewUserService(req.body);
    const decodedJWT = decodeJWT(json.token);
    const date = new Date(decodedJWT.exp * 1000);
    res.cookie("token", json.token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      expires: date,
    });
    delete json.token;
    res.status(201).json(json);
  } catch (error) {
    res.status(400).json({
      message: `Error at new user controller: ${error.message}`,
    });
  }
};

// controller to update user profile like email, name, oAuth authentication type(signin type)
const updateUser = async (req, res) => {
  try {
    const { profile } = req.body;
    if (profile && req.user) {
      const json = await updateUserService(profile, req.user);
      const decodedJWT = decodeJWT(json.token);
      const date = new Date(decodedJWT.exp * 1000);
      res.cookie("token", json.token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        expires: date,
      });
      delete json.token;
      res.status(200).json(json);
    } else {
      throw new Error("profile not provided");
    }
  } catch (error) {
    res.status(400).json({
      message: `Error at update user controller: ${error.message}`,
    });
  }
};

// controller to delete user
/* This controller is not used, it is only here as project was ported to more modular structure, not tested */
const deleteUser = async (req, res) => {
  try {
    const { profile } = req.body;
    const { user } = req;
    if (profile && user) {
      const json = await deleteUserService(profile, user.idHash);
      res.state(200).json(json);
    } else {
      res.state(400).json({ error: "Profile data missing." });
    }
  } catch (error) {
    res.status(400).json({
      message: `Error at delete user controller: ${error.message}`,
    });
  }
};

const authenticateUser = async (req, res, next) => {
  try {
    const { token } = req.cookies;
    if (token) {
      const user = await verifyJWT(token);
      if (user) {
        req.user = user;
        next();
      } else res.status(401).json({ error: "Invalid token" });
    } else {
      res.status(401).json({ error: "Token missing." });
    }
  } catch (error) {
    res.status(400).json({
      message: `Authentication: ${error.message}`,
    });
  }
};

const logOutUser = async (req, res) => {
  try {

    //req.session.destroy();

    res.clearCookie("token");


    res.writeHead(302, {
      'Location': process.env.EXPRESS_APP_HAKA_SLO_URL
    });

    res.end();
  } catch (error) {
    res.status(400).json({
      message: `Authentication: ${error.message}`,
    });
  }
};

// Get haka login cn and eppn
const getHakaLogin = async (req, res) => {

  const eppn=req.header("eppn");
  const cn=req.header("cn");
  const expires = new Date();
  expires.setSeconds(expires.getSeconds() + 1000);
  const json = {
    name: cn,
    email: eppn
  };
  if (eppn==="" || eppn!==null){
    res.cookie("token",json,{
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      expires: expires
    })
    res.status(200).json(json);

  } else {
    res.status(400).json({
      message: "Haka-login failed"
    })
  }
}


export default {
  hakaLoginUser,
  hakaLogin,
  googleLogin,
  linkedInLogin,
  createNewUser,
  updateUser,
  deleteUser,
  authenticateUser,
  logOutUser,
  linkedInRedirect,
  googleRedirect,
  getHakaLogin
};

import { createRequire } from 'module';
const require = createRequire(import.meta.url);

import {
    searchCoursesService,
} from "../services/search_courses_service.mjs";

const getSearchCourses = async (req, res) => {
  try {
   let text= req.query.text;
   let school= req.query.school;
   let course_id= req.query.course_id;
   let course_code= req.query.course_code;
    if (school) {
      const json = await searchCoursesService(text, school, course_id, course_code);
      res.status(201).json(json);
    } else {
      res
        .status(400)
        .json({ error: "Search text or course Id is missing on request body." });
    }
  } catch (error) {
    res.status(400).json({
      message: `Error at Search Courses controller: ${error.message}`,
    });
  }
};

export default {
    getSearchCourses
  };
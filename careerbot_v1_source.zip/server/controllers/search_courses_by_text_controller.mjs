import { createRequire } from 'module';
const require = createRequire(import.meta.url);

import {
    searchCoursesByTextService,
} from "../services/search_courses_by_text_service.mjs";

const getSearchCoursesByText = async (req, res) => {
  try {
    let text= req.query.text;
   let school= req.query.school;
    if (text) {
      const json = await searchCoursesByTextService(text, school);
      res.status(201).json(json);
    } else {
      res
        .status(400)
        .json({ error: "Search text is missing on request body." });
    }
  } catch (error) {
    res.status(400).json({
      message: `Error at Degree Program Suggestion controller: ${error.message}`,
    });
  }
};

export default {
    getSearchCoursesByText
  };
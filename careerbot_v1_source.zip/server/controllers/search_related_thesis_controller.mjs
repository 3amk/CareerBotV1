import { createRequire } from 'module';
const require = createRequire(import.meta.url);

import {
    searchRelatedThesisService,
} from "../services/search_related_thesis_service.mjs";

const getSearchRelatedThesis = async (req, res) => {
  try {
    let keywords= req.query.keywords;
    
    if (keywords) {
      const json = await searchRelatedThesisService(keywords);
      res.status(201).json(json);
    } else {
      res
        .status(400)
        .json({ error: "Search keywords is missing on request body." });
    }
  } catch (error) {
    res.status(400).json({
      message: `Error at Search Related Thesis controller: ${error.message}`,
    });
  }
};

export default {
    getSearchRelatedThesis,

  };
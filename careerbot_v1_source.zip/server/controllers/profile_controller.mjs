/*
 * This controller handles profile related operations
 * get all user profiles, get single profile data ...
 */
import { createRequire } from 'module';
const require = createRequire(import.meta.url);

import {
  createNewProfileService,
  getUserProfilesService,
  getProfileDataService,
  updateProfileDataService,
  deleteProfileService,
} from "../services/profile_service.mjs";

const createNewProfile = async (req, res) => {
  try {
    const { user } = req;  
    const { profileName } = req.body;
    if (profileName) {
      const json = await createNewProfileService(profileName, user.idHash);
      res.status(201).json(json);
    } else {
      res
        .status(400)
        .json({ error: "Profile name is missing on request body." });
    }
  } catch (error) {
    res.status(400).json({
      message: `Error at create profile controller: ${error.message}`,
    });
  }
};

const getUserProfiles = async (req, res) => {
  try {
    const { user } = req;
    const json = await getUserProfilesService(user.idHash);
    res.status(200).json(json);
  } catch (error) {
    res.status(400).json({
      message: `Error at get profiles controller: ${error.message}`,
    });
  }
};

const getProfileData = async (req, res) => {
  try {
    const { user } = req;
    const { profileName } = req.params;
    if (profileName) {
      const json = await getProfileDataService(profileName, user.idHash);
      res.status(200).json(json);
    } else {
      res.status(400).json({ error: "Profile name is missing." });
    }
  } catch (error) {
    res.status(400).json({
      message: `Error at get profile data controller: ${error.message}`,
    });
  }
};

const updateProfileData = async (req, res) => {
  try {
    const { user } = req;
    const json = await updateProfileDataService(req.body, user.idHash);
    res.status(200).json(json);
  } catch (error) {
    res.status(400).json({
      message: `Error at update profile data controller: ${error.message}`,
    });
  }
};

const deleteProfile = async (req, res) => {
  try {
    const { user } = req;
    const profileName = req.params.ProfileName;
    if (profileName) {
      const json = await deleteProfileService(profileName, user.idHash);
      res.status(200).json(json);
    } else {
      res.status(400).json({ error: "Profile name is missing." });
    }
  } catch (error) {
    res.status(400).json({
      message: `Error at delete profile controller: ${error.message}`,
    });
  }
};

export default {
  createNewProfile,
  getUserProfiles,
  getProfileData,
  updateProfileData,
  deleteProfile,
};

import { createRequire } from 'module';
const require = createRequire(import.meta.url);

import {
    requestJobsByKeywordsService,
} from "../services/request_jobs_by_keywords_service.mjs";

const getRequestJobsByKeywords = async (req, res) => {
  try {
    let area= req.query.area;
    let words= req.query.words;
    if (words) {
      const json = await requestJobsByKeywordsService(area, words);
      res.status(201).json(json);
    } else {
      res
        .status(400)
        .json({ error: "Search text or course Id is missing on request body." });
    }
  } catch (error) {
    res.status(400).json({
      message: `Error at Search Courses controller: ${error.message}`,
    });
  }
};

export default {
    getRequestJobsByKeywords,
  };
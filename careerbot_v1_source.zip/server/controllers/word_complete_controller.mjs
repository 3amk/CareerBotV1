import { createRequire } from 'module';
const require = createRequire(import.meta.url);

import {
    wordCompleteService,
} from "../services/word_complete_service.mjs";

const getWordComplete = async (req, res) => {
  try {
    let type= req.query.type;
    let word= req.query.word;
    let lang= req.query.lang;
    if (word) {
      const json = await  wordCompleteService(word, type, lang);
      res.status(201).json(json);
    } else {
      res
        .status(400)
        .json({ error: "Search data is missing on request body." });
    }
  } catch (error) {
    res.status(400).json({
      message: `Error at Word Complete controller: ${error.message}`,
    });
  }
};

export default {
    getWordComplete,

  };
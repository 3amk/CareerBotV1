import { createRequire } from 'module';
const require = createRequire(import.meta.url);

import {
    educationListService,
} from "../services/education_list_service.mjs";

const getEducationList = async (req, res) => {
  try {
      const json = await educationListService();
      res.status(201).json(json);
  } catch (error) {
    res.status(400).json({
      message: `Error at Education List controller: ${error.message}`,
    });
  }
};

export default {
    getEducationList
  };
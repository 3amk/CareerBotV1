import { createRequire } from 'module';
const require = createRequire(import.meta.url);

import {
    semanticSuggestionService,
} from "../services/semantic_suggestion_service.mjs";

const getSemanticSuggestion = async (req, res) => {
  try {
    let type= req.query.type;
    let word= req.query.word;
    let lang= req.query.lang;
    
    if (word) {
      const json = await  semanticSuggestionService(word, type, lang);
      res.status(201).json(json);
    } else {
      res
        .status(400)
        .json({ error: "Search skill is missing on request body." });
    }
  } catch (error) {
    res.status(400).json({
      message: `Error at Semantic Suggestion controller: ${error.message}`,
    });
  }
};

export default {
    getSemanticSuggestion,

  };
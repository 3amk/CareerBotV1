// Base url for headai api
export const HEADAI_BASE_URL = "https://3amkapi.headai.com/microcompetencies";

// LinkedIn redirect
export const LINKEDIN_RIDERECT =
  process.env.NODE_ENV === "production"
    ? process.env.EXPRESS_APP_LINKEDIN_REDIRECT_URI_PROD
    : process.env.EXPRESS_APP_LINKEDIN_REDIRECT_URI_DEV;

// Google reirect
export const GOOGLE_RIDERECT =
  process.env.NODE_ENV === "production"
    ? process.env.EXPRESS_APP_GOOGLE_REDIRECT_URI_PROD
    : process.env.EXPRESS_APP_GOOGLE_REDIRECT_URI_DEV;

export default {
  HEADAI_BASE_URL,
  LINKEDIN_RIDERECT,
  GOOGLE_RIDERECT,
};

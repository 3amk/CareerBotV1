const maps = (sequelize, DataTypes) => {
  // const Maps = sequelize.define("Maps", {
  //   final_data: DataTypes.JSON,
  //   real_data: DataTypes.JSON,
  //   clusterCount: DataTypes.INTEGER,
  //   type: DataTypes.STRING,
  //   name: DataTypes.STRING,
  //   map_id: DataTypes.INTEGER,
  // });

  const Maps = sequelize.define("maps", {
    finalData: DataTypes.JSON,
    realData: DataTypes.JSON,
    clusterCount: DataTypes.INTEGER,
    type: DataTypes.STRING,
    name: DataTypes.STRING,
    mapId: DataTypes.INTEGER,
  });

  return Maps;
};

export default maps;

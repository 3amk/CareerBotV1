const exampleMaps = (sequelize, DataTypes) => {
  // const ExampleMaps = sequelize.define("ExampleMaps", {
  //   final_data: DataTypes.JSON,
  //   clusterCount: DataTypes.INTEGER,
  //   type: DataTypes.STRING,
  //   name: DataTypes.STRING,
  // });

  const ExampleMaps = sequelize.define("example_maps", {
    finalData: DataTypes.JSON,
    clusterCount: DataTypes.INTEGER,
    type: DataTypes.STRING,
    name: DataTypes.STRING,
  });

  return ExampleMaps;
};

export default exampleMaps;

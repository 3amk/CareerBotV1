/* eslint-disable no-console */
import dotenv from "dotenv";
import Sequelize from "sequelize";
import { exec } from "child_process";
import exampleMap from "./exampleMaps.mjs";
import maps from "./maps.mjs";
import users from "./users.mjs";

dotenv.config();

const sequelize = new Sequelize(
  process.env.DATABASE,
  process.env.DATABASE_USER,
  process.env.DATABASE_PASSWORD,
  {
    host: process.env.DATABASE_HOST,
    port: process.env.DATABASE_PORT,
    dialect: "postgres",
    define: {
      underscored: true,
      freezeTableName: true,
      timestamps: true,
    },
    logging: false,
  }
);

const modelExample = exampleMap(sequelize, Sequelize.DataTypes);
const modelMap = maps(sequelize, Sequelize.DataTypes);
const modelUser = users(sequelize, Sequelize.DataTypes);
const db = {
  ExampleMaps: modelExample,
  Maps: modelMap,
  Users: modelUser,
};

Object.keys(db).forEach((modelName) => {
  if (db[modelName].associate) {
    db[modelName].associate(db);
  }
});

/* RUN MIGRATION BEFORE CONNECTING TO DATABASE */

const runMigrations = async () => {
  const migrations = await new Promise((resolve, reject) => {
    exec("sequelize db:migrate", { env: process.env }, (err, stdout) =>
      err
        ? reject(err)
        : resolve(stdout.split("\n").filter((o) => o.length > 0))
    );
  });

  return migrations;
};

const undoMigraions = async () => {
  const migrations = await new Promise((resolve, reject) => {
    exec("sequelize db:migrate:undo", { env: process.env }, (err, stdout) =>
      err ? reject(err) : resolve(stdout.split("\n"))
    );
  });

  return migrations;
};

runMigrations()
  .then((stdout) => console.log("Database migrations complete! \n", stdout))
  .catch((error) => {
    console.log("Database migrations error: \n", error);
    undoMigraions();
  });

/* END OF MIGRATIONS */

export { sequelize };

export default db;

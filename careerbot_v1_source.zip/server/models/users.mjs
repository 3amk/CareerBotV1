const users = (sequelize, DataTypes) => {
  const Users = sequelize.define("users", {
    firstName: DataTypes.STRING,
    lastName: DataTypes.STRING,
    email: DataTypes.STRING,
    signinType: DataTypes.STRING,
    idHash: DataTypes.STRING,
  });

  // eslint-disable-next-line func-names
  Users.prototype.toJSON = function () {
    const values = { ...this.get() };
    delete values.idHash;
    return values;
  };

  return Users;
};

export default users;

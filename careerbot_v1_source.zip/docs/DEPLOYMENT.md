# Deployment

## Overview

3AMK AI server application is an Express web application hosted on NodeJS runtime environment. It can be deployed anywhere as long as the NodeJS runtime is present. You can use any computer used as server or VPS. Docker is also used to deploy the application using Kubernetes, OpenShift or other platforms providing Docker container.

3AMK AI server application is deployed on [CSC Rahti cloud container](https://rahti.csc.fi/). Rahti is the container orchestration service at CSC. Rahti runs on [OKD](https://www.okd.io/), the community distribution of Kubernetes that powers Red Hat OpenShift. [Refer to this diagram](https://docs.csc.fi/cloud/rahti/concepts/) on CSC docs to get understanding of the different components used when deploying the application on OKD. The server application is deployed from Github repository and the deployment can be carried out using the rahti web user interface or using the oc command line tool (OpenShift CLI) whichever is prefered.

## Deploying to Rahti(OKD) using Terminal

### Install OpenShit CLI(oc)

Refer to [this CSC documentation](https://docs.csc.fi/cloud/rahti/usage/cli/) on how to install oc CLI

### Login

First we have to login to Rahti cloud from our terminal to provision new containers or manage other resources. Login to Rahti cloud from your browser and copy the login command. The login command can be found from drop down button near the account name as can be seen from the image below.
![Login image](./images/login.PNG)

### Selecect OpenShift project

Make sure you are using the correct project before adding any resource. You can run `oc projects` to see a list of your projects and the active project is marked by asterisk(\*). You can set the desired project using `oc project project-name`.

### Database

We need to have a PostgreSQL database ready before deploying the server application because the server application will try to connect to database on startup. It is best to host the database on the same environment where the server is depoloyed, but is is not a requirement as long as the database can be reached over the network from deployment environment. The server application expects configuration values to connect to the database as environmenatal variables. To provision database on Rahti cloud using the oc CLI issue the following commands.

OpenShift Container Platform comes pre-configured with two PostgreSQL templates, we can use the template to create database easily and fast.
To list postres templates run the following command:

```bash
$ oc get templates -n openshift -o custom-columns=NAME:.metadata.name|grep -i ^postgres
```

output:

```bash
postgresql-ephemeral
postgresql-persistent
```

For full information about the template and possible paratmeters that can be passed you can run below command:

```bash
$ oc describe template/postgresql-persistent -n openshift
```

We are going to create a new template based on the `postgresql-persistent` template, since we want our data to be persisted. Don't use `postgresql-ephemeral` for deployment unless your doing test deployment.

Use below command to create a postgres application, adjust the name of the application and database service name according to need:

```bash
$ oc new-app --name=prod-database  --template=postgresql-persistent \
-p POSTGRESQL_USER=db_user \
-p POSTGRESQL_PASSWORD=db_password \
-p POSTGRESQL_DATABASE=my_db \
-p DATABASE_SERVICE_NAME=prod-database
```

You can run `oc get pods` to check if the pod is created.

Run `oc get services` to check if the service was created. This will also give you the IP address of the database, but it is not exposed to the outside world since we don't need and we don't want to expose it. If you need to expose the database for some reason you can run `oc expose service/prod-database`.

### Deploye docker application from GitHub

#### SSH key

Since 3AMK AI server GitHub repository is private we will need SSH key or "GitHub personal access tokens" to clone it. You can follow [this cookbook](https://cookbook.openshift.org/building-and-deploying-from-source/how-can-i-build-from-a-private-repository-on-github.html) to generate SSH key, add it to github as deploy key and add it as secrete to the OpenShift project. [Here](https://docs.openshift.com/container-platform/4.6/builds/creating-build-inputs.html#builds-adding-source-clone-secrets_creating-build-inputs) is also the OpenShift documentation on source clone secretes. The steps to add source clone secrete will be added here incase the linked resources are not working.

1. create new SSH key you can change the names and values to what ever you want

```bash
$ ssh-keygen -C "openshift-source-builder/3amk@github" -f $HOME/.ssh/3amk-at-github -N ''
```

2. Add public SSH key to GitHub private repository

To register the SSH key, go to Settings on the private repositry and click Deploy key, then click Add deploy key. Give the name of the key and then paste the content of the `.pub` file which in this case is `3amk-at-github.pub`.

3. Add private SSH key to Rahti cloud (OpenShift)

```bash
$ oc create secret generic github-secret \ --from-file=ssh-privatekey=$HOME/.ssh/3amk-at-github \ --type=kubernetes.io/ssh-auth
```

4. link secret with builder service accout

```bash
$ oc secret link builder github-secret
```

#### Create file containing environment variables

We need to provide the environmental variables for the server application to work properly. This environmental variables are supposed to kept secure and can not (must not) be included with the source code.

create file with the following environmental variables. Note the that the redirect URI for oAuth need to be provided by adding `/api/v1/auth/redirect/linkedin` to the root domain. here the app domain will be `https://app-name-project-name.rahtiapp.fi` after successfull deployment or if you are using your own domain you can use `https://example.com/api/v1/auth/redirect/google` for oAuth depending on which oAuth name we are adding. Note that all varaible names starting with EXPRESS_APP are used for the server and all variables starting with REACT_APP are for the React app client. We will name the file `build_vars.env`.

```
EXPRESS_APP_HEADAI_TOKEN=HeadAI API token
EXPRESS_APP_LINKEDIN_ID=linkedin oAuth client id
EXPRESS_APP_LINKEDIN_SECRET=linkedin oAuth sercrete
EXPRESS_APP_LINKEDIN_REDIRECT_URI_DEV=needed only on dev environment
EXPRESS_APP_LINKEDIN_REDIRECT_URI_PROD=http://localhost:8080/api/v1/auth/redirect/linkedin
EXPRESS_APP_GOOGLE_CLIENT_ID=google oAuth client id
EXPRESS_APP_GOOGLE_CLIENT_SECRET=google oAuth client secrete
EXPRESS_APP_GOOGLE_REDIRECT_URI_DEV=needed only on dev environment
EXPRESS_APP_GOOGLE_REDIRECT_URI_PROD=http://localhost:8080/api/v1/auth/redirect/google/
EXPRESS_APP_JWT_SECRET=random string to sign JWT token
EXPRESS_APP_ENCRYPT_SECRET=random string for encrypting http payload
EXPRESS_APP_SHA_SALT=random string to encrypt user id sha

DATABASE=database name
DATABASE_USER=database user name
DATABASE_PASSWORD=database password
DATABASE_HOST=ip address (refere database section)
DATABASE_PORT=5432

REACT_APP_HEADAI_TOKEN=HeadAI API token
REACT_APP_LINKEDIN_ID=linkedin oAuth client id
REACT_APP_LINKEDIN_REDIRECT_URI_DEV=needed only on dev environment
REACT_APP_LINKEDIN_REDIRECT_URI_PROD=http://localhost:8080/api/v1/auth/redirect/linkedin
REACT_APP_GOOGLE_CLIENT_ID=google oAuth client id
REACT_APP_GOOGLE_REDIRECT_URI_DEV=needed only on dev environment
REACT_APP_GOOGLE_REDIRECT_URI_PROD=http://localhost:8080/api/v1/auth/redirect/google/
REACT_APP_HOTJAR_ID= Hotjar id (analytics)
REACT_APP_HOTJAR_VERSION= Hotjar version (analytics)
REACT_APP_GA_ID= Google analytics id (analytics)
INLINE_RUNTIME_CHUNK=false (to prevent embedding of script)
```

#### Deploy

Build from GitHub using git URL. We will build from specific branch (master in this case) to isolate production and development deployment.

You can run `oc new-app --help` to get full command usage. Here is the meaning of some the flags used.

```
--name: will set name of the app(pod), service, build and other resources.
--strategy: What stratety to use when building the source code, here it is set to docker so it will look for Dockerfile in the provided context (dir)
-v: verbosity level
--build-env-file: build variables set using file (path to the file)
```

```bash
$ oc new-app --code='git@github.com:3amk/3amk-ai.git#master' --source-secret='github-secret' --name='prod' --strategy=docker -v=7 --build-env-file=build_vars.env
```

### Create route to expose the app to outside world

```bash
$ oc create route edge --service=prod --insecure-policy=Redirect
```

You can list the routes using `oc get routes` and open the application in your browser.

## Deploying To Rahti(OKD) Using Web interface (UI)

### TODO: add deployment using web interface

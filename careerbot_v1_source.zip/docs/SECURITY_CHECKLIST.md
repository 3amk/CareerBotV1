# Security checklist

## Overview

This checklist is a combination of different security measures that should be taken when dealing with web servers, specially NodeJS server. The list is compiled from different sources, other checklists and [OWASP top 10](https://owasp.org/www-project-top-ten/). The list only contains measures that are relevant to this project at this time or are an immediate security requirement that needs to be implemented. This list is not an exhaustive list, it is here only as a starting point to implement the most common security practices. For reasons stated above, the list might be incomplete or lack other important security measures.

### Resources

- [OWASP Projects](https://owasp.org/projects/)
- [OWASP top 10](https://owasp.org/www-project-top-ten/)
- [OWASP Cheat Sheet Series](https://cheatsheetseries.owasp.org/Glossary.html)
- [ExpressJS best practices](https://expressjs.com/en/advanced/best-practice-security.html#use-cookies-securely)

---

## 1 General cases

### 1.1 Use strong secrets and store them safely

- Deploy the application and database with strong credentials and environmental variables.
- Store secrets(credentials) encrypted and inaccessible from any network connected devices.
- Remove default unnecessary access from all application e.g databases. This could be test or anonymous users/access.
- Do not commit files that contain secrets to code repositories e.g `.env`.
- Secrets must only be provided to the application in env vars at runtime.

**Implementation:** TODO: change database credentials and server environmental variables to strong hard to guess string of characters.

### 1.2 Secure transmission (HTTPS)

All tests or deployments other than local development must use HTTPS. As HTTP is clear text protocolo, anyone who can access the intermediate network between client and server can sniff the transferred data. Make sure the SSL certificate is valid and check if ciphers, Signature Algorithm, SSL version and key length are properly configured on the server.

**Implementation:** All deployments are using HTTPS and will redirect to HTTPS for all HTTP requests.

### 1.3 Check frameworks, libraries and packages are up-to-date

Make sure the latest packages and libraries are used. Monitor packages used on this project for new vulnerabilities. Use `npm audit` to fix and check for any known vulnerabilities.

**Implementation:** This is something that should be done periodically. At the time of writing all packages have been audited for critical vulnerabilities using npm, that is `npm audit`.

### 1.4 Set security HTTP headers and remove information that identify the technology used

Setting HTTP security headers can be useful to instruct the browser how to behave when communicating with the server and help mitigate some security concern.

**Implementation:** There are multiple ways to implement this, but since the 3AMK AI server is not behind another web server e.g (Apache or nginx), it is best to set the HTTP headers directly on ExpressJS. [Helmet](https://www.npmjs.com/package/helmet) package is used as middleware with defaults options, default options will set 11 default security headers.

Please note that this can break some of the functionality because of [CSP](https://developer.mozilla.org/en-US/docs/Web/HTTP/CSP). You can allow execution of JavaScript from certain sources by explicitly adding them to the script-src list if you wish.

**Connecting to other domains:** Connecting to other domains/APIs using `XMLHttpRequest` or other http tools e.g `axios` is not allowed by default. The desired domains have to be added to the `connect-src` list.

We also need to build react with `INLINE_RUNTIME_CHUNK=false` to prevent embedding of script into `index.html`. Refer to [CRA Advanced Configuration](https://create-react-app.dev/docs/advanced-configuration/)

Other parts of

### 1.5 Data validation and sanitization

Sanitize and validate all data coming from clients, input fields(HTML responses), or URL path or query parameter values to prevent XSS, SQL injection and CLI command injections. Implement data validation and sanitization both on client and server and Never rely on client side data validation or logic. Escape HTML, JS and CSS output.

**Implementation:** Continuous checks and data validations implementations on both client and server. The project uses Sequelize ORM library for database access(query) and it has built-in protection against injection attack. A lot of inputs are directly sent to Headai API from client applications without proxying to the 3AMK AI server and that leaves the server validation part for many HTML inputs(client inputs) to the Headai side.

### 1.6 Sensitive data exposure

In case of HTTP protocol (clear text) an attacker can steal sensitive user data while in transit, even though 3AMK AI server uses HTTPS it is absolutely important no sensitive data transferred to the client over the network in the first place.

**Implementation:** The most sensitive user data is `user id hash` that can be used to identify the user on Headai API and it is only sent to Headai API from server and never sent to client. The `user id hash` alone can not be used to access the user's data, it have to be used with the Headai developer token. Only sensitive data sent to client is user email address when user is signing up for the first time and user id on database when user is logged in, both this are sent as encrypted payload using AES encryption. The encryption of the payload is not necessary, because data will only be transferred over HTTPS which have its own protection, but since these values don't need to be displayed on the client side we encrypt them for extra precaution.

### 1.7 Denial of service and brute force attack

Prevent denial of service and brute force attack using rate limit.

**Implementation:**

    ❌ Unimplemented, Dev ops test and optimization not necessary on the development deployment right now. (It was agreed in meeting)
    TODO: Implement at least a simple rate limit based on IP address for fast consecutive HTTP requests (failed logins or failed authorization).

### 1.8 Error handling

The server can leak information about used technologies (libraries and framework) or other details of the server setup if an error stack trace is sent to the client. Send customized error messages on every level to clients to prevent information leak.

**Implementation:** The server application has extensive error handling on most modules(abstraction level) and error is propagated with customized messages on every module towards the outer middlewares until it is returned to the client. Most functions include `try...catch` statements and throw a custom errors when error occurs.

### 1.9 Logging and monitoring

Log all errors and database query for security audit and early discovery of attack surface. Save log entries on a separate server.

**Implementation:**

    ❌ Unimplemented,  A working solution has not been found  for using persistence volume outside of deployment cluster.
    TODO: find ways to save log files outside the server without using CSC persistent volume.

## 2. 3AMK AI Server specific cases

### 2.1 JSON Web Token (JWT) invalidation

**Problem:** 3AMK AI server uses JWT credentials for granting access. The JWT is signed with 1 day expiration time starting from issuing the token. Currently after the user click logout the frontend application will simply delete the JWT token. Browsers have security measures to prevent sharing of data of one domain with another domains, and ReactJS already have extensive measures against XSS on top of the added measures, yet this might not be enough if an attacker could get a hold of the JWT token. To prevent misuse of JWT tokens after a user is logged out, we need a way to invalidate an non expired token after a user is logged out. Some possible solutions for this problem includes:

**Solution 1:** Keep a list of blacklisted tokens. After a user clicks logout send JWT to the server and add it to a blacklist with expiration time equal to the JWT's expiration time. This will make the JWT stateful, but we have to keep a list of invalidated tokens instead of all tokens issued.

**Solution 2:** Use refresh token. Keep JWT expiration date minimum e.g 5 - 15 min and use refresh token to create new valid JWT. The refresh token could be valid for a long time e.g 1 - 5 days. This can be secured by saving the refresh token using HTTP only cookie and setting secure to `true`, thus ensuring the client does not have access to the refresh token. This solves the problem by reducing the expiration time of JWT.

**Use another authentication/authorization method:** Implement session based access using session id or use PassportJS. This is stateless authentication and will store the session id on memory or database. This uses the same strategy as saving the generated access credentials, but comes with defaults ways to secure the generated credentials. This will not be implemented to leverage an already implemented and tested strategy, and this strategy has its own disadvantages in regarding scaling and managing credentials across multiple containers.

**Implementation:** In order to keep the already implemented method of authentication and stateless nature of JWT, we will just add the generated token into HTTP only cookie without using refresh token and decrease the expiration time to `12 hour`.

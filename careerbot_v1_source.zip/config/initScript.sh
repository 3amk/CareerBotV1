#!/bin/sh
nginx
cd /project
pm2-runtime process.json
import { getURLWithQueryParams } from "../utils/helperFunctions";

// Base url for headai api
export const HEADAI_BASE_URL = "https://3amkapi.headai.com/microcompetencies";
export const ADD_NEW_COURSE = "https://headai.com/import_course/";
export const TERMS_AND_PRIVACY_URL =
    "https://www.3amk.fi/files/2023/02/Tietosuojaseloste-FI.pdf";
    // "https://www.laurea.fi/globalassets/laurea/documents/laurean-opiskelijatietojen-tietosuojaseloste-en.pdf";

// list of schools in course search page
export const SCHOOL_LIST = ["AMKosaaja", "Haaga-Helia", "Hamk", "Laurea", "Metropolia",  "Xamk"];

// keys for browser local storage
export const APP_SETTINGS_KEY = "appSettings";
export const AUTHENTICATION_DATA_KEY = "loggedUser";


export const HAKA_LOGIN_URL = process.env.REACT_APP_HAKA_LOGIN_URL;

export const HAKA_LOGOUT_URL = process.env.REACT_APP_HAKA_LOGOUT_URL;

// LinkedIn url constants
const LINKEDIN_BASE_URL = "https://www.linkedin.com/oauth/v2/authorization";
const LINKEDIN_SCOPE = "r_liteprofile r_emailaddress";
const LINKEDIN_CLIENT_ID = process.env.REACT_APP_LINKEDIN_ID;
const LINKEDIN_RIDERECT =
    process.env.NODE_ENV === "production"
        ? process.env.REACT_APP_LINKEDIN_REDIRECT_URI_PROD
        : process.env.REACT_APP_LINKEDIN_REDIRECT_URI_DEV;


export const LINKEDIN_FULL_URL = getURLWithQueryParams(LINKEDIN_BASE_URL, {
  response_type: "code",
  client_id: LINKEDIN_CLIENT_ID,
  redirect_uri: LINKEDIN_RIDERECT,
  scope: LINKEDIN_SCOPE,
});

// Google url constants
const GOOGLE_SCOPE = "https://www.googleapis.com/auth/userinfo.profile";
const GOOGLE_RIDERECT =
    process.env.NODE_ENV === "production"
        ? process.env.REACT_APP_GOOGLE_REDIRECT_URI_PROD
        : process.env.REACT_APP_GOOGLE_REDIRECT_URI_DEV;
export const GOOGLE_FULL_URL = `https://accounts.google.com/o/oauth2/v2/auth?
scope=${GOOGLE_SCOPE}&
access_type=offline&
include_granted_scopes=true&
response_type=code&
redirect_uri=${GOOGLE_RIDERECT}&
client_id=${process.env.REACT_APP_GOOGLE_CLIENT_ID}`;

import i18n from "i18next";
import LanguageDetector from "i18next-browser-languagedetector";
import { initReactI18next } from "react-i18next";
import englishLocales from "./locales/en/translation.json";
import finnishLocales from "./locales/fi/translation.json";

const DETECTION_OPTIONS = {
  order: ['localStorage', 'navigator'],
  caches: ['localStorage']
};

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    // Specify languages so en-US, en-GB etc do not continue to confuse the dropdown
    supportedLngs: ["en", "fi"],
    resources: {
      "en": englishLocales,
      "fi": finnishLocales,
    },
    detection: DETECTION_OPTIONS,
    /* When react i18next not finding any language to as default in borwser */
    fallbackLng: ["en", "fi"],
    /* default language when load the website in browser. Does not work, page refresh in anothe language and reverts to default language */
    // lng: "fi",
    /* debugger For Development environment */
    debug: true,
    ns: ["translations"],
    defaultNS: "translations",
    keySeparator: ".",
    interpolation: {
      escapeValue: false,
      formatSeparator: ",",
    },
    react: {
      bindI18n: "languageChanged loaded",
      bindStore: "added removed",
      nsMode: "default",
      // useSuspense: false,
    },
  });

export default i18n;

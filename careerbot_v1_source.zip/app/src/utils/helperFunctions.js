const enMonthsShort = [
  "JAN",
  "FEB",
  "MAR",
  "APR",
  "MAY",
  "JUN",
  "JUL",
  "AUG",
  "SEP",
  "OCT",
  "NOV",
  "DEC",
];

const finMonthsShort = [
  "tammi",
  "helmi",
  "maalis",
  "huhti",
  "touko",
  "kesä",
  "heinä",
  "elo",
  "syys",
  "loka",
  "marras",
  "joulu",
];

export const dateformat = (dateString, localeLang) => {
  try {
    if (dateString && localeLang) {
      const date = new Date(Date.parse(dateString.trim().replace(/ /g, "T")));
      if (localeLang.includes("fi")) {
        return `${date.getDate()} ${
          finMonthsShort[date.getMonth()]
        }, ${date.getFullYear()}`;
      } else {
        return `${
          enMonthsShort[date.getMonth()]
        } ${date.getDate()}, ${date.getFullYear()}`;
      }
    } else {
      return "";
    }
  } catch (error) {
    console.log("dateformat:", error.message);
  }
};

export const trimString = (str, strlength) => {
  if (str.length > strlength) {
    return `${str.substring(0, strlength)}...`;
  } else {
    return str;
  }
};

export const stringToArray = (str) =>
  str.split(",").filter((entry) => entry.trim() !== "");

// encode url parameters
// SOURCE: https://gist.github.com/RodionChachura/8e35af3948a039c9cd27f34079440956#file-generic-js
export const getURLWithQueryParams = (base, params) => {
  const query = Object.entries(params)
    .map(([key, value]) => `${key}=${encodeURIComponent(value)}`)
    .join("&");

  return `${base}?${query}`;
};

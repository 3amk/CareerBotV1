import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import { Button, Modal, Checkbox } from "semantic-ui-react";
import { saveUser } from "../../services/user";
import { TERMS_AND_PRIVACY_URL } from "../../constants/index.js";

const TermsModal = ({ modalOpen, onClose, updateLogin, esclation }) => {
  const { t } = useTranslation();

  const [buttonDisabled, setButtonDisabled] = useState(true);

  const handleCheckBox = (e, data) => {
    setButtonDisabled(!data.checked);
  };

  const acceptClick = async () => {
    const user = await saveUser(esclation.profile);
    if (user) {
      onClose();
      updateLogin(user.profile);
    }
  };

  return (
    <Modal
      size="small"
      open={modalOpen}
      onClose={onClose}
      closeOnDimmerClick={false}
    >
      <Modal.Header>{t("user.terms")}</Modal.Header>
      <Modal.Content scrolling>
        <Checkbox
          onChange={handleCheckBox}
          label={{
            children: (
              <>
                {t("user.termsAccept")}{" "}
                <a
                  href={TERMS_AND_PRIVACY_URL}
                  target="_blank"
                  rel="noreferrer"
                >
                  {t("user.terms")}
                </a>
              </>
            ),
          }}
        />
      </Modal.Content>
      <Modal.Actions>
        <Button primary disabled={buttonDisabled} onClick={acceptClick}>
          {t("user.accept")}
        </Button>
      </Modal.Actions>
    </Modal>
  );
};

export default TermsModal;

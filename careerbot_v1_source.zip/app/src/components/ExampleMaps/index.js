import React, { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { useSelector, useDispatch } from "react-redux";
import {
  Loader,
  Grid,
  Segment,
  Header,
  Form,
  Dropdown,
  Item,
  Label,
} from "semantic-ui-react";
import LoaderCube from "../../components/LoaderCube";

import MapVisualizer from "../MapVisualizer";
import NoResultSegement from "../NoResultSegment";

import { fetchExampleMaps } from "../../reducers/mapReducer";

const ExampleMaps = () => {
  const { t } = useTranslation();
  const dispatch = useDispatch();

  // example maps filter state
  const [filteredMaps, setFilteredMaps] = useState([]);

  // selected map state
  const [expandSelected, setexpandSelected] = useState(false);
  const [selectedMap, setSelectedMap] = useState({});

  const exampleMap = useSelector((state) => state.exampleMap);

  const mapFilterOptions = ["all", "education", "labor"].map((m, i) => ({
    key: i,
    text: t(`maps.${m}`),
    value: m,
  }));

  // fetch example maps if examplemap result is empty and it has not been loaded
  useEffect(() => {
    if (
      exampleMap.results.length === 0 &&
      !exampleMap.isLoaded &&
      !exampleMap.isLoading
    ) {
      dispatch(fetchExampleMaps());
    } else if (exampleMap.results.length > 0) {
      setFilteredMaps(exampleMap.results);
    }
  }, [exampleMap, dispatch]);

  const selectedMapHandler = (data, name, clusterCount) => {
    setSelectedMap({ data: data, mapName: name, count: clusterCount });
    setexpandSelected(!expandSelected);
  };

  // handle map type filter checkbox
  const mapFilterHandler = (e, { value }) => {
    if (value === "all") {
      setFilteredMaps(exampleMap.results);
    } else {
      const filtered = exampleMap.results.filter(
        (item) => item.type === value.toLowerCase()
      );
      setFilteredMaps(filtered);
    }
  };

  const hideWhenVisible = { display: expandSelected ? "none" : "" };
  const showWhenVisible = { display: expandSelected ? "" : "none" };

  return (
    <>
      {/* Show loading animation if example maps are loading */}
      {(exampleMap.isLoading || exampleMap.results.length < 0) && (
         <Segment style={{ border: "0px", boxShadow: "none", overflow: "hidden" }}>
         <LoaderCube />
         <div style={{ padding: "50px 0px 50px 0px" }}>
           <h4 className="loading-text">{t("maps.loading")}</h4>
           <p className="loading-message">{t("loading.loadingMessage")}</p>
         </div>  
       </Segment>
      )}

      {/* If no maps retured from server */}
      {exampleMap.isLoaded && exampleMap.results.length === 0 && (
        <NoResultSegement
          message={t("app.noexample")}
          icon="frown outline"
        />
      )}

      {/* iterate over maps filtered or all maps */}
      <div style={{ marginTop: "30px" }}>
        {filteredMaps.length > 0 && exampleMap.isLoaded && (
          <div style={hideWhenVisible}>
            <Grid stackable>
              <Grid.Row width={2}>
                <Grid.Column className="padless-column" width={4}>
                  <Segment attached="top">
                    <Header as="h4" content={t("app.filters")} />
                  </Segment>
                  <Segment attached>
                    <Form onSubmit={null}>
                      <Form.Group>
                        <Form.Field
                          width={16}
                          label={{
                            children: (
                              <label className="label">{t("maps.type")}</label>
                            ),
                          }}
                          control={Dropdown}
                          selection
                          fluid
                          selectOnBlur={false}
                          defaultValue={"all"}
                          options={mapFilterOptions}
                          onChange={mapFilterHandler}
                        />
                      </Form.Group>
                    </Form>
                  </Segment>
                </Grid.Column>
                <Grid.Column className="padless-column" width={12}>
                  <Segment attached="top">
                    <Header
                      as="h4"
                      content={filteredMaps.length + " " + t("maps.exampleMaps")}
                    />
                  </Segment>
                  <Segment attached>
                    <Item.Group relaxed unstackable divided>
                      {filteredMaps.map((map, i) => (
                        <Item
                          onClick={(e) => {
                            selectedMapHandler(
                              map.finalData,
                              map.name,
                              map.clusterCount
                            );
                          }}
                          key={i}
                        >
                          <Item.Content className="overflow-fix">
                            <Item.Header as="a">{map.name}</Item.Header>
                            <Item.Extra>
                              <Label content={t(`maps.${map.type}`)} />
                            </Item.Extra>
                            <Item.Meta>{t("maps.cluster") + t("maps.clusterNext")}: {map.clusterCount}</Item.Meta>
                            <Item.Meta>
                            {t("maps.labels")}: {map.finalData.length}
                            </Item.Meta>
                          </Item.Content>
                        </Item>
                      ))}
                    </Item.Group>
                  </Segment>
                </Grid.Column>
              </Grid.Row>
            </Grid>
          </div>
        )}
        <div style={showWhenVisible}>
          <MapVisualizer
            selectedMap={selectedMap}
            toggleVisibility={() => setexpandSelected(!expandSelected)}
            isExample
          />
        </div>
      </div>
    </>
  );
};

export default ExampleMaps;

import React from 'react'
import { useTranslation } from 'react-i18next'
import { Modal, Loader } from 'semantic-ui-react'
import LoaderCube from "../../components/LoaderCube/LoaderCubeMini.js";

import CourseList from '../CourseList'

const CourseModal = ({ courseModalOpen, closeCourseModal, courses, skill }) => {
  const { t } = useTranslation()
  return (
    <Modal
      open={courseModalOpen}
      onClose={closeCourseModal}
      centered={true}
      closeIcon
    >
      <Modal.Header>
        {t('courses.availableCourses')} {skill}
      </Modal.Header>
      <Modal.Content 
        style={{ maxHeight: "40vh" }}
        scrolling
        >
        {courses.isLoading && (
          <LoaderCube />
          // <Loader active size="big">
          //   Loading...
          // </Loader>
        )}
        <CourseList courses={courses.list} isLoading={courses.isLoading} />
      </Modal.Content>
    </Modal>
  )
}

export default CourseModal

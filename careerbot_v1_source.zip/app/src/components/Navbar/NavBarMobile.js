import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import {
  Button,
  Header,
  Icon,
  Image,
  Menu,
  Segment,
  Sidebar,
} from "semantic-ui-react";
import { Link, useLocation } from "react-router-dom";
import { useDispatch } from "react-redux";
import { openLoginModal } from "../../reducers/loginModalReducer";
import { logoutUser } from "../../reducers/userReducer";
import LanguageDropdown from "../LanguageDropdown";
import logoImage from "../../public/images/3amk-header-banner.png";

import "./Navbar.css";

const NavBarMobile = ({ children, user }) => {
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const location = useLocation();

  const [visible, setVisible] = useState(false);
  // const toggleVisiblity = () => setVisible(!visible);
  const openSideBar = () => setVisible(true);
  const closeSideBar = () => setVisible(false);

  return (
    <>
      <Sidebar.Pushable>
        <Sidebar
          as={Menu}
          animation="overlay"
          direction="right"
          vertical
          visible={visible}
          onHide={closeSideBar}
          style={{ backgroundColor: "white" }}
        >
          <div className="navbar-mobile">
            <Menu.Item header style={{ margin: "-4px 0 -4px 0" }}>
              <Image
                size="small"
                spaced="right"
                src={logoImage}
                alt="logo"
                style={{ imageRendering: "high-quality" }}
              />
              <Button
                className="humberger"
                icon
                basic
                size="big"
                onClick={closeSideBar}
                floated="right"
              >
                <Icon name="close" size="large" />
              </Button>
            </Menu.Item>
            <Menu.Item
              as={Link}
              onClick={closeSideBar}
              active={location.pathname === "/"}
              to="/"
              name={t("nav.home")}
            ></Menu.Item>
            <Menu.Item
              as={Link}
              onClick={closeSideBar}
              active={location.pathname === "/skills_profile"}
              to="/skills_profile"
              name={t("nav.profile")}
            ></Menu.Item>
            <Menu.Item
              as={Link}
              onClick={closeSideBar}
              active={location.pathname === "/jobs"}
              to="/jobs"
              name={t("nav.job")}
            ></Menu.Item>
            <Menu.Item
              as={Link}
              onClick={closeSideBar}
              active={location.pathname === "/courses"}
              to="/courses"
              name={t("nav.courses")}
            ></Menu.Item>
            <Menu.Item
              as={Link}
              onClick={closeSideBar}
              active={location.pathname === "/maps"}
              to="/maps"
              name={t("nav.maps")}
            ></Menu.Item>
            <Menu.Item
              as={Link}
              onClick={closeSideBar}
              active={location.pathname === "/theseus"}
              to="/theseus"
              name={t("nav.theses")}
            ></Menu.Item>
            {user.isAuthorised && (
              <Menu.Item>
                <Header
                  icon="user"
                  content={`${t("user.welcome")}, ${user.data.firstName}!`}
                  as="h4"
                />
              </Menu.Item>
            )}
            <Menu.Item>
              <div>
                {user.isAuthorised ? (
                  <Button
                    // size="big"
                    color="blue"
                    basic
                    content={t("user.logout")}
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      closeSideBar();
                      dispatch(logoutUser());
                    }}
                  />
                ) : (
                  <Button
                    className="loginButton"
                    // size="big"
                    color="blue"
                    content={t("user.login")}
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      closeSideBar();
                      dispatch(openLoginModal());
                    }}
                  />
                )}
              </div>
            </Menu.Item>
            <Menu.Item>
              <LanguageDropdown />
            </Menu.Item>
          </div>
        </Sidebar>

        <Sidebar.Pusher dimmed={visible}>
          <Segment className="clear-margin" clearing textAlign="center">
            <Image
              size="small"
              src={logoImage}
              spaced
              alt="logo"
            />
            <Button
              className="humberger"
              icon
              basic
              floated="right"
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                openSideBar();
              }}
            >
              <Icon name="sidebar" size="big" />
            </Button>
          </Segment>
          {children}
        </Sidebar.Pusher>
      </Sidebar.Pushable>
    </>
  );
};

export default NavBarMobile;

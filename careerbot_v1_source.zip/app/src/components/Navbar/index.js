import React from "react";
import { Responsive, Button } from "semantic-ui-react";
import NavBarDesktop from "./NavBarDesktop";
import NavBarMobile from "./NavBarMobile";
import Footer from "../../components/Footer";
import "./Navbar.css";

const NavBarChildren = ({ children }) => (
  <>
    <div className="nav-container">{children}</div>
    <Footer />
  </>
);

const NavBar = ({ children, user }) => {
  return (
    <div>
      <Responsive {...Responsive.onlyMobile}>
        <NavBarMobile user={user}>
          <NavBarChildren>{children}</NavBarChildren>
        </NavBarMobile>
      </Responsive>
      <Responsive minWidth={Responsive.onlyTablet.minWidth}>
        <NavBarDesktop user={user} />
        <NavBarChildren>{children}</NavBarChildren>
      </Responsive>
    </div>
  );
};

export default NavBar;

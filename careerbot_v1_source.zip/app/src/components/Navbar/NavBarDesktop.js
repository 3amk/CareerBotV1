import React from "react";
import { useTranslation } from "react-i18next";
import { Link, NavLink } from "react-router-dom";
import { useDispatch } from "react-redux";

import UserDropdown from "../UserDropdown";
import LanguageDropdown from "../LanguageDropdown";
import { openLoginModal } from "../../reducers/loginModalReducer";
import { logoutUser } from "../../reducers/userReducer";
import "./Navbar.css";
import logoImage from "../../public/images/3amk-header-banner.png";
import { Button, Image } from "semantic-ui-react";

const NavBarDesktop = ({ user }) => {
  const { t } = useTranslation();
  const scrollTop = () => {
    window.scrollTo(0, 0);
  };

  //dispatch opeLoginModal, logoutUser
  const dispatch = useDispatch();

  return (
    <nav className="nav" onClick={scrollTop}>
      <Image
        size="small"
        spaced="right"
        src={logoImage}
        alt="logo"
        style={{ imageRendering: "high-quality" }}
      />
      <NavLink as={Link} exact to="/" activeClassName="navbar-active">
        {t("nav.home")}
      </NavLink>

      <NavLink to="/skills_profile" exact activeClassName="navbar-active">
        {t("nav.profile")}
      </NavLink>

      <NavLink to="/jobs" exact activeClassName="navbar-active">
        {t("nav.job")}
      </NavLink>

      <NavLink to="/courses" exact activeClassName="navbar-active">
        {t("nav.courses")}
      </NavLink>

      <NavLink to="/maps" exact activeClassName="navbar-active">
        {t("nav.maps")}
      </NavLink>
      <NavLink to="/theseus" exact activeClassName="navbar-active">
      {t("nav.theses")}
      </NavLink>
      <div className="nav-lang">
        <LanguageDropdown />
      </div>
      <div className="nav-user">
        {user.isAuthorised ? (
          <UserDropdown
            user={user.data.firstName}
            handleLogout={() => dispatch(logoutUser())}
          />
        ) : (
          <Button
            style={{ whiteSpace: "noWrap" }}
            color="blue"
            onClick={(e, d) => {
              e.preventDefault();
              dispatch(openLoginModal());
            }}
          >
            {t("user.login")}
          </Button>
        )}
      </div>
    </nav>
  );
};

export default NavBarDesktop;

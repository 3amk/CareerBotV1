import React, { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { useDispatch } from "react-redux";
import {
  Button,
  Checkbox,
  Form,
  Grid,
  Header,
  Loader,
  Segment,
  Popup,
  Icon,
  Modal,
  Label,
} from "semantic-ui-react";
import TheseusGraph from "../TheseusGraph";
import {getTheseus, getArticle} from "../../reducers/theseusReducer";
import NoResultSegment from "../NoResultSegment";
import { FullScreen, useFullScreenHandle } from "react-full-screen";
import LoaderCube from "../../components/LoaderCube";
import { scaleBand } from "d3-scale";

const ThesisKeywordContainer = ({ results, resultsOriginal, isEmpty, theseusType, globalType, isLoading, loaded }) => {
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const handleFullscreen = useFullScreenHandle();

  const trendOptions = [
    {
      value: "keywords",
      label: t("theseus.showKeywordsTrends"),
      disabled: results?.data?.length === 0 ?? true,
    },
    {
      value: "related",
      label: t("theseus.showRelatedTrends"),
      disabled: results?.relations?.length === 0 ?? true,
    },
  ];

  const [hoverKeyword, setHoverKeyword] = useState(null);
  const [selectedWords, setSelectedWords] = useState([]);
  const [selectedTrends, setSelectedTrends] = useState(trendOptions[0].value);
  const [trendData, setTrendData] = useState([]);
  const [open, setOpen] = useState(false);
  const [futurePrediction, setFuturePrediction] = useState(true);
  const [theseusTypeLocal, setTheseusTypeLocal] = useState(true);
  const [globalTypeLocal, setGlobalTypeLocal] = useState(false);
  const [isEmptyLocal, setIsEmptyLocal] = useState(false);
  const [scaleValue, setScaleValue] = useState();
  const [yValue, setYValue] = useState();
  // const [selectedTrendWords, setSelectedTrendWords] = useState([])
  const [ dimensions, setDimensions ] = useState({
    width: window.innerWidth
  });

  useEffect(() => {
    setTrendData([]);
    setIsEmptyLocal(true);
  },[theseusType])

  useEffect(() => {
    function handleResize() {
      setDimensions({
        width: window.innerWidth
      })
    }
    window.addEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    if (results.data && results.data.length > 0) {
      setSelectedTrends(trendOptions[0].value);
      
    setTheseusTypeLocal(theseusType);
    setGlobalTypeLocal(globalType);
    setIsEmptyLocal(isEmpty);
      
      setTrendData(results.data);

      setFuturePrediction(true);
      // selectedTrends(results.data.map((d) => d.word));
    } 

    if (results.data.length > 22  && results.data.length < 31) {
      setScaleValue(60);
      setYValue(35);
    } 
    else if (results.data.length > 31) {
      setScaleValue(40);
      setYValue(75);
    } 
    else {
      setScaleValue(70);
      setYValue(20);
    }

  }, [resultsOriginal]);

  const handleHover = (keyword, trendGroup) => {
    if (trendGroup === selectedTrends && hoverKeyword !== keyword)
      setHoverKeyword(keyword);
  };

  const exitHover = () => {
    setHoverKeyword(null);
  };

  const handleTrends = (e, { value }) => {
    setSelectedTrends(value);

    if (value === trendOptions[0].value) {
      setTrendData(results.data);
    } else {
      setTrendData(results.relations);
    }
  };

  const checkedWordHandler = (e, data) => {
    if (data.checked) {
      setSelectedWords([...new Set([...selectedWords, data.value])]);
    } else {
      let key = selectedWords.filter((word) => word !== data.value);
      setSelectedWords(key);
    }
  };

  const thesisSearchHandler = () => {
    if (selectedWords.length > 0) {
      const keywords = selectedWords.toString();
      if(theseusType==true){
      dispatch(getTheseus(keywords));
    }
    else if(globalType==true){
      dispatch(getArticle(keywords));
    }
    }
    setSelectedWords([]);
  };
  
  if(theseusTypeLocal==true){
  return (
    <>
    {isLoading ? (
      <Segment style={{ border: "0px", boxShadow: "none", overflow: "hidden" }}>
        <LoaderCube />
        <div style={{ padding: "50px 0px 50px 0px" }}>
          <h4 className="loading-text">{t("theseus.spinner")}</h4>
          <p className="loading-message">{t("loading.loadingMessage")}</p>
        </div>
      </Segment>
    ) : isEmptyLocal != true ? (
      <Grid stackable>
        <Grid.Row width={2} reversed="computer" >
          <Grid.Column className="padless-column" width={12} stretched>
            <FullScreen className="fullScreen" handle={handleFullscreen}>
              <Segment.Group style={{ backgroundColor: "white", position: "relative" }}>
                <Segment clearing attached="top" style={{ maxHeight: "47px" }}>
                  {/* If device width is Mobile size, modal button displayed, otherwise full screen button displayed. iOS on smaller devices does not support full screen mode */}
                  {!handleFullscreen.active && dimensions.width < 1500 ? (
                    <>
                      <Button
                        size="small"
                        basic
                        compact
                        icon
                        labelPosition="right"
                        onClick={() => setOpen(true)}
                        floated="right"
                        style={{ borderRadius: 9, marginTop: "-5px" }}
                      >
                        <Icon name="expand" />
                        {t("theseus.expand")}
                      </Button>
                        <h4 style={{ marginTop: "0px" }}>{t("theseus.graph")} 
                          <Popup
                            on="click"
                            trigger={<Icon color="grey" name="question circle" />}
                            content={t("popup.graph")}
                            // position="right center"
                          />
                      </h4>
                    </>
                  ) : !handleFullscreen.active && dimensions.width > 1500 ? (
                    <>     
                      <Button
                        size="small"
                        basic
                        compact
                        icon
                        labelPosition="right"
                        onClick={handleFullscreen.enter}
                        floated="right"
                        style={{ borderRadius: 9, marginTop: "-5px" }}
                      >
                        <Icon name="expand" />
                          {t("theseus.fullScreen")}
                      </Button>
                        <h4 style={{ marginTop: "0px" }}>{t("theseus.graph")} 
                          <Popup
                            on="click"
                            trigger={<Icon color="grey" name="question circle" />}
                            content={t("popup.graph")}
                            // position="right center"
                          />
                      </h4>
                    </>
                  ) : (
                    <div>
                      {/* Close button for full screen */}
                      <Button
                        size="small"
                        basic
                        compact
                        icon
                        labelPosition="right"
                        onClick={handleFullscreen.exit}
                        floated="right"
                        style={{ borderRadius: 9, marginTop: "-5px" }}
                      >
                      {t("theseus.close")}
                        <Icon name="close" />
                      </Button>
                        <h4 style={{ marginTop: "0px" }}>{t("theseus.graph")}
                        </h4>
                    </div>
                  )}
                </Segment>
                <Segment clearing attached style={{ maxHeight: "85px" }}>
                <Checkbox 
                  toggle 
                  // label="Show Predictions"
                  defaultChecked={true}
                  style={{ float: "right", marginBottom: "-20px" }}
                  onClick={(e, data) => setFuturePrediction(data.checked)} 
                  
                />
                  <label style={{ float: "right", margin: "0 20px -20px" }}>{t("theseus.predict")}</label>
                  <Form>
                    {trendOptions.map((trend, i) => (
                      <Form.Field floated="right" key={i}>
                        <Checkbox
                          radio
                          label={trend.label}
                          name="checkboxRadioGroup"
                          value={trend.value}
                          checked={selectedTrends === trend.value}
                          onChange={handleTrends}
                          disabled={trend.disabled}
                        />
                      </Form.Field>
                    ))}

                  </Form>
                </Segment>
                <Segment attached>
                  {!isLoading && !handleFullscreen.active && open == false ? (
                    <>
                    {trendData.length > 0 && (
                      <TheseusGraph data={trendData} theseusType={theseusType} globalType={globalType} hoverKeyword={hoverKeyword} futurePrediction={futurePrediction} />
                      )}
                    </>
                  ) : open == true ? (
                    <>
                    {trendData.length > 0 && (
                      <div>
                        <Modal 
                          onClose={() => setOpen(false)}
                          onOpen={() => setOpen(true)}
                          open={open}

                          style={{ maxWidth: "80%", marginTop: "-3px" }}
                          centered="true"
                        >
                          <div style={{  padding: "5px" }}>
                            <Icon name="close" onClick={() => setOpen(false)} size="large" style={{ float: "right", cursor: "pointer" }} />
                              <TheseusGraph data={trendData} theseusType={theseusType} globalType={globalType} hoverKeyword={hoverKeyword} futurePrediction={futurePrediction} />
                          </div>
                        </Modal>
                      </div>
                    )}
                    </>
                  ) : (
                    <>
                    {trendData.length > 0 && (
                      <div style={{ transform: `scale(${scaleValue}%) translateY(-${yValue}%)`, WebkitTransform: `scale(0.${scaleValue}) translateY(-${yValue}%)` }}>
                        <TheseusGraph data={trendData} theseusType={theseusType} globalType={globalType} hoverKeyword={hoverKeyword} futurePrediction={futurePrediction} style={{ maxHeight: "30vh" }} />
                      </div>
                    )}
                    </>
                  )}
                  </Segment>
                    {/* Full screen loader on SVG */}
                    {isLoading && handleFullscreen.active && (
                      <div style={{ padding: "20% 0% 0% 0%" }}>
                        <LoaderCube />
                      </div>
                    )}
              </Segment.Group>
            </FullScreen>
          </Grid.Column>
          <Grid.Column className="padless-column" width={4} stretched>
            <Segment.Group style={{ backgroundColor: "white" }}>
              <Segment>
                <Header as="h4" content={t("theseus.parameters")} />
              </Segment>
              <Segment>
                <Header as="h4" content={t("theseus.keywords")} />
                {results.data &&
                  results.data.map((item, i) => (
                    <div
                      key={i}
                      onMouseEnter={() =>
                        handleHover(item.word, trendOptions[0].value)
                      }
                      onMouseLeave={exitHover}
                    >
                      <Checkbox
                        label={item.word.replace(/[^a-zA-Z ]/g, " ")}
                        value={item.word}
                        onChange={checkedWordHandler}
                        checked={selectedWords.includes(item.word)}
                      />
                    </div>
                  ))}
              </Segment>
              <Segment>
                <Header as="h4" content={t("theseus.related")} />
                {results.relations &&
                  results.relations.map((item, i) => (
                    <div
                      key={i}
                      onMouseEnter={() =>
                        handleHover(item.word, trendOptions[1].value)
                      }
                      onMouseLeave={exitHover}
                    >
                      <Checkbox
                        label={item.word}
                        value={item.word}
                        onChange={checkedWordHandler}
                        checked={selectedWords.includes(item.word)}
                      />
                    </div>
                  ))}
              </Segment>
              <Segment clearing>
                <Header
                  as="h4"
                  content={t("theseus.relatedThesis")}
                />
                <Button
                  color="blue"
                  style={{ whiteSpace: "noWrap" }}
                  disabled={selectedWords.length <= 0}
                  onClick={thesisSearchHandler}
                  content={t("theseus.searchThesis")}
                  floated="right"
                />
              </Segment>
            </Segment.Group>
          </Grid.Column>
        </Grid.Row>
      </Grid>
    ) : (
      <>
        <div/>
      </>
    )}
  </>
);
};
if(globalTypeLocal==true){
  return (
    <>
    {isLoading ? (
      <Segment style={{ border: "0px", boxShadow: "none", overflow: "hidden" }}>
        <LoaderCube />
        <div style={{ padding: "50px 0px 50px 0px" }}>
          <h4 className="loading-text">{t("theseus.spinner")}</h4>
          <p className="loading-message">{t("loading.loadingMessage")}</p>
        </div>
      </Segment>
    ) : isEmptyLocal != true ? (
      <Grid stackable>
        <Grid.Row width={2} reversed="computer" >
          <Grid.Column className="padless-column" width={12} stretched>
            <FullScreen className="fullScreen" handle={handleFullscreen}>
              <Segment.Group style={{ backgroundColor: "white", position: "relative" }}>
                <Segment clearing attached="top" style={{ maxHeight: "47px" }}>
                  {/* If device width is Mobile size, modal button displayed, otherwise full screen button displayed. iOS on smaller devices does not support full screen mode */}
                  {!handleFullscreen.active && dimensions.width < 1500 ? (
                    <>
                      <Button
                        size="small"
                        basic
                        compact
                        icon
                        labelPosition="right"
                        onClick={() => setOpen(true)}
                        floated="right"
                        style={{ borderRadius: 9, marginTop: "-5px" }}
                      >
                        <Icon name="expand" />
                        {t("theseus.expand")}
                      </Button>
                        <h4 style={{ marginTop: "0px" }}>{t("theseus.graph")} 
                          <Popup
                            on="click"
                            trigger={<Icon color="grey" name="question circle" />}
                            content={t("popup.graph")}
                            // position="right center"
                          />
                      </h4>
                    </>
                  ) : !handleFullscreen.active && dimensions.width > 1500 ? (
                    <>     
                      <Button
                        size="small"
                        basic
                        compact
                        icon
                        labelPosition="right"
                        onClick={handleFullscreen.enter}
                        floated="right"
                        style={{ borderRadius: 9, marginTop: "-5px" }}
                      >
                        <Icon name="expand" />
                          {t("theseus.fullScreen")}
                      </Button>
                        <h4 style={{ marginTop: "0px" }}>{t("theseus.graph")} 
                          <Popup
                            on="click"
                            trigger={<Icon color="grey" name="question circle" />}
                            content={t("popup.graph")}
                            // position="right center"
                          />
                      </h4>
                    </>
                  ) : (
                    <div>
                      {/* Close button for full screen */}
                      <Button
                        size="small"
                        basic
                        compact
                        icon
                        labelPosition="right"
                        onClick={handleFullscreen.exit}
                        floated="right"
                        style={{ borderRadius: 9, marginTop: "-5px" }}
                      >
                      {t("theseus.close")}
                        <Icon name="close" />
                      </Button>
                        <h4 style={{ marginTop: "0px" }}>{t("theseus.graph")}
                        </h4>
                    </div>
                  )}
                </Segment>
                <Segment clearing attached style={{ maxHeight: "85px" }}>
                <Checkbox 
                  toggle 
                  // label="Show Predictions"
                  defaultChecked={true}
                  style={{ float: "right", marginBottom: "-20px" }}
                  onClick={(e, data) => setFuturePrediction(data.checked)} 
                  
                />
                  <label style={{ float: "right", margin: "0 20px -20px" }}>{t("theseus.predict")}</label>
                  <Form>
                    {trendOptions.map((trend, i) => (
                      <Form.Field floated="right" key={i}>
                        <Checkbox
                          radio
                          label={trend.label}
                          name="checkboxRadioGroup"
                          value={trend.value}
                          checked={selectedTrends === trend.value}
                          onChange={handleTrends}
                          disabled={trend.disabled}
                        />
                      </Form.Field>
                    ))}

                  </Form>
                </Segment>
                <Segment attached>
                  {!isLoading && !handleFullscreen.active && open == false ? (
                    <>
                    {trendData.length > 0 && (
                      <TheseusGraph data={trendData} theseusType={theseusType} globalType={globalType} hoverKeyword={hoverKeyword} futurePrediction={futurePrediction} />
                      )}
                    </>
                  ) : open == true ? (
                    <>
                    {trendData.length > 0 && (
                      <div>
                        <Modal 
                          onClose={() => setOpen(false)}
                          onOpen={() => setOpen(true)}
                          open={open}

                          style={{ maxWidth: "80%", marginTop: "-3px" }}
                          centered="true"
                        >
                          <div style={{  padding: "5px" }}>
                            <Icon name="close" onClick={() => setOpen(false)} size="large" style={{ float: "right", cursor: "pointer" }} />
                              <TheseusGraph data={trendData} theseusType={theseusType} globalType={globalType} hoverKeyword={hoverKeyword} futurePrediction={futurePrediction} />
                          </div>
                        </Modal>
                      </div>
                    )}
                    </>
                  ) : (
                    <>
                    {trendData.length > 0 && (
                      <div style={{ transform: `scale(${scaleValue}%) translateY(-${yValue}%)`, WebkitTransform: `scale(0.${scaleValue}) translateY(-${yValue}%)` }}>
                        <TheseusGraph data={trendData} theseusType={theseusType} globalType={globalType} hoverKeyword={hoverKeyword} futurePrediction={futurePrediction} style={{ maxHeight: "30vh" }} />
                      </div>
                    )}
                    </>
                  )}
                  </Segment>
                    {/* Full screen loader on SVG */}
                    {isLoading && handleFullscreen.active && (
                      <div style={{ padding: "20% 0% 0% 0%" }}>
                        <LoaderCube />
                      </div>
                    )}
              </Segment.Group>
            </FullScreen>
          </Grid.Column>
          <Grid.Column className="padless-column" width={4} stretched>
            <Segment.Group style={{ backgroundColor: "white" }}>
              <Segment>
                <Header as="h4" content={t("theseus.parameters")} />
              </Segment>
              <Segment>
                <Header as="h4" content={t("theseus.keywords")} />
                {results.data &&
                  results.data.map((item, i) => (
                    <div
                      key={i}
                      onMouseEnter={() =>
                        handleHover(item.word, trendOptions[0].value)
                      }
                      onMouseLeave={exitHover}
                    >
                      <Checkbox
                        label={item.word.replace(/[^a-zA-Z ]/g, " ")}
                        value={item.word}
                        onChange={checkedWordHandler}
                        checked={selectedWords.includes(item.word)}
                      />
                    </div>
                  ))}
              </Segment>
              <Segment>
                <Header as="h4" content={t("theseus.related")} />
                {results.relations &&
                  results.relations.map((item, i) => (
                    <div
                      key={i}
                      onMouseEnter={() =>
                        handleHover(item.word, trendOptions[1].value)
                      }
                      onMouseLeave={exitHover}
                    >
                      <Checkbox
                        label={item.word}
                        value={item.word}
                        onChange={checkedWordHandler}
                        checked={selectedWords.includes(item.word)}
                      />
                    </div>
                  ))}
              </Segment>
              <Segment clearing>
                <Header
                  as="h4"
                  content={t("theseus.relatedArticle")}
                />
                <Button
                  color="blue"
                  style={{ whiteSpace: "noWrap" }}
                  disabled={selectedWords.length <= 0}
                  onClick={thesisSearchHandler}
                  content={t("theseus.searchArticle")}
                  floated="right"
                />
              </Segment>
            </Segment.Group>
          </Grid.Column>
        </Grid.Row>
      </Grid>
    ) : (
      <>
        <div/>
      </>
    )}
  </>
);
}
};

export default ThesisKeywordContainer;
import React, { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { useDispatch, useSelector } from "react-redux";
import {
  Button,
  Loader,
  Grid,
  Segment,
  Header,
  Form,
  Select,
  Item,
  Label,
} from "semantic-ui-react";

import { getMapList, deleteMap, requestMap } from "../../services/maps";
import { setNotification } from "../../reducers/notificationReducer";
import { openLoginModal } from "../../reducers/loginModalReducer";
import { getProfileData } from "../../services/skillsProfile";

import { getProfile } from "../../reducers/profileDataReducer";

import MapVisualizer from "../MapVisualizer";
import EmptySegment from "../EmptySegment";
import ConformationModal from "../ConformationModal";
import secureLoginImg from "../../public/images/secure_login.svg";
import LoaderCube from "../../components/LoaderCube";

import "./Maplist.css";
import MapsPage from "../../pages/MapsPage";
import { dateformat } from "../../utils/helperFunctions";

const MapList = () => {
  const { t } = useTranslation();
  const dispatch = useDispatch();

  const user = useSelector((state) => state.user);

  const [mapList, setMapList] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isCalculating, setIsCalculating] = useState(false);

  const [expandSelected, setexpandSelected] = useState(false);
  const [selectedMap, setSelectedMap] = useState({});

  const [selectedProfile, setSelectedProfile] = useState("");
  const [profileError, setProfileError] = useState(null);
  const profiles = useSelector((state) => state.profiles);
  const [deleteConfirm, setDeleteConfirm] = useState({ open: false, id: null });
  const profileDatas = useSelector((state) => state.profileData);
  let intervalTimeout;

  useEffect(() => {
    if (
      user.isAuthorised &&
      selectedProfile !== null &&
      profileDatas[selectedProfile] === undefined
    ) {
      let data =selectedProfile;
      let buff = new Buffer(data);
      let encodedProfileName = buff.toString('base64');

      //dispatch(getProfile(encodedProfileName));
    }
  }, [selectedProfile, profileDatas, dispatch]);

  const handleProfileChange = (e, data) => {
    if (user.isAuthorised && data.value) {
      setSelectedProfile(data.value);
    } else {
      setSelectedProfile(null);
    }
  };

  // const handleProfileChange = (e, data) => {
  //   if (data.value !== selectedProfile) {
  //     setSelectedProfile(data.value);
  //     if (profileError) setProfileError(null);
  //   }
  // };
  const refreshPage =() => {
    //window.alert("Please refresh the page to see the current status of your maps");;
    //window.location.reload(false); 
    //console.log("refreshing")
  }
    //window.alert("Please refresh the page to see the current status of your maps");*/



  const handleCreateMap = async () => {
    if (!selectedProfile) {
      return setProfileError({
        content: t("error.mapError"),
        pointing: "below",
      });
    }
    //let profileData = profileDatas[selectedProfile];
    let profileData;
    if (!profileData) {
      let data =selectedProfile;
      let buff = new Buffer(data);
      let encodedProfileName = buff.toString('base64');
      profileData = await getProfileData(encodedProfileName);
    }
    // NOTE: Need to cheak if we same json for sending a map a new profile and old profile ...
    // ... check output of "await getProfileData(encodedProfileName)"";
    if (profileData && (profileData.data.include_skills.length > 1)) {
      requestMap(selectedProfile);
      dispatch(
        setNotification(
          `${t("notification.sendCalculation")} "${selectedProfile}"`,
          5,
          "success"
        )
      );
      setSelectedProfile("");
      setIsCalculating(true);
      intervalTimeout = setInterval(() => {
        // refreshPage();
        setIsCalculating(false);

        getMapList().then((data) => {
          if(!data.some(x=>x.status == "Calculating"))
          {
              clearInterval(intervalTimeout);
          }
          setMapList(data);
        });
      }, 5000);

    } else {
      dispatch(
        setNotification(
          `"${selectedProfile}" ${t("notification.nodata")}`,
          5,
          "error"
        )
      );
    }
  };

  // Dropdown organiser, newest profile appears first. uses API's id
  const reformattedData = profiles.sort((a,b) => (a.id < b.id));
  const profileOptions = reformattedData.map((profile) => ({
    key: profile.id,
    value: profile.name,
    text: profile.name,
  }));

  useEffect(() => {
    // mounted variable used to possible prevent data leaks(prevent setting data on unmounted component)
    let mounted = true;
    if (user.isAuthorised) {
      setIsLoading(true);
      getMapList().then((data) => {
        if (mounted) setMapList(data);
        setIsLoading(false);
      });
    } else {
      setIsLoading(false);
      setMapList([]);
    }
    return () => {
      mounted = false;
    };
        
  }, [user.isAuthorised]);

  const deleteMapHandler = async () => {
    const id = deleteConfirm.id;
    setDeleteConfirm({ open: false, id: null });
    const removed = await deleteMap(id);
    if (removed && removed.data) {
      const updadatedList = mapList.filter((list) => list.data.map_id !== id);
      setMapList(updadatedList);
      dispatch(setNotification(`${removed.data}`, 5, "success"));
    } else {
      /*
       * This error only happens when trying to delete empty maps,
       * which is already fixed by not creating maps for empty skill profiles,
       * this is here for compatibility
       */
      dispatch(setNotification(`Error: can not delete map`, 5, "error"));
    }
  };

  /*window.setTimeout(function () {
    window.location.reload();
  }, 10000);*/

  const selectedMapHandler = (id, name) => {
    setSelectedMap({ id: id, mapName: name });
    setexpandSelected(!expandSelected);
  };

  const hideWhenExpanded = { display: expandSelected ? "none" : "" };
  const showWhenSelected = { display: expandSelected ? "" : "none" };

  return (
    <div style={{ marginTop: "30px" }}>
      {isLoading && (
        <Segment style={{ border: "0px", boxShadow: "none", overflow: "hidden" }}>
          <LoaderCube />
          <div style={{ padding: "50px 0px 50px 0px" }}>
            <h4 className="loading-text">{t("maps.loading")}</h4>
            <p className="loading-message">{t("loading.loadingMessage")}</p>
          </div>  
        </Segment>
      )}
      {isCalculating && (
        <Segment style={{ border: "0px", boxShadow: "none", overflow: "hidden" }}>
          <LoaderCube />
          <div style={{ padding: "50px 0px 50px 0px" }}>
            <h4 className="loading-text">{t("maps.calculateMap")}</h4>
            <p className="loading-message">{t("maps.calculationWarning")}</p>
          </div>  
        </Segment>
      )}
      {/* if there is no user maps show no maps */}
      {/* {!isLoading && mapList.length === 0 && <p>{t("maps.noMaps")}</p>} */}
      {!user.isAuthorised && !isLoading && mapList.length == 0 && (
        <EmptySegment
          image={secureLoginImg}
          title={t("app.notLoggedIn")}
          content={t("maps.unauthorisedText")}
          btnText={t("loginForm.title")}
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            dispatch(openLoginModal());
          }}
        />
      )}

      {/* iterate over maps list*/}
      {/* {mapList.length > 0 && !expandSelected && ( */}
      {user.isAuthorised && !isLoading && !isCalculating && mapList && (
        <div style={{ marginTop: "28px" }}>
          <div style={hideWhenExpanded}>
            <Grid stackable>
              <Grid.Row width={2}>
                <Grid.Column className="padless-column" width={16}>
                  <Segment attached="top">
                    <Header as="h4" content={t("maps.create")} />
                  </Segment>
                  <Segment attached clearing>
                    <Form onSubmit={null}>
                      <Form.Group widths={1}>
                        <div style={{ width: "100%" }}>
                          <Form.Field
                            // id="form-select-control-profile"
                            style={{ minWidth: "6em" }}
                            value={selectedProfile}
                            control={Select}
                            options={profileOptions}
                            selectOnBlur={false}
                            label={t("jobs.profilePlaceholder")}
                            placeholder={t("jobs.profilePlaceholder")}
                            onChange={handleProfileChange}
                            error={profileError}
                          />
                        </div>
                      </Form.Group>
                      <Button
                        style={{ marginTop: "16px" }}
                        content={t("maps.sendData")}
                        onClick={handleCreateMap}
                        color="blue"
                        floated="right"
                      />
                    </Form>
                  </Segment>
                {/* </Grid.Column>
                <Grid.Column className="padless-column" width={12}> */}
                {user.isAuthorised && mapList.length > 0 && (
                  <>
                  <Segment attached="top">
                    <Header as="h4" content={mapList.length + " " + t("maps.mapsFound")}/>
                  </Segment>
                  <Segment attached>
                    <Item.Group relaxed unstackable divided>
                      {mapList.map((map, i) => (
                        <Item key={i}>
                          {/* Map card/item */}
                          <Item.Content className="overflow-fix">
                            <Item.Header
                              as="a"
                              onClick={(e) => {
                                selectedMapHandler(
                                  map.data.map_id,
                                  map.data.question
                                );
                              }}
                              className={
                                map.status === "Ready!"
                                  ? "mapcard--header"
                                  : "mapcard--header-inactive"
                              }
                            >
                              {map.data.question}
                            </Item.Header>
                            <Item.Extra>
                              <span
                                style={{
                                  color:
                                    map.status === "Ready!"
                                      ? "#058527"
                                      : "#faa125",
                                }}
                              >
                                {t("maps.mapStatus")}: {t(`maps.${map.status}`)}                               
                               </span>
                            </Item.Extra>
                            <Item.Extra>
                              <Label content={t(`maps.${map.data.type}`)} />
                            </Item.Extra>
                            <Item.Extra>
                              <Button
                                negative
                                size="tiny"
                                content={t("profile.deleteBtn")}
                                onClick={() =>
                                  setDeleteConfirm({
                                    open: true,
                                    id: map.data.map_id,
                                  })
                                }
                                disabled={
                                  map.status === "Calculating..." ? true : false
                                }
                              />
                            </Item.Extra>
                          </Item.Content>
                        </Item>
                      ))}
                    </Item.Group>
                  </Segment>
                  </>
                  )}
                </Grid.Column>
              </Grid.Row>
            </Grid>
          </div>

          <div style={showWhenSelected}>
            <MapVisualizer
              selectedMap={selectedMap}
              toggleVisibility={() => setexpandSelected(!expandSelected)}
            />
          </div>
          <ConformationModal
            modalOpen={deleteConfirm.open}
            onClose={() => setDeleteConfirm({ ...deleteConfirm, open: false })}
            onConfirm={deleteMapHandler}
            onCancel={() => setDeleteConfirm({ ...deleteConfirm, open: false })}
          />
        </div>
      )}
    </div>
  );
};

export default MapList;

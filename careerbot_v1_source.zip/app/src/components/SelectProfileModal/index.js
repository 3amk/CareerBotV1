import React, { useState } from "react";
import { useSelector } from "react-redux";
import { useTranslation } from "react-i18next";
import { Grid, Modal, Form } from "semantic-ui-react";

const SelectProfileModal = ({
  profileModalOpen,
  closeModal,
  updateProfile,
}) => {
  const { t } = useTranslation();

  const profiles = useSelector((state) => state.profiles);

  const [selectedProfile, setSelectedProfile] = useState(null);

  const handleProfileChange = (e, data) => {
    e.preventDefault();
    setSelectedProfile(data.value);
  };

  const profileOptions = profiles.map((profile) => ({
    key: profile.id,
    value: profile.name,
    text: profile.name,
  }));

  return (
    <Modal
      open={profileModalOpen}
      centered={true}
      size="mini"
      dimmer="blurring"
    >
      <Modal.Header>{t("jobs.profile")}</Modal.Header>
      <Modal.Content>
        <Form>
          <Form.Select
            placeholder={t("jobs.profilePlaceholder")}
            fluid
            search
            selection
            value={selectedProfile}
            options={profileOptions}
            onChange={handleProfileChange}
          />
          <Grid columns={2}>
            <Grid.Column>
              <Form.Button
                size="large"
                onClick={closeModal}
                floated="left"
                color="red"
              >
                {t("profile.cancel")}
              </Form.Button>
            </Grid.Column>
            <Grid.Column>
              <Form.Button
                size="large"
                floated="right"
                primary
                onClick={(e) => {
                  e.preventDefault();
                  updateProfile(selectedProfile);
                }}
              >
                {t("profile.add")}
              </Form.Button>
            </Grid.Column>
          </Grid>
        </Form>
      </Modal.Content>
    </Modal>
  );
};

export default SelectProfileModal;

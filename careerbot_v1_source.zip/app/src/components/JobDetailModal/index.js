import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import { useDispatch, useSelector } from "react-redux";
import { Button, Header, Divider, Modal } from "semantic-ui-react";

import CoursesModal from "../CoursesModal";
import SelectProfileModal from "../SelectProfileModal";

import {
  trimString,
  stringToArray,
  dateformat,
} from "../../utils/helperFunctions";
import { getCourseBySkills } from "../../services/courses";
import { getProfileData } from "../../services/skillsProfile";
import { updateProfileData } from "../../reducers/profileDataReducer";
import { setNotification } from "../../reducers/notificationReducer";
import "./JobDetailModal.css";

const JobDetailModal = ({ job, modalOpen, onClose }) => {
  const { t } = useTranslation();
  const dispatch = useDispatch();

  const [selectedSkill, setSelectedSkill] = useState(null);
  const [profileModalOpen, setProfileModalOpen] = useState(false);
  const [courseModalOpen, setCourseModalOpen] = useState(false);
  const [courses, setCourses] = useState({ list: null, isLoading: false });

  const user = useSelector((state) => state.user);
  const profileData = useSelector((state) => state.profileData);

  const description = trimString(job.description, 700);
  const missingSkills = stringToArray(job.required_skills_not_found_from_cv);
  const matchingSkills = stringToArray(job.skills_that_match);
  const date = dateformat(job.time);

  const handleClick = (skill) => {
    if (selectedSkill === skill) {
      setSelectedSkill(null);
    } else {
      setSelectedSkill(skill);
    }
  };

  const openCourseModal = () => setCourseModalOpen(true);
  const closeCourseModal = () => setCourseModalOpen(false);

  const openSelectProfileModal = () => setProfileModalOpen(true);

  const closeSelectProfileModal = () => setProfileModalOpen(false);

  const handleCourse = () => {
    if (selectedSkill) {
      setCourses({ ...courses, isLoading: true });
      getCourseBySkills(selectedSkill, 50).then((courses) => {
        setCourses({ ...courses, list: courses.data, isLoading: false });
      });
    }
    openCourseModal();
  };

  const updateProfile = (selectedProfile) => {
    if (selectedProfile) {
      if (profileData[selectedProfile] === undefined) {
        let data =selectedProfile;
        let buff = new Buffer(data);
        let encodedProfileName = buff.toString('base64');

        getProfileData(selectedProfile).then((res) =>
          addSkillToProfile(res.data)
        );
      } else addSkillToProfile(profileData[selectedProfile]);
    }
  };

  const addSkillToProfile = (currentProfile) => {
    const exist = currentProfile.include_skills.indexOf(selectedSkill);
    if (exist === -1) {
      const newProfileData = {
        ...currentProfile,
        include_skills: [
          ...currentProfile.include_skills,
          selectedSkill,
        ].toString(),
        exclude_skills: currentProfile.exclude_skills.toString(),
        courses: currentProfile.courses.toString(),
      };
      dispatch(updateProfileData(newProfileData, currentProfile.name));
      closeSelectProfileModal();
      dispatch(
        setNotification("Skills profile updated with new skills", 5, "success")
      );
    }
  };

  return (
    <Modal
      open={modalOpen}
      onClose={onClose}
      centered={true}
      closeIcon
      size="large"
    >
      <Modal.Header>{job.id}</Modal.Header>

      <Modal.Content 
        style={{ maxHeight: "40vh" }}
        scrolling
      >

        {/* <p>{date}</p> */}
        <Modal.Description>
          <Header 
            style={{ marginTop: "-20px" }} 
            size="medium">{t("jobs.summary")}</Header>

            <p>{description}</p>

          <Header size="medium">{t("jobs.matchingSkills")}</Header>
          {matchingSkills.length < 1 ? (
            <p>{t("jobs.noMatching")}</p>
          ) : (
            matchingSkills.map((skill, index) => (
              <Button 
                basic 
                color="teal" 
                key={index}
                style={{ margin: "4px 6px 4px 0px" }}
              >
                {skill}
              </Button>
            ))
          )}
          <Divider section />
          <Header size="medium">{t("jobs.missingSkills")}</Header>
          {missingSkills.map((skill, index) => (
            <button
              key={index}
              onClick={() => handleClick(skill)}
              style={{ padding: "9px 20px 9px 20px" }}
              className={
                selectedSkill === skill
                  ? "missing-button-active"
                  : "missing-button"
              }
            >
              {skill}
            </button>
          ))}

        </Modal.Description>

        <Divider section />

        <Modal.Actions >
          <Button
            // style={{ float: "right" }}
            color="blue"
            className="stacked-button"
            onClick={openSelectProfileModal}
            disabled={!user.isAuthorised || selectedSkill === null}
            content={t("jobs.addSkill")}
          />
          <Button
            // style={{ float: "right" }}
            color="blue"
            className="stacked-button"
            onClick={handleCourse}
            content={t("jobs.searchCourse")}
            disabled={selectedSkill === null}
          />
        </Modal.Actions>
      </Modal.Content>

      <Modal.Actions>
        <Button
          as="a"
          basic
          color="blue"
          // floated="right"
          content={t("jobs.readMore")}
          href={job.url}
          target="_blank"
          rel="noreferrer"
        />
      </Modal.Actions>
      <CoursesModal
        courseModalOpen={courseModalOpen}
        closeCourseModal={closeCourseModal}
        courses={courses}
        skill={selectedSkill}
      />
      <SelectProfileModal
        profileModalOpen={profileModalOpen}
        closeModal={closeSelectProfileModal}
        updateProfile={updateProfile}
      />

    </Modal>
    
  );
};

export default JobDetailModal;

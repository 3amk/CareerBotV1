import React, { useState } from "react";
import { Segment, TransitionablePortal, Icon } from "semantic-ui-react";


const Alert = ({ messageDescription, color }) => {

const [open, setOpen] = useState(true);

const alertType = () => {
  if(color == "#03991f") {
    return("rgba(3, 153, 31, 0.3)")
  }
  else if (color == "#fc3b05") {
    return("rgba(252, 59, 5, 0.3)")
  }
  else if (color == "#fbbd08") {
    return("rgba(251, 189, 8, 0.3)")
  }
  else {
    return("")
  }
}
const alertIcon = () => {
  if(color == "#03991f") {
    return("checkmark")
  }
  else if (color == "#fc3b05") {
    return("exclamation circle")
  }
  else if (color == "#fbbd08") {
    return("exclamation triangle")
  }
  else {
    return("")
  }
}
const alertColor = () => {
  if(color == "#03991f") {
    return("green")
  }
  else if (color == "#fc3b05") {
    return("red")
  }
  else if (color == "#fbbd08") {
    return("yellow")
  }
  else {
    return("")
  }
}

  return (

    <TransitionablePortal 
      transition={{ animation: "fade", duration: 500 }}
      open={open}
      closeOnDocumentClick={true}
      closeOnEscape={true}
      closeOnTriggerBlur={false}
      >
       <Segment
        onClick={() => setOpen(false)}
        onClose={() => setOpen(true)}
        style={{
          horizontalAlign: "middle",
          left: "20%",
          right: "20%",
          position: "fixed",
          top: "10%",
          zIndex: 1000,
          backgroundColor: "white",
          maxWidth: "60%",
          borderRadius: "6px",
          boxShadow: `0px 0px 10px 1px ${alertType()}`,
          textAlign: "center",
         }}
       >
         <Icon color={alertColor()} name={alertIcon()} size="large"></Icon>
         <p>{messageDescription}</p>
       </Segment>
    </TransitionablePortal>


  );
};

export default Alert;

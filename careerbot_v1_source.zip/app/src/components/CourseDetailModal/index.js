import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import { useSelector, useDispatch } from "react-redux";
import { Header, Modal, Button } from "semantic-ui-react";

import SelectProfileModal from "../SelectProfileModal";

import { updateProfileData } from "../../reducers/profileDataReducer";
import { setNotification } from "../../reducers/notificationReducer";

import { getProfileData } from "../../services/skillsProfile";

const CourseDetailModal = ({ course, modalOpen, onClose }) => {
  const { t } = useTranslation();
  const dispatch = useDispatch();

  const [selectProfileModalOpen, setSelectProfileModalOpen] = useState(false);

  const user = useSelector((state) => state.user);
  const profileData = useSelector((state) => state.profileData);

  const updateProfile = (selectedProfile) => {
    if (selectedProfile) {
      if (profileData[selectedProfile] === undefined) {
        let data =selectedProfile;
        let buff = new Buffer(data);
        let encodedProfileName = buff.toString('base64');

        getProfileData(encodedProfileName).then((res) =>
          addCourseToProfile(res.data)
        );
      } else addCourseToProfile(profileData[selectedProfile]);
    }
  };

  const addCourseToProfile = (currentProfile) => {
    const exist = currentProfile.courses.indexOf(course.id);
    if (exist === -1) {
      const newProfileData = {
        ...currentProfile,
        include_skills: currentProfile.include_skills.toString(),
        exclude_skills: currentProfile.exclude_skills.toString(),
        courses: [...currentProfile.courses, course.id].toString(),
      };
      dispatch(updateProfileData(newProfileData, currentProfile.name));
      setSelectProfileModalOpen(false);
      dispatch(
        setNotification("Skills profile updated with new course", 5, "success")
      );
    }
  };

  return (
    <>
      <Modal
        open={modalOpen}
        onClose={onClose}
        centered={true}
        closeIcon
        size="large"
      >
        <Modal.Header>{course.title}</Modal.Header>
        <Modal.Content 
          style={{ maxHeight: "40vh" }}
          scrolling
          >
          <Modal.Description>
            <Header size="medium">{t("courses.description")}</Header>
            <p>{course.description}</p>
            <div>
              <strong>{t("courses.language")}: </strong>
              {course.language ? course.language.toUpperCase() : "Unknown"}
            </div>
            <div>
              <strong>{t("courses.school")}: </strong>
              {course.school.toUpperCase()}
            </div>
          </Modal.Description>
        </Modal.Content>
        <Modal.Actions>
          <Button
            className="stacked-button"
            onClick={(e) => {
              e.preventDefault();
              setSelectProfileModalOpen(true);
            }}
            disabled={!user.isAuthorised}
            content={t("courses.addCourse")}
            color="blue"
          />
          <Button
           style={{ marginBottom: "15px"}}
            className="stacked-button"
            color="blue"
            as="a"
            basic
            content={
              course.url === "api" ? "Link not found" : t("jobs.readMore")
            }
            href={course.url}
            target="_blank"
            rel="noreferrer"
            disabled={course.url === "api"}
          />
        </Modal.Actions>
      </Modal>
      <SelectProfileModal
        profileModalOpen={selectProfileModalOpen}
        closeModal={() => setSelectProfileModalOpen(false)}
        updateProfile={updateProfile}
      />
    </>
  );
};

export default CourseDetailModal;

// line: 76: {course.author.toUpperCase()}
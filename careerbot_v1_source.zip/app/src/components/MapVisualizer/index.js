/* eslint-disable react-hooks/exhaustive-deps */
import React, { useRef, useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import {
  Button,
  Icon,
  Segment,
  Header,
  Grid,
  Checkbox,
  Table,
  Input,
  Popup
} from "semantic-ui-react";
import { saveSvgAsPng } from "save-svg-as-png";
import { select } from "d3-selection";
import { zoom, zoomTransform } from "d3-zoom";
import { scaleOrdinal } from "d3-scale";
import { interpolateGnBu, schemeCategory10 } from "d3-scale-chromatic";

import { getMapData } from "../../services/maps";
import { FullScreen, useFullScreenHandle } from "react-full-screen";

import LoaderCube from "../../components/LoaderCube";

import * as d3 from 'd3';

import "./Maps.css";

const MapVisualizer = ({ toggleVisibility, selectedMap, isExample }) => {
  const { t, i18n } = useTranslation();
  const [highlight, setHighlight] = useState(false);
  const [finalData, setFinalData] = useState(null);
  const [showLabel, setShowLabel] = useState(true);
  const [newNode, setNewNode] = useState(null);
  const [isLabelCreated, setIsLabelCreated] = useState(false);
  const [tableColumns, setTableColumns] = useState([]);
  const [transposedColumns, setTransposedColumns] = useState([]);
  const [userFontSize, setUserFontSize] = useState(3);

  const [svgLoaded, setSvgLoaded] = useState(false);
  const refContainer = useRef(null);
  const refDiv = useRef(null);
  const refSvg = useRef(null);
  const refGroup = useRef(null);
  const handleFullscreen = useFullScreenHandle();
  const [downloadBtnText, setDownloadBtnText] = useState(t("maps.btnDownload"));

  const [ dimensions, setDimensions ] = useState({
    width: window.innerWidth
  });

  const [{ x, y, k }, setTransform] = useState({ x: 0, y: 0, k: 1 });
  const [svg, setSvg] = useState(null);
  const [group, setGroup] = useState(null);
  const [svgm, setSvgm] = useState(refSvg.current);

  let highlightedNode = null;
  let currentlyHighlightedConnectedNodes = []; // connected nodes to current highlight node
  let currentWindowScale = [1, 1];

  /* Constant variables */
  const SELECTED_NODE_HIGHLIGHT_COLOR = "pink";
  const NOMINAL_TEXT_SIZE = userFontSize;
  const MAX_TEXT_SIZE = 22;
  const COLORS = scaleOrdinal(schemeCategory10);
 
  // set window resize listners
  useEffect(() => {
    function windowResizeListner() {
      setDimensions({
        width: window.innerWidth
      })
      const width = 1400;
      const height = 900;
      let current_window_size = [
        refSvg.current && refSvg.current.clientWidth,
        refSvg.current && refSvg.current.clientHeight,
      ];
      return (currentWindowScale = [
        current_window_size[0] / width,
        current_window_size[1] / height,
      ]);
    }
    refSvg.current && window.addEventListener("resize", windowResizeListner);
  }, []);

  const exit_highlight = (d) => {
    if (highlight && highlightedNode != null && finalData !== undefined) {
      highlightedNode.ring.style("stroke", "none");
      for (let i = 0; i < currentlyHighlightedConnectedNodes.length; i++)
        finalData[currentlyHighlightedConnectedNodes[i][0]].ring.style(
          "stroke",
          "none"
        );
      currentlyHighlightedConnectedNodes = [];
      highlightedNode = null;
    }
  };

  const set_highlight = (datum) => {
    if (highlight) {
      svg.style("cursor", "pointer");
      highlightedNode = datum;
      currentlyHighlightedConnectedNodes =
        finalData[highlightedNode.id].connected;
      datum.ring.style("stroke", SELECTED_NODE_HIGHLIGHT_COLOR);
      for (let i = 0; i < currentlyHighlightedConnectedNodes.length; i++)
        finalData[currentlyHighlightedConnectedNodes[i][0]].ring.style(
          "stroke",
          interpolateGnBu(currentlyHighlightedConnectedNodes[i][1])
        );
    }
  };

  const addLegend = () => {
    // remove old data
    if (isLabelCreated) {
      select("svg").selectAll("circle").remove();
      select("svg").selectAll("text").remove();
    }

    if (tableColumns.length < 1) return;
    let keys = [];
    for (let i = 0; i < tableColumns.length; i++) {
      keys.push(t("maps.cluster") + String(i + 1));
    }
    // rescale text
    const scale_x = Math.min(3, Math.max(0.5, 1 / currentWindowScale[0]));
    const scale_y = Math.min(3, Math.max(0.5, 1 / currentWindowScale[1]));
    const font_size = String(Math.round(24 * scale_x)) + "px";
    const legend_X_pad = 10;
    const legend_Y_pad = 20 * scale_y;

    // Add one dot in the legend for each cluster name.
    // set dots
    select(refSvg.current)
      .selectAll()
      .data(keys)
      .enter()
      .append("circle")
      .attr("cx", legend_X_pad)
      .attr("cy", function (d, i) {
        return legend_Y_pad + i * 30 * scale_y;
      })
      .attr("r", 8)
      .style("fill", function (d, i) {
        return COLORS(i);
      })
      .attr("opacity", 0.75);

    // set labels to each dot
    select(refSvg.current)
      .selectAll()
      .data(keys)
      .enter()
      .append("text")
      .attr("x", legend_X_pad + 19)
      .attr("y", function (d, i) {
        return legend_Y_pad + i * 30 * scale_y + 9;
      })
      .style("fill", function (d, i) {
        return COLORS(i);
      })
      .text(function (d) {
        return d;
      })
      .attr("text-anchor", "left")
      .style("alignment-baseline", "middle")
      .style("font-size", font_size)
      .attr("opacity", 0.6);
    setIsLabelCreated(true);
  };

  // highlight circles, only show when highlight mode is checked and mouse hovered on circle
  const makeHighlight = (data) => {
    let ring;
    for (let i = 0; i < data.length; i++) {
      ring = select(group)
        .append("circle")
        .attr("class", "rings") // attach a circle
        .attr("cx", data[i].x) // position the x-centre
        .attr("cy", data[i].y) // position the y-centre
        .attr("r", Math.max(data[i].r - 1, 0.5)) // set the radius
        .style("stroke-width", 1.5) // set the stroke width
        .style("stroke", "none") // set the line colour
        .style("fill", "none");
      data[i].ring = ring;
    }
  };

  const drawMap = () => {
    addLegend();

    setTimeout(function () {
      const uid = `O-${Math.random().toString(16).slice(2)}`;
      const nNode = select(group)
        .append("g")
        .selectAll("g")
        .data(finalData)
        .enter()
        .append("g");

      nNode
        .attr("cx", (d) => d.x)
        .attr("cy", (d) => d.y)
        .attr("transform", function (d) {
          return "translate(" + d.x + "," + d.y + ")";
        });

      nNode
        .append("circle")
        .attr("r", (d) => d.r)
        .attr("fill", function (d) {
          return COLORS(d.group - 1);
        })
        .attr("opacity", 0.6)
        .on("click", function(d){var highlightColor = this.style.opacity == 0.2 ? 0.6 : 0.2;
          d3.select(this).style("opacity", highlightColor);
        })
          nNode.append("title")
        .text((d) => d.label_extra);

        

        const D = d3.map(finalData, d => d);

        if (userFontSize < 5) { 
          nNode.append("clipPath")
              .attr("id", d => `${uid}-clip-${d.r}`)
            .append("circle")
              .attr("r", d => (d.r));
        }
        nNode.append("text")
          .attr("clip-path", finalData => `url(${new URL(`#${uid}-clip-${finalData.r}`, window.location)})`)
          .style("font-size", d => (NOMINAL_TEXT_SIZE * d.r / 16) + "px")
          .style("text-anchor", "middle")
          .style('cursor', 'pointer')
          .on("click", function(){var highlightColor = this.style.fill == "white" ? "black" : "white";
              d3.select(this).style("fill", highlightColor);
          })
          .selectAll("tspan")
          .data((d) => d.label.replace(/_/g, "\n").split(/\n/g))

          .join("tspan")
            .attr("x", 0)
            .attr("y", (d, i, finalData) => `${i - finalData.length / 2 + 0.85}em`)
            .attr("fill-opacity", (d, i, finalData) => i === finalData.length - 1)
            .text(d => d);
      setNewNode(nNode);
      setSvgLoaded(true);
      makeHighlight(finalData);
    }, 500);
    setSvgLoaded(false);
  };

  const setZoomListner = () => {
    setHighlight(false);
    setShowLabel(true);
    let svgMap = select(svgm);
    const myZoom = zoom().on("zoom", function () {
      let text_size = NOMINAL_TEXT_SIZE;
      setTransform(zoomTransform(svgMap.node()));
      const current_zoom_scale = zoomTransform(svgMap.node()).k;
      if (
        NOMINAL_TEXT_SIZE * current_zoom_scale >
        MAX_TEXT_SIZE / currentWindowScale[0]
      ) {
        text_size = MAX_TEXT_SIZE / current_zoom_scale / currentWindowScale[0];
        select(group)
          .selectAll("text")
          .style("font-size", (finalData, d) => (text_size * d.r / 16) + "px")
      }
    });
    svgMap.call(myZoom);
    setSvg(svgMap);

    select("svg").selectAll("circle").remove();
    select("svg").selectAll("text").remove();
  };

  // init svg and svg container on mount
  useEffect(() => {
    setSvgm(refSvg.current);
    setGroup(refContainer.current);
  }, []);

  // fetch map data if not passed with props (example maps data will be passed with props, user maps will be fetched from server using map id)
  useEffect(() => {
    let isMounted = true;
    if (isExample) {
      if (selectedMap.data && selectedMap.count) {
        if (isMounted) {
          setZoomListner();
          setFinalData(selectedMap.data);
          setSvgLoaded(false);
          setIsLabelCreated(false);
        }
      }
    } else if (selectedMap.id) {
      if (isMounted) {
        setZoomListner();
        getMapData(selectedMap.id).then((data) => {
          setFinalData(data.finalData);
          setIsLabelCreated(false);
        });
      }
    }

    return () => {
      isMounted = false;
    }; 
  }, [selectedMap.data, selectedMap.id, i18n.language]);

  // add or remove mouseover listner for node and circle text labels
  useEffect(() => {
    let isMounted = true;
    if (finalData && newNode) {
      if (isMounted) {
        if (!highlight) {
          newNode
            .on("mouseover.highlight", null)
            .on("mouseout.highlight", null);
        } else {
          newNode
            .on("mouseover.highlight", function () {
              const datum = select(this).datum();
              if (datum) {
                set_highlight(datum);
              }
            })
            .on("mouseout.highlight", function () {
              exit_highlight();
            });
          select(group)
            .selectAll("text")
            .on("mouseover.highlight", function (d, i) {
              set_highlight(finalData[i]);
            })
            .on("mouseout.highlight", function (d) {
              exit_highlight();
            });
        }
      }
    }
    return () => {
      isMounted = false;
    };
  }, [highlight]);

  // draw table of first 25 values of each cluster under the map
  useEffect(() => {
    let isMounted = true;

    // group final data by cluster key
    const getColumns = () => {
      if (finalData) {
        const group = finalData.reduce(function (acc, item) {
          var group = item["cluster"];
          acc[group] = acc[group] || [];
          acc[group].push({ label: item.label, weight: parseFloat(item.r.toFixed(1)), id: item.id });
          
          return acc;
        }, []);
        const sortedGroup = group.map((g) =>
          g.sort((a, b) => b.weight - a.weight).slice(0, 15)
        );
        return sortedGroup;
      } else {
        return [];
      }
    };

    // transpose column array to row array
    // source https://stackoverflow.com/a/50844014
    const transpose = (array) =>
      array.reduce((r, a, i, { length }) => {
        a.forEach((v, j) => {
          r[j] = r[j] || new Array(length).fill("");
          r[j][i] = v;
        });
        return r;
      }, []);

    if (finalData && svg) {
      if (isMounted) {
        setTransform({ x: 0, y: 0, k: 1 });
        const columns = getColumns();
        setTableColumns(columns);
        setTransposedColumns(transpose(columns));
      }
    }

    return () => {
      isMounted = false;
    };
  }, [finalData]);
 
  useEffect(() => {
    let isMounted = true;
    if (tableColumns.length > 0 && isMounted) {
      drawMap();
    }
    return () => {
      isMounted = false;
    };
  }, [tableColumns]);

  // draw label and highlight after svg is loaded or rerendered
  // useEffect(() => {
  //   if (finalData && svgLoaded) {
  //     select(group).selectAll("text").remove();
  //     if (showLabel) {
  //       let text_size = NOMINAL_TEXT_SIZE;
  //       if (NOMINAL_TEXT_SIZE * k > MAX_TEXT_SIZE / currentWindowScale[0])
  //         text_size = MAX_TEXT_SIZE / k / currentWindowScale[0];
  //       for (let i = 0; i < finalData.length; i++) {
  //         select(group)
  //           .append("text")
  //           .attr("class", "labels")
  //           .text((d) => finalData[i].label)
  //           .attr("x", finalData[i].x)
  //           .attr("y", finalData[i].y)
  //           .style("font-size", text_size + "px")
  //           .style("text-anchor", "middle")
  //           .attr("dy", "0.30em");
  //       }
  //     }
  //   }
  // }, [svgLoaded, showLabel]);

  /* ==== Button handlers === */

  const handleBack = () => {
    toggleVisibility();
    setTableColumns([]);
  };

  const handleSaveSvg = () => {
    setDownloadBtnText(t("maps.btnWait"));
    saveSvgAsPng(refSvg.current, "skillMap.png", {
      backgroundColor: "white",
    }).then(() => setDownloadBtnText("Download SVG"));
  };

  const highlightCheckbox = (e, data) => {
    if (data.checked === false) {
      exit_highlight();
      drawMap();
    }
    setHighlight(data.checked);
  };

  const handlingFontSize = (e) => {
    e.preventDefault();
    setUserFontSize(e.target.value);
 }
  
  const renderingFontSize = (e) => {
    select("svg").selectAll("circle").remove();
    select("svg").selectAll("text").remove();
    drawMap();
 }

  // No longer needed as text size fixed 

  // const labelsCheckbox = (e, data) => {
  //   const checked = data.checked;
  //   setShowLabel(checked);
  // };

  return (
    <Segment.Group>
      <Segment clearing>
        <Button
          size="small"
          basic
          compact
          color="blue"
          icon
          labelPosition="right"
          onClick={handleBack}
          style={{ borderRadius: 9 }}
        >
          {t("maps.close")}
          <Icon name="close" />
        </Button>
        {!handleFullscreen.active && dimensions.width > 1500 && (
        <Button
          size="small"
          basic
          compact
          icon
          labelPosition="right"
          onClick={handleFullscreen.enter}
          floated="right"
          style={{ borderRadius: 9 }}
        >
          <Icon name="expand" />
          {t("maps.fullScreen")}
        </Button>
        )}
      </Segment>
      <Segment clearing>
        <Header as="h3" content={selectedMap.mapName} />
        {!isExample && (
          <Button
            size="small"
            basic
            compact
            icon
            labelPosition="right"
            onClick={handleSaveSvg}
            floated="right"
            positive
            style={{ borderRadius: 9 }}
          >
            <Icon name="download" />
            {t("maps.btnDownload")}
          </Button>
        )}
      </Segment>
      <Segment >
        <FullScreen handle={handleFullscreen}>
          <div id="container" className="fullscreen-container">
            <Segment.Group>
              {/* Map control input */}
              {handleFullscreen.active && (
              <Segment style={{ marginTop: "-16px" }} clearing>
              <div>
                    {/* Close button for full screen */}
                    <Button
                      size="small"
                      basic
                      compact
                      icon
                      labelPosition="right"
                      onClick={handleFullscreen.exit}
                      floated="right"
                      style={{ borderRadius: 9, marginTop: "-5px" }}
                    >
                    {t("theseus.close")}
                      <Icon name="close" />
                    </Button>
                      <h4 style={{ marginTop: "0px" }}>{selectedMap.mapName}
                      </h4>
                  </div>
                  </Segment>
              )}

              <Segment clearing>

                <div>
                  {t("maps.textSize")} {userFontSize}
                <Popup
                  on="click"
                  trigger={<Icon color="grey" name="question circle" />}
                  content={t("maps.textHelp")}
                  position="top center"
                />
                  </div>
                   <Input
                    min={1}
                    max={8}
                    type='range'
                    value={userFontSize}
                    onChange={handlingFontSize}
                  />
                    {/* No longer needed */}
                    {/* <Checkbox
                      className="big-checkbox"
                      checked={showLabel}
                      onChange={labelsCheckbox}
                      label={t("maps.label")}
                    /> */}
                  <button 
                    className="ui primary right floated button"
                    onClick={renderingFontSize}>
                      {t("maps.mapRefresh")}   
                  </button>
                </Segment>
                <Segment clearing>
                  <Checkbox
                    className="big-checkbox"
                    checked={highlight}
                    onChange={highlightCheckbox}
                    label={t("maps.edges")}
                  />
                </Segment>
                {/* Map SVG */}
                <Segment secondary>
                  <div
                    className={`svg-container ${
                      handleFullscreen.active && "svg-container-full"
                    }`}
                    ref={refDiv}
                  >
                  {/* Full screen loader on SVG */}
                  {!svgLoaded && handleFullscreen.active && (
                    <div style={{ padding: "20% 0% 0% 0%" }}>
                      <LoaderCube />
                    </div>
                  )}
                  {/* Loader for non full screen */}
                  {!svgLoaded && !handleFullscreen.active && (
                    <div style={{ padding: "40% 0% 0% 0%" }}>
                      <LoaderCube />
                    </div>
                  )}
                  <svg
                    id="svgID"
                    // preserveAspectRatio="xMinYMin meet"
                    viewBox="0 0 1200 1900"
                    className="svg-content-responsive"
                    ref={refSvg}
                  >
                    <g
                      ref={refGroup}
                      transform={`translate(${x}, ${y}) scale(${k})`}
                    >
                      <g ref={refContainer} className="svg-group"></g>
                    </g>
                  </svg>
                </div>
              </Segment>
            </Segment.Group>
          </div>
        </FullScreen>
      </Segment>
      {tableColumns.length > 0 && (
        // <Segment>
        <div className="overflowed-table">
          <Table
            compact
            celled
            unstackable
            textAlign="left"
            columns={tableColumns.length}
          >
            <Table.Header>
              <Table.Row>
                {tableColumns.map((c, i) => (
                  <Table.HeaderCell style={{ color: COLORS(i) }} key={i}>
                   {t("maps.cluster") + " " + (i + 1)}
                  </Table.HeaderCell>
                ))}
              </Table.Row>
            </Table.Header>
            <Table.Body>
              {transposedColumns
              .map((row, i) => (
                <Table.Row textAlign="left" key={i}>
                  {row.map((r, j) => (
                    <Table.Cell key={j} style={{ color: COLORS(j) }}>
                      {r ? r.label + " " + r.weight : ""}
                    </Table.Cell>
                  ))}
                </Table.Row>
              ))}
            </Table.Body>
          </Table>
        </div>
        // </Segment>
      )}
    </Segment.Group>
  );
};

export default MapVisualizer;

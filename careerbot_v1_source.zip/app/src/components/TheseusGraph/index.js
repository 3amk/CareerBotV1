import React, { useRef, useEffect, useState } from "react";
import { select, selectAll, selection } from "d3-selection";
import { useTranslation } from "react-i18next";

import * as d3 from "d3";

import "./Graph.css";

const TheseusGraph = ({ data, theseusType, globalType, hoverKeyword, futurePrediction }) => {
// hoverKeyword currently unused, future dev perhaps
// Did not yet get the translation to re render when changing the language. map needs to be reloaded for axis labels to translate
const { t, i18n } = useTranslation();

const [svgContainer, setSvgContainer] = useState(null);
const [svg, setSvg] = useState(null);
const [graphVerticalPadding, setGraphVerticalPadding] = useState(40);
const [height, setHeight] = useState(410);

const refChart = useRef(null);

// Constants
const ENABLED_OPACITY = 1;
const DISABLED_OPACITY = 0.2;
const timeFormatter = d3.timeFormat('%Y');
const width = 590;
const margin = { top: 20, right: 160, bottom: 80, left: 60 };

const [chartAreaWidth, setChartAreaWidth] = useState();
const [chartAreaHeight, setChartAreaHeight] = useState();

// let totalCount = [];
let maxval = 0;
const reformattedData = [];
if(theseusType==true){
}
else if(globalType==true){
}

if(theseusType==true){
data.forEach((d, i) => {
  const word = d.word;
  const keyId = "" + i;
  d.stats.forEach((d, i) => {
    const data = {
      word: word,
      keyId: keyId,
      stats: d.stats.map((d) => {
        if (d.count > maxval) maxval = d.count;
          return { ...d, year: new Date(d.year, 0), word: word, keyId: keyId }; 
      }),
    };
        reformattedData.push(data);
  });
});
}
else{
  data.forEach((d, i) => {
      const data = {
        word: d.word,
        keyId: "" + i,
        stats: d.stats.map((d) => {
          if (d.count > maxval) maxval = d.count;
            return { ...d, year: new Date(d.year, 0), word: d.word, keyId: "" + i}; 
        }),
      };
          reformattedData.push(data);
    });
  };

useEffect(() => {
  if (reformattedData.length > 21) {
    setGraphVerticalPadding(80);
    setHeight(410 + (reformattedData.length - 21) * 20);
  } else {
    setGraphVerticalPadding(40);
    setHeight(410);
  }
  setChartAreaWidth(width + margin.left + margin.right);
  setChartAreaHeight(height + margin.top + graphVerticalPadding);
}, [reformattedData])

const predict = (datum, newX) => {

  const round = n => Math.round(n * 100) / 100;

  const sum = datum.reduce((acc, pair) => {
    const x = pair[0];
    const y = pair[1];

    if (y !== null) {
      acc.x += x;
      acc.y += y;
      acc.squareX += x * x;
      acc.product += x * y;
      acc.len += 1;
    }
    
    return acc;
  }, { x: 0, y: 0, squareX: 0, product: 0, len: 0 });

  const run = ((sum.len * sum.squareX) - (sum.x * sum.x));
  const rise = ((sum.len * sum.product) - (sum.x * sum.y));
  const gradient = run === 0 ? 0 : round(rise / run);
  const intercept = round((sum.y / sum.len) - ((gradient * sum.x) / sum.len));

  if (round((gradient * newX) + intercept) > 0) {
    return round((gradient * newX) + intercept);
  } else {
    return 0;
  }
  
};

// Another data reformat to access 3 future years from API data, grab the last 3 years which have populated results for predictions
const forecastData = [];
const increments = [0, 1, 2];

reformattedData.forEach((d, i) => {
  const year = d.stats[d.stats.length -1].year;
  const data = {
    word: d.word,
    keyId: d.keyId,
    array: d.stats.map((d, i) => {
      return[i, d.count]
    }),
    year: increments.map((d, i) => {
      return { forecastYear: new Date(year.getFullYear() + i, 0) } 
    }),
  }
  forecastData.push(data)
  })

const forecast = [];

forecastData.forEach((d, x) => {
  for (var i = 0; i < increments.length; i++) {
    const array = forecastData[x].array.slice(0, -1);
    const data = {
      year: forecastData[x].year[i].forecastYear,
      keyId: forecastData[x].keyId,
      word: forecastData[x].word,
      count: parseInt(predict(array, array.length + i)),
    }   
  forecast.push(data)
}
});


// Reformatted again into CSV style data that is very easy to work with
var reformattedData2 = [];

if (futurePrediction === true) {
  reformattedData.forEach((d, i) => {
    for (var i = 0; i < d.stats.length -1; i++) {
      reformattedData2.push(d.stats[i])
    }
  });
  forecast.forEach((d, i) => {
    reformattedData2.push(forecast[i])
  });
} else {
  reformattedData.forEach((d, i) => {
    for (var i = 0; i < d.stats.length -1; i++) {
      reformattedData2.push(d.stats[i])
    }
  });
}

// Scales
let xScale = d3.scaleTime()
  .domain(d3.extent(reformattedData2, d => d.year))
  .range([10, width - margin.top])
  .nice();

let yScale = d3.scaleLinear()
  .domain([0, d3.max(reformattedData2, (d => d.count))])
  .range([height - margin.top, 0])
  .nice();

// Rescale
let rescaledX = xScale;
let rescaledY = yScale;

// Color scale
const colorScale = d3.scaleOrdinal(d3.schemeCategory10);

useEffect(() => {
  setSvgContainer(refChart.current);
}, []);

useEffect(() => {
  select("svg").selectAll("g").remove();
  select("path").remove();

  const svgm = select(svgContainer);
  svgm.attr("viewBox", [0, 0, chartAreaWidth, chartAreaHeight]);
// Axis labels
  svgm
    .append("g")
    .append("text")
    .attr('transform', `translate(${chartAreaWidth / 2 - 75},${height + 55})`)
    .attr("fill", "#565656")
    .text(t("theseus.year"));

  svgm
    .append("g")
    .append("text")
    .attr('transform', `translate(15,${chartAreaHeight / 2}) rotate(-90)`)
    .attr("fill", "#565656")
    .text(t("theseus.totalCount"));

  // Zoom & Hovering dot
  // Remove 160 if extra years to be shown on zoom
  const zoom = d3.zoom()
    .scaleExtent([1, 2.5])
    .translateExtent([[0, 0], [chartAreaWidth - 160, chartAreaHeight + margin.top]])
    .on('start', () => {
      hoverDot
        .attr('cx', -15)
        .attr('cy', 0);
    })
    .on('zoom', zoomed);

  // Draw chart as SVG
  const chart = d3.select('#chart')
    .append('svg')
    .attr("width", width + margin.left + "px")
    .attr("height", height + margin.bottom + "px")
    .append('g')
    .attr("transform", `translate(${margin.left}, ${margin.top})`);

  // Maximum Y value
  const totalCount = d3.max(reformattedData2, d => d.count);

  // Extra margin to Y Axis (+5% of the highest value on chart) to prevent hitting the clip path
  const totalPadding = totalCount + (totalCount / 100) * 5;

  // Info for axes and color value
  xScale.domain(d3.extent(reformattedData2, d => d.year));
  yScale.domain([0, totalPadding]);
  colorScale.domain(d3.map(reformattedData2, d => d.keyId).keys());

  // Rendering axes
  // Label positioning
  const xAxis = d3.axisBottom(xScale)
    .ticks((width + 2) / (height + 2) * 5)
    .tickSize(-height - 6)
    .tickPadding(3);

  const yAxis = d3.axisRight(yScale)
    .ticks(5)
    .tickSize(7 + width)
    .tickPadding(-13 - width)
    .tickFormat(d => d);
    
  // Axis lines
  const xAxisElement = chart.append('g')
    .attr('class', 'axis x-axis')
    .attr('transform', `translate(0,${ height })`)
    .call(xAxis);

  const yAxisElement = chart.append('g')
    .attr('transform', 'translate(0, 0)')
    .attr('class', 'axis y-axis')
    .call(yAxis);

  // Axis label population i.e display months/ years on X axis (ticks)
  chart.append('g')
    .attr('transform', `translate(0,${ height })`)
    .call(d3.axisBottom(xScale).ticks(0));

  chart.append('g')
    .call(d3.axisLeft(yScale).ticks(0));

  // Clip path for line
  chart.append('defs').append('clipPath')
    .attr('id', 'clip')
    .append('rect')
    .attr('width', width)
    .attr('height', height);

  // Nesting by keyword
  const nestByKeyId = d3.nest()
    .key(d => d.keyId)
    .sortKeys((v1, v2) => (parseInt(v1, 10) > parseInt(v2, 10) ? 1 : -1))
    .entries(reformattedData2);

  const subjectsNamesById = {};

  // Nesting mapping
  nestByKeyId.forEach(item => {
    subjectsNamesById[item.key] = item.values[0].word;
  });
  const keys = {};

  // Split by keyword / id
  d3.map(reformattedData2, d => d.keyId)
    .keys()
    .forEach((d, i) => {
      keys[d] = {
        data: nestByKeyId[i].values,
        enabled: true
      };
  });

  // Split by ID
  const keysIds = Object.keys(keys);

  // Generate line and curve style
  const lineGenerator = d3.line()
    .x(d => rescaledX(d.year))
    .y(d => rescaledY(d.count))
    .curve(d3.curveMonotoneX)
    // .curve(d3.curveCardinal.tension(0.25))
    ;

  // Split by date
  const nestByDate = d3.nest()
    .key(d => d.year)
    .entries(reformattedData2);

  const totalsByDate = {};

  nestByDate.forEach(dateItem => {
    totalsByDate[dateItem.key] = {};

    dateItem.values.forEach(item => {
      totalsByDate[dateItem.key][item.keyId] = item.count;
    });
  });

  // Legend container
  const legendContainer = d3.select('#chart');
      
  const legendsSvg = legendContainer
    .append('svg')
    .attr('width', 350)
    .attr('height', height + graphVerticalPadding)
    .attr('x', chartAreaWidth - margin.right - 45)
    .attr('y', 0)
    .append('g')
    .attr("transform", `translate(${margin.left}, ${margin.top})`);

  // Display the year when hovering 
  const legendsDate = legendsSvg.append('text')
    .attr('visibility', 'hidden')
    .attr('x', -10)
    .attr('y', 5)
  
  // Click handling in legend
  const legends = legendsSvg
    .selectAll('g')
    .data(keysIds)
    .enter()
    .append('g')
    .attr('class', 'legend-item')
    .attr('transform', (keyId, index) => `translate(0,${ index * 20 + 20 })`)
    .on('click', clickLegendHandler);

  // Keywords into legend
  const legendsValues = legends
    .append('text')
    .attr('x', -10)
    .attr('y', 5)
    .style('fill', keyId => colorScale(keyId))
    .attr('class', 'legend-value');

  // Circles in legend
  legends.append('circle')
    .attr('cx', 30)
    .attr('cy', 0)
    .attr('r', 8)
    .style('fill', keyId => colorScale(keyId))
    .select(function() { return this.parentNode; })
    .append('text')
    .style('fill', keyId => colorScale(keyId))
    .attr('x', 45)
    .attr('y', 5)
    .text(keyId => subjectsNamesById[keyId])
    .attr('class', 'textselected')
    .style('text-anchor', 'start')
    .style('font-size', 12)
    .append("title")
    .text(keyId => subjectsNamesById[keyId]);

  // Lines container
  const linesContainer = chart.append('g')
    .attr('clip-path', 'url(#clip)');

  let singleLineSelected = false;

  const voronoi = d3.voronoi()
    .x(d => xScale(d.year))
    .y(d => yScale(d.count))
    .extent([[0, 0], [width, height]]);

  // Hovering tool tip
  const hoverDot = chart.append('circle')
    .attr('class', 'dot')
    .attr('r', 5)
    .attr('clip-path', 'url(#clip)')
    .style('stroke', 'rgba(0, 0, 0, 0.51)')
    .style('stroke-width', '3')
    .style('fill', 'none')
    .style('visibility', 'hidden');

  // Visibilities for legend and hover
  let voronoiGroup = chart.append('g')
    .attr('class', 'voronoi-parent')
    .attr('clip-path', 'url(#clip)')
    .append('g')
    .attr('class', 'voronoi')
    .on('mouseover', () => {
      legendsDate.style('visibility', 'visible');
      hoverDot.style('visibility', 'visible');
    })
    .on('mouseout', () => {
      legendsValues.text('');
      legendsDate.style('visibility', 'hidden');
      hoverDot.style('visibility', 'hidden');
    });

  // Zooming and re rendering
  d3.select('.voronoi-parent').call(zoom);

  redrawChart();

  function redrawChart(showingKeysIds) {
    const enabledKeysIds = showingKeysIds || keysIds.filter(keyId => keys[keyId].enabled);

// Rendering lines
  const paths = linesContainer
    .selectAll('.line')
    .data(enabledKeysIds);

  paths.exit().remove();

  const pathsPrediction = linesContainer
    .selectAll('.dashed')
    .data(enabledKeysIds);

    pathsPrediction.exit().remove();

  // Line generator
  if (futurePrediction === true) {
    paths
    .enter()
    .append('path')
    .merge(paths)
    .attr('class', 'line')
    .attr('id', keyId => `subject-${ keyId }`)
    .attr('d', keyId => lineGenerator(keys[keyId].data.slice(0,-3)))
    .style('stroke', keyId => colorScale(keyId))
    .style('stroke-linecap', 'round')

    pathsPrediction
    .enter()
    .append('path')
    .merge(pathsPrediction)
    .attr('class', 'dashed')
    .attr('id', keyId => `subjectPredict-${ keyId }`)
    .attr('d', keyId => lineGenerator(keys[keyId].data.slice(9)))
    .style('stroke', keyId => colorScale(keyId))
    .style('stroke-linecap', 'round')

  } else {
    paths
    .enter()
    .append('path')
    .merge(paths)
    .attr('class', 'line')
    .attr('id', keyId => `subject-${ keyId }`)
    .attr('d', keyId => lineGenerator(keys[keyId].data))
    .style('stroke', keyId => colorScale(keyId))
    .style('stroke-linecap', 'round')
  }

  // Opacities for selection... active / inactive
  legends.each(function(keyId) {
    const opacityValue = enabledKeysIds.indexOf(keyId) >= 0 ? ENABLED_OPACITY : DISABLED_OPACITY;

    d3.select(this).attr('opacity', opacityValue);
  });

  // Further data filtering
  const filteredData = reformattedData2.filter(dataItem => enabledKeysIds.indexOf(dataItem.keyId) >= 0);

  const voronoiPaths = voronoiGroup.selectAll('path')
    .data(voronoi.polygons(filteredData));

  voronoiPaths.exit().remove();

  voronoiPaths
  .enter()
  .append('path')
  .merge(voronoiPaths)
  .attr('d', d => (d ? `M${ d.join('L') }Z` : null))
  .on('mouseover', voronoiMouseover)
  .on('mouseout', voronoiMouseout)
  .on('click', voronoiClick);
  
  }

// Click handler for legend
function clickLegendHandler(keyId) {
  if (singleLineSelected) {
    const newEnabledKeys = singleLineSelected === keyId ? [] : [singleLineSelected, keyId];

    keysIds.forEach(currentKeyId => {
      keys[currentKeyId].enabled = newEnabledKeys.indexOf(currentKeyId) >= 0;
    });
  } else {
    keys[keyId].enabled = !keys[keyId].enabled;
  }

  singleLineSelected = false;

  redrawChart();

}

  // Hover functionality
  function voronoiMouseover(d) {
    legendsDate.text(timeFormatter(d.data.year));

    legendsValues.text(dataItem => {
      const value = totalsByDate[d.data.year][dataItem];

      return value;
    });

    d3.select(`#subject-${ d.data.keyId }`).classed('subject-hover', true);
    d3.select(`#subjectPredict-${ d.data.keyId }`).classed('subject-hover', true);

    hoverDot
      .attr('cx', () => rescaledX(d.data.year))
      .attr('cy', () => rescaledY(d.data.count));
  }

  function voronoiMouseout(d) {
    if (d) {
      d3.select(`#subject-${ d.data.keyId }`).classed('subject-hover', false);
      d3.select(`#subjectPredict-${ d.data.keyId }`).classed('subject-hover', false);
    }
  }

  // Further click handling for single line selection
  function voronoiClick(d) {
      if (singleLineSelected) {
        singleLineSelected = false;
  
        redrawChart();
      } else {
        const keyId = d.data.keyId;
  
        singleLineSelected = keyId;
  
        redrawChart([keyId]);
      }
  }


  // Zoom functionality
  function zoomed() {
    const transformation = d3.event.transform;

    const rightEdge = Math.abs(transformation.xScale) / transformation.k + width / transformation.k;
    const bottomEdge = Math.abs(transformation.yScale) / transformation.k + height / transformation.k;

    if (rightEdge > width) {
      transformation.xScale = -(width * transformation.k - width);
    }

    if (bottomEdge > height) {
      transformation.yScale = -(height * transformation.k - height);
    }

    // X & Y zoom transforms
    rescaledX = transformation.rescaleX(xScale);
    rescaledY = transformation.rescaleY(yScale);

    // Axis zoom scaling
    xAxisElement.call(xAxis.scale(rescaledX));
    yAxisElement.call(yAxis.scale(rescaledY));

    // Rescale lines on zoom
    
    if (futurePrediction === true) {
      linesContainer.selectAll('.line')
      .attr('d', keyId => {
        return d3.line()
          .curve(d3.curveMonotoneX)
          .x(d => rescaledX(d.year))
          .y(d => rescaledY(d.count))(keys[keyId].data.slice(0, -3));
      });
    linesContainer.selectAll('.dashed')
      .attr('d', keyId => {
        return d3.line()
          .curve(d3.curveMonotoneX)
          .x(d => rescaledX(d.year))
          .y(d => rescaledY(d.count))(keys[keyId].data.slice(9));
      });
    } else {
      linesContainer.selectAll('.line')
        .attr('d', keyId => {
          return d3.line()
            .curve(d3.curveMonotoneX)
            .x(d => rescaledX(d.year))
            .y(d => rescaledY(d.count))(keys[keyId].data);
      });
    }


    voronoiGroup
      .attr('transform', transformation);
  }

    chart.node();
    setSvg(svgm);
}, [data, chartAreaHeight, svgContainer, i18n.language, futurePrediction]);

  return (
    <div>
      <svg className="thesesGraph" id="chart" ref={refChart} />
    </div>
  );
};

export default TheseusGraph;
import React, { useState, useEffect, forwardRef } from "react";
import { useTranslation } from "react-i18next";
import { useDispatch, useSelector } from "react-redux";
import {
  Form,
  Popup,
  Icon,
  Input,
  Segment,
  Button,
  Select,
} from "semantic-ui-react";
import DatePicker from "react-datepicker";

import { searchJobs } from "../../reducers/jobsReducer";
import { getProfile } from "../../reducers/profileDataReducer";

import { MultiSelectPureDropdown } from "../MultiSelectPureDropdown";

import { AREA_LIST_OPTIONS } from "../../constants/area_list";

const JobSearch = () => {
  const { t } = useTranslation();
  const dispatch = useDispatch();

  const profiles = useSelector((state) => state.profiles);
  const profileData = useSelector((state) => state.profileData);

  const getStartDate = () => {
    let d = new Date();
    d.setMonth(d.getMonth() - 6);
    return d;
  };

  const [selectedArea, setSelectedArea] = useState([]);
  const [areaSelectionError, setAreaSelectionError] = useState(null);
  const [skills, setSkills] = useState("");
  const [skillError, setSkillError] = useState(null);
  const [selectedProfile, setSelectedProfile] = useState(null);
  const [profileError, setProfileError] = useState(null);
  const [startDate, setStartDate] = useState(getStartDate());

  // Ordering the list of profiles by date created, newest first. utilising Api's id
  const reformattedData = profiles.sort((a,b) => (a.id < b.id));
  const profileOptions = reformattedData.map((p) => ({
    key: p.id,
    text: p.name,
    value: p.name,
  }));

  // This is a custom input component for ract-datepicker, using semantic dropdown css classes to make it look like an input/selection
  const CustomCalendarInput = forwardRef(({ value, onClick }, ref) => (
    <div className="ui selection dropdown" onClick={onClick}>
      <Icon name="calendar outline" />
      <span ref={ref} style={{ marginLeft: "16px" }}>
        {value}
      </span>
    </div>
  ));

  useEffect(() => {
    if (
      selectedProfile !== null &&
      profileData[selectedProfile] === undefined
    ) {
      let data =selectedProfile;
      let buff = new Buffer(data);
      let encodedProfileName = buff.toString('base64');

      dispatch(getProfile(encodedProfileName));
    }
  }, [selectedProfile, profileData, dispatch]);

  const handleProfileChange = (e, data) => {
    if (data.value) {
      setSelectedProfile(data.value);
    } else {
      setSelectedProfile(null);
    }
  };

  const handleSkillsChange = (e, data) => {
    e.preventDefault();
    if (skillError !== null) {
      setSkillError(null);
    }
    setSkills(data.value);
  };

  const handleAreaChange = (e, data) => {
    e.preventDefault();
    if (areaSelectionError !== null) {
      setAreaSelectionError(null);
    }
    setSelectedArea(data.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // if area is not selected set error and return
    if (selectedArea.length === 0) {
      setAreaSelectionError(t("error.cityError"));
      return;
    }

    /* if profile selected use profile skills to search for jobs unless profile is empty and return */
    if (selectedProfile != null) {
      if (profileData[selectedProfile].include_skills.length === 0) {
        setProfileError(t("error.profileSkillsEmpty"));
      } else {
        dispatch(
          searchJobs(
            selectedArea.toString(),
            startDate,
            profileData[selectedProfile].include_skills.toString()
          )
        );
      }
      return;
    }

    /* if user input skills and it is valid skill(more than 2 characters) search using inputted skills and return */
    if (skills.length > 2)
      dispatch(searchJobs(selectedArea.toString(), startDate, skills));
    else {
      setSkillError(t("error.skillError"));
    }
  };

  return (
    <Segment clearing>
      <Form onSubmit={handleSubmit}>
        <Form.Group widths="equal">
          <Form.Field
            // id="form-input-control-skills"
            control={Input}
            icon="search"
            iconPosition="left"
            value={skills}
            disabled={selectedProfile !== null}
            placeholder={t("jobs.skillPlaceholder")}
            onChange={handleSkillsChange}
            error={skillError}
            label={{
              children: (
                <>
                  <label className="label">{t("jobs.enterSkill")}</label>
                  <Popup
                    on="click"
                    trigger={<Icon color="grey" name="question circle" />}
                    content={t("popup.skill")}
                    position="bottom center"
                  />
                </>
              ),
            }}
          />
        </Form.Group>
          <Form.Group widths="equal">
          <Form.Field
            id="form-select-control-profile"
            aria-label="select-profile"
            control={Select}
            clearable
            options={profileOptions}
            onChange={handleProfileChange}
            placeholder={t("jobs.profilePlaceholder")}
            disabled={profiles.length === 0 || skills.length > 0}
            selectOnBlur={false}
            error={profileError}
            label={{
              children: (
                <>
                  <label className="label">{t("jobs.selectProfile")}</label>
                  <Popup
                    on="click"
                    trigger={<Icon color="grey" name="question circle" />}
                    content={t("popup.profile")}
                    position="bottom center"
                  />
                </>
              ),
            }}
          />

          {/* <div style={{width: "24cm" }}> */}
          <Form.Field
            id="form-mult-select-control-areas"
            control={MultiSelectPureDropdown}
            fluid
            search
            clearable
            options={AREA_LIST_OPTIONS}
            placeholder={t("jobs.enterCities")}
            onChange={handleAreaChange}
            error={areaSelectionError}
            extra-error={areaSelectionError}
            style= {{ overFlow: "hidden" }}
            label={{
              children: (
                <>
                  <label className="label">{t("jobs.enterCities")}</label>
                  <Popup
                    on="click"
                    trigger={<Icon color="grey" name="question circle" />}
                    content={t("popup.city")}
                    position="bottom center"
                  />
                </>
              ),
            }}
          />
          <Button style={{ padding: "12px", paddingLeft: "24px", paddingRight: "24px", float: "right", margin: "24px 9px auto auto" }}
            type="submit"
            // size="medium"
            color="blue"
            content={t("jobs.search")}
            floated="right"
          />
        </Form.Group>

          { // ******* This part is removed due to integration/updation of the API in the backend ... 
            // ... as the new API does not consider the starting time parameter as a search criteria.
          /*<Form.Group>
          <Form.Field
            id="form-date-picker-control-date"
            width={3}
            control={DatePicker}
            selected={startDate}
            onChange={(date) => setStartDate(date)}
            dateFormat="yyyy-MM"
            showMonthYearPicker
            maxDate={new Date()}
            customInput={<CustomCalendarInput />}
            label={{
              children: (
                <>
                  <label className="label">{t("jobs.startingDate")}</label>
                  <Popup
                    on="click"
                    trigger={<Icon color="grey" name="question circle" />}
                    content={t("popup.date")}
                    position="bottom center"
                  />
                </>
              ),
            }}
          />*
        </Form.Group>
          /}
        {/* </div> */}
      </Form>
    </Segment>
  );
};

export const JobSearchInput = React.memo(JobSearch);

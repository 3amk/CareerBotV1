import React from "react";
import CourseCard from "./CourseCard";
import NoResultSegement from "../NoResultSegment";
import { Header, Item, Segment } from "semantic-ui-react";
import { useTranslation } from "react-i18next";

const CourseList = ({ courses, isLoading }) => {
  const { t } = useTranslation();
  if (!courses) return null;
  if (!isLoading && courses.length < 1) return <NoResultSegement />;
  return (
    <div>
      <Segment attached="top">
        <Header as="h4" content={courses.length + " " + t("courses.results")} />
      </Segment>
      <Segment attached>
        <Item.Group relaxed unstackable divided>
          {courses.map((course, i) => (
            <CourseCard key={i} course={course} />
          ))}
        </Item.Group>
      </Segment>
    </div>
  );
};

export default CourseList;

import React, { useState } from "react";
import { Item } from "semantic-ui-react";
import { useTranslation } from "react-i18next";
import { trimString } from "../../utils/helperFunctions";
import CourseDetailModal from "../CourseDetailModal";

const CourseItem = ({ course }) => {
  const { t } = useTranslation();
  const [modalOpen, setModalOpen] = useState(false);

  return (
    <>
      <CourseDetailModal
        course={course}
        modalOpen={modalOpen}
        onClose={() => setModalOpen(false)}
      />
      <Item
        // fluid
        // onClick={() => window.open(course.url, '_blank')}
        onClick={() => setModalOpen(true)}
      >
        <Item.Content>
          <Item.Header as="a">{course.title}</Item.Header>
          <Item.Meta className="item-margin">
          <strong>{t("courses.language")}: </strong> 
            {course.language ? course.language.toUpperCase() : "Unknown"}
          </Item.Meta>
          <Item.Description>
          {t("courses.description")}:
            {trimString(course.description, 200)}
          </Item.Description>
          <Item.Meta className="item-margin">
          <strong>{t("courses.school")}: </strong> 
          {/*course.author.toUpperCase()*/}
          {course.school.toUpperCase()}
          </Item.Meta>
        </Item.Content>
      </Item>
    </>
  );
};

export default CourseItem;
// line 35: {course.author.toUpperCase()}
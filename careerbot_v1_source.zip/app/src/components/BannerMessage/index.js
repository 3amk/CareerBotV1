import React from "react";
import { Button, Grid, Icon } from "semantic-ui-react";

import "./banner.css";

const BannerMessage = ({ BannerMessageChild, onClose }) => {
  return (
    <div className="temp-banner">
      <Grid>
        <Grid.Column width="14">
          <BannerMessageChild />
        </Grid.Column>
        <Grid.Column width="2">
          <Button
            className="humberger"
            icon
            basic
            size="big"
            onClick={onClose}
            floated="right"
          >
            <Icon name="close" size="large" />
          </Button>
        </Grid.Column>
      </Grid>
    </div>
  );
};

export default BannerMessage;

import React, { useState } from "react";
import { Icon, Item, Label } from "semantic-ui-react";
import { useTranslation } from "react-i18next";

import JobDetailModal from "../JobDetailModal";

import {
  dateformat,
  trimString,
  stringToArray,
} from "../../utils/helperFunctions";

const JobCard = ({ job }) => {
  const { t, i18n } = useTranslation();
  const [modalOpen, setModalOpen] = useState(false);

  const openModal = () => setModalOpen(true);

  const closeModal = () => {
    setModalOpen(false);
  };

  const formatted_date = dateformat(job.time, i18n.language);
  const jobTitle = trimString(job.id.split(",")[0], 60);
  const jobExtra = () => {
    const i = job.id.indexOf(",");
    let extra = job.id.slice(i + 1);
    if (extra.length > 60) {
      extra = trimString(job.id.slice(i + 1), 60) + "...";
    }
    return extra;
  };

  return (
    <>
      <JobDetailModal job={job} modalOpen={modalOpen} onClose={closeModal} />
      <Item onClick={() => openModal()}>
        <Item.Content>
          <Item.Header as="a">
            {jobTitle ? jobTitle : trimString(job.id, 60)}
          </Item.Header>
          <Item.Description>{jobExtra()}</Item.Description>
          <Item.Meta className="item-margin">
            <span>
              <Icon color="green" name="check" />{" "}
              <span className={"base-text-color bold"}>
                {stringToArray(job.skills_that_match).length}
              </span>{" "}
              {t("jobs.matchingSkills")}
            </span>
            <span>
              <Icon color="red" name="remove" />
              <span className={"base-text-color bold"}>
                {stringToArray(job.required_skills_not_found_from_cv).length}
              </span>{" "}
              {t("jobs.missingSkills")}
            </span>
          </Item.Meta>
          <Item.Meta className="item-margin">
            <Label content= {t("jobs.relevancy")} />
            <Label
              color={job.relevancy >= 0.8 ? "blue" : null}
              circular
              basic
              content={parseFloat(job.relevancy).toFixed(1)}
            />
          </Item.Meta>
          <Item.Meta className="item-margin">{formatted_date}</Item.Meta>
        </Item.Content>
      </Item>
    </>
  );
};

export default JobCard;

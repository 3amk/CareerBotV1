import React from "react";
import { Select } from "semantic-ui-react";
import i18n from 'i18next';

const multiSelect = (props) => {

  return (
    <Select
      multiple
      selection
      noResultsMessage={i18n.t("profile.noResult")}
      renderLabel={(label) => ({
        color: "blue",
        content: label.text,
      })}
      {...props}
    />
  );
};

const areProsEqual = (prev, next) => {
  if (prev.options.length !== next.options.length) return false;
  else if (prev.disabled !== next.disabled) return false;
  else if (prev.placeholder !== next.placeholder) return false;
  else if (prev.error !== next.error) return false;
  else if (prev["extra-error"] !== next["extra-error"]) return false;
  else return true;
};

export const MultiSelectPureDropdown = React.memo(multiSelect, areProsEqual);

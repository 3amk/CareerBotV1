import React from "react";
import { Loader, Segment } from "semantic-ui-react";
import { useTranslation } from "react-i18next";

import "./Loading.css";

const WithLoading = (Component) => {
  return function WithLoadingComponent({
    isLoading,
    loadingMessage,
    loadingText,
    ...props
  }) {
    const { t } = useTranslation();
    if (!isLoading) return <Component {...props} />;
    return (
      <Segment style={{ border: "0px", boxShadow: "none", overflow: "hidden" }}>
        <div className="column padless-column" style={{ paddingTop: "30px" }}>
          <div className="cube">
            <div className="side"></div>
            <div className="side"></div>
            <div className="side"></div>
            <div className="side"></div>
            <div className="side"></div>
            <div className="side"></div>
          </div>

        <div style={{ padding: "50px 0px 50px 0px" }}>
          <h4 className="loading-text">{loadingText}</h4>
          <p className="loading-message">{loadingMessage}</p>
        </div>
      </div>
    </Segment>
    );
  };
};

export default WithLoading;

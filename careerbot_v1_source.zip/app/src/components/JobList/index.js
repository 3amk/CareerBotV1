import React from "react";
import { useTranslation } from "react-i18next";
import { Header, Item, Segment } from "semantic-ui-react";
import JobCard from "../JobCard";
import NoResultSegment from "../NoResultSegment";

const JobList = ({ isLoading, jobs }) => {
  const { t } = useTranslation();
  if (!jobs) return null;

  if (!isLoading && jobs.length < 1) return <NoResultSegment />;
  return (
    <div>
      <Segment attached="top">
        <Header as="h4" content={jobs.length + " " + t("courses.results")} />
      </Segment>
      <Segment attached>
        <Item.Group relaxed unstackable divided>
          {jobs.map((job, i) => (
            <JobCard key={i} job={job} />
          ))}
        </Item.Group>
      </Segment>
    </div>
  );
};

export default JobList;

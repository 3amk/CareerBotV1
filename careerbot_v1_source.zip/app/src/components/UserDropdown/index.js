import React from "react";
import { useTranslation } from "react-i18next";
import { Dropdown, Icon } from "semantic-ui-react";

import "./userDropdown.css";

const UserDropdown = ({ user, handleLogout }) => {
  const { t } = useTranslation();
  const trigger = (
    <span className="userDropdown">
      <Icon name="user" />
      {user}
    </span>
  );
  const options = [
    {
      key: "user",
      text: (
        <span>
          {t("notification.login")} <strong>{user}</strong>
        </span>
      ),
      disabled: true,
    },
    { key: "logout", text: t("user.logout"), value: "logout" },
  ];
  const onChange = (e, data) => {
    e.preventDefault();
    if (data.value === "logout") handleLogout();
  };
  return (
    <Dropdown
      aria-label="account dropdown selection"
      className="userDropdown"
      trigger={trigger}
      options={options}
      direction="left"
      onChange={onChange}
      selectOnBlur={false}
      pointing
    />
  );
};

export default UserDropdown;

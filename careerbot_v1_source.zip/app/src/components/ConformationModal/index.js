import React from "react";
import { useTranslation } from "react-i18next";
import { Modal } from "semantic-ui-react";

const ConformationModal = ({
  modalOpen,
  onClose,
  onConfirm,
  onCancel,
  headerContent,
  confirmContent,
}) => {
  const { t } = useTranslation();
  return (
    <Modal
      open={modalOpen}
      onClose={onClose}
      header={headerContent ? headerContent :  t("app.areYouSure")}
      actions={[
        {
          key: "delete",
          content: confirmContent ? confirmContent : t("profile.deleteBtn"),
          color: "red",
          onClick: onConfirm,
        },
        {
          key: "cancel",
          content: t("profile.cancel"),
          color: "blue",
          onClick: onCancel,
        },
      ]}
    />
  );
};

export default ConformationModal;

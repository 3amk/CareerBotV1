import React from "react";
import { Header, Segment } from "semantic-ui-react";

const PageHeading = ({ headingTxt, contentTxt }) => {
  return (
    <div className="page-heading">
      <Segment basic>
        <Header as="h1" textAlign="center" content={headingTxt} />
        <p>{contentTxt}</p>
      </Segment>
    </div>
  );
};

export default PageHeading;

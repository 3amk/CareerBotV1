import React from "react";
import { useTranslation } from "react-i18next";
import { Header, Icon, Segment } from "semantic-ui-react";

const NoResultSegment = ({ message, icon }) => {
  const { t } = useTranslation();
  return (
    <Segment placeholder>
      <Header icon>
        <Icon name={icon ? icon : "search minus"} />
        {message ? message : t("courses.noResult")}
      </Header>
    </Segment>
  );
};

export default NoResultSegment;

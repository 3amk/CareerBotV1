import { Search, Label, Button, Segment } from "semantic-ui-react";
import { useTranslation } from "react-i18next";

const resultRenderer = ({ title }) => (
  <Label style={{ minWidth: "100px" }} size="big" content={title} />
);

const SearchInputSkills = ({
  addButtonHandler,
  state,
  handleSearchChange,
  onResultSelect,
  placeholder,
}) => {
  const { t } = useTranslation();

  return (
    <div style={{ marginTop: "24px", marginBottom: "8px"}}>
      <Search
        input={{
          input: "text",
          placeholder: placeholder,
          fluid: true
        }}
        loading={state.isLoading}
        onResultSelect={onResultSelect}
        onSearchChange={handleSearchChange}
        results={state.results}
        noResultsMessage={t("profile.noResult")}
        value={state.value}
        resultRenderer={resultRenderer}
        autoFocus
        fluid
      />
      {/*{<Segment basic clearing>
        <Button
          content={t("profile.add")}
          disabled={state.selection === null}
          onClick={addButtonHandler}
          color="blue"
          floated="right"
        />
      </Segment>}*/}
    </div>
  );
};

export default SearchInputSkills;

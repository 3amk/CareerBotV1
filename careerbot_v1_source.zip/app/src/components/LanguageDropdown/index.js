import React from "react";
import { useTranslation } from "react-i18next";
import { Dropdown } from "semantic-ui-react";

const languageOptions = [
  {
    key: "Suomi",
    text: "Suomi",
    value: "fi",
  },
  {
    key: "English",
    text: "English",
    value: "en",
  },
];

const LanguageDropdown = () => {
  const { i18n } = useTranslation();

  const languageHandler = (e, data) => {
    let newLang = data.value;
    if (newLang !== i18n.language) {
      i18n.changeLanguage(newLang);
    }
  };
  return (
    <Dropdown
      style={{ fontSize: "14px" }}
      aria-label="language-selection"
      options={languageOptions}
      defaultValue={i18n.language}
      onChange={languageHandler}
      selection
      compact
    />
  );
};

export default LanguageDropdown;

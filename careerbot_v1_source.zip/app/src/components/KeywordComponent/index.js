import React from "react";
import { useTranslation } from "react-i18next";
import { Header, Label, Form, Segment } from "semantic-ui-react";

const KeywordComponent = ({ keywords }) => {
  const { t } = useTranslation();
  return (
    <div style={{ margin: "-14px 0px 16px 0px" }}>
      <Segment.Group>
        <Segment>
          <Header as="h4">{t("courses.keywords")}:</Header>
        </Segment>
        <Segment className="keyContainer">
          <Form>
            <Form.Group unstackable="false">
              <Form.Field>
                <Label.Group color="green" size="large" style={{ marginBottom: "-20px" }}>
                  {keywords.map((skill, i) => (
                    <Label key={i} content={skill} style={{ borderRadius: "99px"}} />
                  ))}
                </Label.Group>
              </Form.Field>
            </Form.Group>
          </Form>
        </Segment>
      </Segment.Group>
    </div>
  );
};

export default KeywordComponent;

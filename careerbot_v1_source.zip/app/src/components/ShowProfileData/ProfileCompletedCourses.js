import React, { useCallback, useEffect, useReducer, useState } from "react";
import { useDispatch } from "react-redux";
import { useTranslation } from "react-i18next";
import {toast} from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { Header, Button, Segment, Checkbox } from "semantic-ui-react";

import SearchReducer, { initialState } from "../../reducers/searchReducer";
import { getCourseByText, getCourseByCode } from "../../services/courses";
import { setNotification } from "../../reducers/notificationReducer";

import SearchInput from "../SearchInput";
import ConformationModal from "../ConformationModal";
import "./skillprofile.css";

/*
 * Show list of completed courses related to single selected profile
 */
const ProfileCompletedCourses = ({
  addCompletedCourse,
  deleteCompletedCourses,
  profileData,
}) => {
  const { t } = useTranslation();

  const [completedCourses, setCompletedCourses] = useState([]);
  const [checkedCourses, setCheckedCourses] = useState([]);
  const [state, dispatch] = useReducer(SearchReducer, initialState);
  const [deleteConfirm, setDeleteConfirm] = useState({
    open: false,
    _checkedCourses: [],
  });

  const dispatchNotification = useDispatch();

  const timeoutRef = React.useRef();

  const schools = "metropolia,laurea,haaga-helia,HAMK,XAMK,metropolia-AMKosaaja,laurea-AMKosaaja,haaga-helia-AMKosaaja,HAMK-AMKosaaja,XAMK-AMKosaaja";

  useEffect(() => {
    const fetchAllCourses = async (courses) => {
      try {
        const results = await Promise.allSettled(
          courses.map((c) => getCourseByCode("", schools, c, null))
        );

        const courseTitles = results
          .filter((r) => r.status === "fulfilled" && r.value.data.length > 0)
          .map((e) => e.value);
        setCompletedCourses(courseTitles);
      } catch (error) {
        console.log(error);
      }
    };
    if (profileData.courses.length > 0) fetchAllCourses(profileData.courses);
  }, [profileData]);

  useEffect(() => {
    return () => {
      clearTimeout(timeoutRef.current);
    };
  }, []);

  const handleSearchChange = useCallback((e, data) => {
    clearTimeout(timeoutRef.current);
    dispatch({ type: "START_SEARCH", query: data.value });

    timeoutRef.current = setTimeout(() => {
      if (data.value.length === 0) {
        dispatch({ type: "CLEAN_QUERY" });
        return;
      } else if (data.value.length > 3) {
        /* HeadAI api will not return auto completetion for courses if there is less than 4 characters that is 1-3 characters will not work */
        getCourseByCode(data.value, schools).then((courses) => {
          dispatch({
            type: "FINISH_SEARCH",
            results: courses.data.map((c) => ({
              title: c.title,
              id: c.course_id,
            })),
          });
        });
      }
    }, 1000);
  }, []);


  const onResultSelect = (e, data) => {
    e.preventDefault();
    dispatch({
      type: "UPDATE_SELECTION",
      value: data.result.title,
      selection: data.result.id,
    })  
    };

  const searchAddbuttonHandler = (e) => {
    let temp=0;
    const duplicate = (course) =>{
      if(course.courseId!=state.selection){
        temp+=1;
      }
    }
      completedCourses.map(duplicate); 
    if(completedCourses.length==0){
    e.preventDefault();
    if (state.selection !== null) {
      dispatch({ type: "CLEAN_QUERY" });
      addCompletedCourse(state.selection);
    }
  } else if(completedCourses.length>0 && temp==completedCourses.length){
    e.preventDefault();
    if (state.selection !== null) {
      dispatch({ type: "CLEAN_QUERY" });
      addCompletedCourse(state.selection);
    }
  } else {
    dispatchNotification(
      setNotification(
        t("notification.duplicateCourse"),
        5,
        "error"
      )
    )
  }
  };

  const checkedCourseHandler = (e, data) => {
    if (data.checked) {
      setCheckedCourses([...new Set([...checkedCourses, data.value])]);
    } else {
      const filtered = checkedCourses.filter((c) => c !== data.value);
      setCheckedCourses(filtered);
    }
  };

  const deleteCheckedCourses = (e) => {
    e.preventDefault();
    if (checkedCourses.length > 0) {
      deleteCompletedCourses(checkedCourses);
    }
    console.log("checkedCourses", checkedCourses);
    console.log("completedCourses", completedCourses);
    if(completedCourses.length == 1 || checkedCourses.length == completedCourses.length){
      const empty= [];
      setCompletedCourses(empty);
      setCheckedCourses(empty);
      //window.location.reload();
    };
  };

  return (
    <div>
      <SearchInput
        addButtonHandler={searchAddbuttonHandler}
        state={state}
        handleSearchChange={handleSearchChange}
        onResultSelect={onResultSelect}
        placeholder={t("profile.searchCourses")}
      />
      <Header as="h3">{t("profile.completedTitle")}</Header>
      {completedCourses.map((c, i) => (
        <div key={i} className="big-checkbox">
          <Checkbox
            label={c.data[0].title}
            value={c.courseId}
            checked={checkedCourses.includes(c.courseId)}
            onChange={checkedCourseHandler}
          />
        </div>
      ))}
      <Segment basic clearing>
        <Button
          style={{ marginLeft: "24px", marginRight: "-12px" }}
          negative
          disabled={checkedCourses.length <= 0}
          onClick={() =>
            setDeleteConfirm({
              open: true,
              _checkedCourses: [],
            })
          }
          content={t("profile.deleteSelected")}
          floated="right"
        />
      </Segment>
      <ConformationModal
        modalOpen={deleteConfirm.open}
        onClose={() => setDeleteConfirm({ ...deleteConfirm, open: false })}
        onConfirm={deleteCheckedCourses}
        onCancel={() => setDeleteConfirm({ ...deleteConfirm, open: false })}
      />
    </div>
  );
};

export default ProfileCompletedCourses;

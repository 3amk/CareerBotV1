import React, {useRef, useState } from "react";
import { useTranslation } from "react-i18next";
import { Modal, Form, Grid, Button } from "semantic-ui-react";
import PropTypes, { bool } from "prop-types";

/*
 * A modal to input new profile name, the component will handle all form errors.
 * The open state is controlled by parent component and the new profile name will be passed to parent component if no erros present.
 */
const CreateProfileModal = ({ modalOpen, onClose, createNewProfile }) => {
  const { t } = useTranslation();

  // const ref = useRef(); 

  const [error, setError] = useState(null);
  const [value, setValue] = useState("");

  const handleBlur = (event) => {
    if (event.target.validity.patternMismatch) {
      //ref.current.focus(); 
      setError(true);
    }
  };

  function style(error) {
    if (error) {
      return { backgroundColor: "rgba(255, 0, 0, 0.5)" };
    }
  }
 
  const handleChange = (event) => {
    let reg = /[`!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\?~ÄäåÅöÖ]/;
    if(event.target.value === "" || reg.test(event.target.value)===true){
      console.log("Error found")
      setError(true);
    }
    else{
      setValue(event.target.value);
      console.log("No error")
      setError(false);
    }
  }

  const submitProfile = (e) => {
    //e.preventDefault();
    if (value.length > 2 && error==false) {
      createNewProfile(value);
    } else {
      setError({
        content: t("error.profileName"),
        pointing: "below",
      });

      setTimeout(() => {
        setError(null);
      }, 5000);
    }
  };

  const handleEnterKey=(e)=>{
    if(e.keyCode == 13){
       submitProfile();
    }
}

  return (
    <Modal open={modalOpen} centered={true} size="mini" onClose={onClose}>
      <Modal.Header>{t("profile.createProfile")}</Modal.Header>
      <Modal.Content>
        <Form onSubmit={submitProfile}>
          <Form.Input
            placeholder={t("profile.profile")}
            onChange={handleChange}
            onBlur={handleBlur}
            autoFocus
            onKeyDown={handleEnterKey}
            // ref={ref} 
            style={style(error)}
            error={error && (
              <p role="alert" style={{ color: "rgb(255, 0, 0)" }}>
                <em>{t("error.errorMessage1")}</em> {t("error.errorMessage2")} <em>{t("error.errorMessage3")}</em> {t("error.errorMessage4")} 
              </p>
            )}
          />
          <Grid columns={2}>
            <Grid.Column>
              <Form.Button onClick={onClose} floated="left" color="red">
                {t("profile.cancel")}
              </Form.Button>
            </Grid.Column>
            <Grid.Column>
              <Button
                color="blue"
                floated="right"
                content={t("profile.create")}
                onClick={submitProfile}
              />
            </Grid.Column>
          </Grid>
        </Form>
      </Modal.Content>
    </Modal>
  );
};

CreateProfileModal.prototype = {
  // open state of modal
  modalOpen: PropTypes.bool.isRequired,
  // function to call when modal is closing, update openstate on parent component
  onClose: PropTypes.func.isRequired,
  // Function from parent to create new profile, the function accept profile name as first argument
  createNewProfile: PropTypes.func.isRequired,
};

export default CreateProfileModal;

import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import { useDispatch} from "react-redux";
//import { textFromDoc } from "./reducers/profilesReducers"
import {useForm} from "react-hook-form";
import {
  Header,
  Form,
  Popup,
  Icon,
  Container,
  Select,
  Button,
  Segment,
  TextArea,
  Input,
  Label
} from "semantic-ui-react";
import { trimString } from "../../utils/helperFunctions";
import { setNotification } from "../../reducers/notificationReducer";


import "./skillprofile.css";

/*
 * Show list of documents related to single selected profile
 */
const ProfileDocuments = ({ profileData, updateProfileDocument }) => {
  const dispatch = useDispatch();
  const { t } = useTranslation();
  // const {register, handleSubmit} = useForm();

  const [documentType, setDocumentType] = useState("");
  const [doctypeError, setDoctypeError] = useState(null);
  const [documentError, setDocumentError] = useState(null);
  const [documentText, setDocumentText] = useState("");
  const [uploadFile, setUploadFile] = useState("");
  const [uploadResponse, setUploadResponse] = useState();

  const documentOptions = [
    { key: "koski", text: "Koski/CV Data", value: "Koski_Data" },
    //{ key: "cv", text: "CV", value: "CV" },
    { key: "file", text: "File Upload", value: "File_Upload" },
  ];

  const onSubmit = (e) => {
    e.preventDefault();
    /**if(documentText=="File_Upload"){
      console.log("File_Upload submit");
    }**/
    if (documentType && documentText.length > 0) {
      updateProfileDocument(documentText, documentType);
      setDocumentType(null);
      setDocumentText("");
    } else {
      if (!documentType) {
        setDoctypeError({
          content: t("error.docType"),
          pointing: "below",
        });
      }
      if (!documentText) {
        setDocumentError({
          content: t("error.docInput"),
          pointing: "below",
        });
      }
    }
  };

  const onFileUpload = (e) => { 
    setDocumentType(documentOptions[1].value)
    setDocumentText("")
    e.preventDefault();
    setUploadFile(e.target.files[0])
    // Details of the uploaded file 
    //console.log("File is: ", uploadFile);
  }

  const onSubmitFile=(e)=>{
    e.preventDefault();
    const formData = new FormData();
    formData.append("file", uploadFile, uploadFile.name);
    // Details of the uploaded file
      // console.log("uploaded file", uploadFile);
      if (!uploadFile) {
        setDoctypeError({
          content: t("error.docType"),
          pointing: "below",
        });
        return;
      }
      if (uploadFile) {
          //dispatch(
            //textFromDoc(uploadFile)// start from here!!!!!!!!!!!!!!!
          //);
          dispatch(
            setNotification(
              // `${t("notification.duplicateCourse")} "${state.value}"`,
              t("notification.fileInfo"),
              5,
              "alert"
            ))
      fetch('/api/v1/document_to_text',{
        method: 'POST',
        body: formData,
        })
        .then(response => response.json())
        .then(success => {
          var text = success.text;
          text = text.replace("\u0000","");
          setDocumentText(text);
        })
        .catch(error => console.log(error)
      );
    } 
};

const fileName = () => {
  if(uploadFile) {
    return (
      uploadFile.name
    )
  } else {
    return (
      t("profile.fileEmpty")
    )
  }
}

const activeButton = () => {
  if(documentType !== "Koski_Data") {
    return (
      "ui blue button"
    )
  } else {
    return (
      "ui blue disabled button"
    )
  }
}

const fileData =() => {
    
  if (uploadFile) {
     
    return (
      <div>
        <h3>File Details:</h3>
          <p>File Name: {uploadFile.name}</p>
      </div>
    );
  } 
};

  const documentTypeChange=(e, data)=>{
    /**
    if(data.value=="File_Upload"){
      console.log("Testing1");
      //onFileUpload();
    }
    */
    setDocumentType(data.value)
  }

  return (
    <Container>
      <Segment clearing basic>
        {/* Document input Form with two sections type selection and input textarea */}
        <Form onSubmit={onSubmit}>
          <Form.Field
            id="form-selection-control-type"
            control={Select}
            options={documentOptions}
            placeholder={t("profile.docType")}
            value={documentType}
            onChange={documentTypeChange}
            error={doctypeError}
            label={{
              children: (
                <>
                  <label className="label">{t("profile.selectDocType")}</label>
                  <Popup
                    on="click"
                    trigger={<Icon name="question circle" />}
                    content={t("popup.docType")}
                    position="bottom center"
                  />
                </>
              ),
            }}
          />
          <Form>
            
        
          {/* <input disabled={documentType=="Koski_Data" || documentType==""}  */}
            {/* <div className="ui primary button" style={{ display: "flex", position: "relative", cursor: "pointer", alignItems: "center", justifyContent: "center" }}> */}
            <Segment.Group horizontal>
              <Segment>

                <div className={activeButton()} style={{ display: "flex", alignItems: "center", justifyContent: "center", position: "relative", float: "left" }}>
                  <input 
                    disabled={documentType=="Koski_Data"} 
                    type="file" 
                    id="file"
                    onChange={onFileUpload}
                    className="fileInput"
                    />
                  <label type="file">{t("profile.fileUpload")}</label>
                </div>
                <Label
                  className="ui basic button"
                  style={{ border: "0px rgba(0, 0, 0, 0)", pointerEvents: "none", cursor: "initial", minHeight: "1em", fontSize: "1em", padding: "10px" }}
                >
                {fileName()}
                </Label>
                <Button 
                  disabled={documentType == "" || (documentType === "Koski_Data")
                  || (documentType === "File_Upload" && documentText.length!=0)}
                  color="blue"
                  floated="right"
                  content={t("profile.add")}
                  onClick={onSubmitFile}
                  style={{ float: "right" }}
                />
              </Segment>
            </Segment.Group>
         
          {/* <div>{fileData()}</div> */}
          </Form>
          <Form.Field
            // id="form-text-control-cv"
            // The above id stopped the popup from working
            rows="10"
            control={TextArea}
            maxLength={28340}
            disabled={documentType=="File_Upload" && documentText.length==0}
            placeholder={t("profile.descriptionPlaceholder")}
            value={documentText}
            onChange={(e, data) => setDocumentText(data.value)}
            error={documentError}
            label={{
              children: (
                <>
                  <label className="label">{t("profile.description")}</label>
                  {documentType !== "File_Upload" ? (
                  <Popup 
                  // disabled={documentType=="File_Upload"}
                  on="click"
                  trigger={<Icon name="question circle" />}
                  content={t("popup.docInput")}
                  position="bottom center"
                  
                />
                  ) : (
                    <Popup 
                    // disabled={documentType=="File_Upload"}
                    on="click"
                    trigger={<Icon name="question circle" />}
                    content={t("popup.docUpload")}
                    position="bottom center"
                    
                  />
                )}
                </>
              ),
            }}
          />
          <Button 
            disabled={documentType == "" || (documentType === "Koski_Data" && documentText.length == 0)
              || (documentType === "File_Upload" && documentText.length==0)}
            color="blue"
            floated="right"
            content={t("profile.add")}
          />
        </Form>
      </Segment>
      {/* CV text*/}
      <Segment attached="top">
        <Header as="h4">{t("profile.currentCv")}</Header>
      </Segment>
      <Segment attached>
        {profileData.text ? (
          <p style={{ fontSize: "14px" }}>{trimString(profileData.text, 900)}</p>
        ) : (
          <p style={{ fontSize: "14px" }}>{t("profile.cvStatus")}</p>
        )}
      </Segment>

      {/* Koksi data text*/}
      <Segment attached="top">
        <Header as="h4">{t("profile.koskiText")}</Header>
      </Segment>
      <Segment attached style={{ fontSize: "14px" }}>
        {profileData.koski_text ? (
          <p style={{ fontSize: "14px" }}>{trimString(profileData.koski_text, 900)}</p>
        ) : (
          <p style={{ fontSize: "14px" }}>{t("profile.koskiStatus")}</p>
        )}
      </Segment>
    </Container>
  );
};

export default ProfileDocuments;

import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useTranslation } from "react-i18next";
import { Button, Header, Grid, Icon, Menu, Segment } from "semantic-ui-react";
import PropTypes from "prop-types";

import ConformationModal from "../ConformationModal";
import ProfileSkills from "./ProfileSkills";
import ProfileDocuments from "./ProfileDocuments";
import ProfileCompletedCourses from "./ProfileCompletedCourses";

import { removeProfile } from "../../reducers/profilesReducers";
import {
  getProfile,
  updateProfileData,
} from "../../reducers/profileDataReducer";
import { setNotification } from "../../reducers/notificationReducer";
import { getSuggestedSkills } from "../../reducers/suggestedSkillsReducer";

/*
 * Shows the selected profile's data
 *
 */
const ShowProfileData = ({ selectedProfile }) => {
  const { t } = useTranslation();
  const dispatch = useDispatch();

  /*
   * data of selected profile and its skill suggestion keywords are saved in Redux store as key value pairs, where
   * the name of profile is key of the object and profile data as the value, this is done to load data of selected profile once
   */
  const profileData = useSelector(
    (state) => state.profileData[selectedProfile]
  );
  const suggestedSkills = useSelector(
    (state) => state.suggestedSkills[selectedProfile]
  );

  const [deleteConfirm, setDeleteConfirm] = useState({
    open: false,
    name: null,
  });

  // horizontal menu items
  const [menuItems, setMenuItems] = useState([
    t("profile.mySkills"),
    t("profile.certificates"),
    t("profile.courses"),
  ]);

  /* Menu items state hook funciton. This menus are My Skills, CV certificate and courses menu. */
  const [activeItem, setActiveItem] = useState(t("profile.mySkills"));
  useEffect(() => {
    setMenuItems([
      t("profile.mySkills"),
      t("profile.certificates"),
      t("profile.courses"),
    ]);
    setActiveItem(t("profile.mySkills"));
  }, [t]);

  /* Load the data for the selected profile if it does not exist in Redux store already */
  useEffect(() => {
    if (profileData === undefined) {
      let data = selectedProfile;
      let buff = new Buffer(data);
      let encodedProfileName = buff.toString('base64');
      dispatch(getProfile(encodedProfileName));
    }
  }, [dispatch, selectedProfile, profileData]);

  /* Load suggested skills if the profile includes skills and if suggested skills does not exist in Redux store already */
  useEffect(() => {
    if (
      profileData !== undefined &&
      profileData.include_skills.length > 0 &&
      suggestedSkills === undefined
    ) {
      const language = t("api.microcompetenciesLanguageCode");
      dispatch(getSuggestedSkills(profileData.include_skills, selectedProfile, language));
    }
  }, [dispatch, profileData, selectedProfile, suggestedSkills]);

  const deleteProfileHandler = async () => {
    try {
      const name = deleteConfirm.name;
      if (name !== null) {
        setDeleteConfirm({ open: false, name: null });
        dispatch(removeProfile(name));
        dispatch(
          setNotification(
            `${t("notification.deleteProfile")}: ${name}`,
            5,
            "success"
          )
        );
      }
    } catch (error) {
      dispatch(setNotification(`Error: can not delete profile`, 5, "error"));
    }
  };

  const updateProfile = (newProfileData) => {
    dispatch(updateProfileData(newProfileData, selectedProfile));
    dispatch(setNotification(t("notification.updateSkill"), 5, "success"));
  };

  const updateProfile_delete = (newProfileData) => {
    dispatch(updateProfileData(newProfileData, selectedProfile));
    dispatch(setNotification(t("notification.deleteSkill"), 5, "success"));
  };

  const addProfileSkill = (newSkill) => {
    try {
      const exist = profileData.include_skills.indexOf(newSkill);
      if (exist === -1) {
        updateProfile({
          ...profileData,
          include_skills: [...profileData.include_skills, newSkill].toString(),
          exclude_skills: profileData.exclude_skills.toString(),
          courses: profileData.courses.toString(),
        });
        const language = t("api.microcompetenciesLanguageCode");
        dispatch(
          getSuggestedSkills(
            [...profileData.include_skills, newSkill],
            selectedProfile,
            language
          )
        );
      } else {
        dispatch(setNotification(t("profile.skillAlreadyExist"), 3, "error"));
      }
    } catch (error) {
      console.log("Add profile error: ", error);
    }
  };

  const excludeProfileSkill = (skill) => {
    try {
      const new_include_skills = profileData.include_skills.filter(
        (skil) => skil !== skill
      );
      updateProfile_delete({
        ...profileData,
        include_skills: new_include_skills.toString(),
        exclude_skills: [...profileData.exclude_skills, skill].toString(),
        courses: profileData.courses.toString(),
      });
      const language = t("api.microcompetenciesLanguageCode");
      dispatch(getSuggestedSkills(new_include_skills, selectedProfile, language));
    } catch (error) {
      console.log("Update profile error: ", error);
    }
  };

  const undoExcludeProfileSkill = (skill) => {
    updateProfile({
      ...profileData,
      include_skills: [...profileData.include_skills, skill].toString(),
      exclude_skills: profileData.exclude_skills
        .filter((skil) => skil !== skill)
        .toString(),
      courses: profileData.courses.toString(),
    });
    const language = t("api.microcompetenciesLanguageCode");
    dispatch(
      getSuggestedSkills(
        [...profileData.include_skills, skill],
        selectedProfile,
        language
      )
    );
  };

  const addCompletedCourse = (courseId) => {
    updateProfile({
      ...profileData,
      include_skills: profileData.include_skills.toString(),
      exclude_skills: profileData.exclude_skills.toString(),
      courses: [...profileData.courses, courseId].toString(),
    });
  };

  const deleteCompletedCourses = (courses) => {
    const filteredCourses = profileData.courses.filter(
      (c) => !courses.includes(c)
    );
    updateProfile({
      ...profileData,
      include_skills: profileData.include_skills.toString(),
      exclude_skills: profileData.exclude_skills.toString(),
      courses: filteredCourses.toString(),
    });
  };

  const updateProfileDocument = (data, type) => {
    const updatedProfile = {
      ...profileData,
      include_skills: profileData.include_skills.toString(),
      exclude_skills: profileData.exclude_skills.toString(),
      courses: profileData.courses.toString(),
    };
    if (type === "Koski_Data") {
      updatedProfile["koski_text"] = data;
    } else {
      updatedProfile["text"] = data;
    }
    dispatch(updateProfileData(updatedProfile, selectedProfile));
    dispatch(
      setNotification(
        t("notification.newDocument"),
        5,
        "success"
      )
    );
  };

  const menuItemClickHandler = (e, { name }) => {
    setActiveItem(name);
  };

  return (
    <Segment loading={profileData === undefined} style={{ marginTop: "32px" }}>
      {/* Show selected profile data */}
      <Grid
        style={{ marginTop: "8px", marginBottom: "8px" }}
        verticalAlign="middle"
        columns={2}
      >
        {/* Profile name */}
        <Grid.Column computer="12" mobile="8" tablet="11">
          <Header color="grey" as="h3">
            {t("profile.profile")}:{" "}
            <span style={{ color: "#000000" }}>{selectedProfile}</span>
          </Header>
        </Grid.Column>

        {/* Delete profile button and confirm delete modal */}
        <Grid.Column computer="4" mobile="8" tablet="5">
          <Button
            color="red"
            onClick={() =>
              setDeleteConfirm({
                open: true,
                name: selectedProfile,
              })
            }
            floated="right"
            size="small"
          >
            {t("profile.deleteBtn")}
            <Icon style={{ marginLeft: "4px" }} name="trash alternate" />
          </Button>
        </Grid.Column>
      </Grid>
      {profileData && suggestedSkills && (
        <div>
          <div>
            <Menu color="blue" pointing secondary>
              {menuItems.map((item, i) => (
                <Menu.Item
                  key={i}
                  name={item}
                  active={activeItem === item}
                  onClick={menuItemClickHandler}
                />
              ))}
            </Menu>
          </div>
          <div>
            {activeItem === menuItems[0] && (
              <ProfileSkills
                addProfileSkill={addProfileSkill}
                excludeProfileSkill={excludeProfileSkill}
                undoExcludProfileSkill={undoExcludeProfileSkill}
                suggestedSkills={suggestedSkills?.suggestions || []}
                profileData={profileData}
              />
            )}
            {activeItem === menuItems[1] && (
              <ProfileDocuments
                profileData={profileData}
                updateProfileDocument={updateProfileDocument}
              />
            )}
            {activeItem === menuItems[2] && (
              <ProfileCompletedCourses
                addCompletedCourse={addCompletedCourse}
                deleteCompletedCourses={deleteCompletedCourses}
                profileData={profileData}
              />
            )}
          </div>
        </div>
      )}
      <ConformationModal
        modalOpen={deleteConfirm.open}
        onClose={() => setDeleteConfirm({ ...deleteConfirm, open: false })}
        onConfirm={deleteProfileHandler}
        onCancel={() => setDeleteConfirm({ ...deleteConfirm, open: false })}
        headerContent={`${t("profile.deleteMessage")}: "${selectedProfile}"`}
      />
    </Segment>
  );
};

// TODO: change fetching of profile data to use id instead of name
ShowProfileData.prototype = {
  // name of selectd profile
  selectedProfile: PropTypes.string.isRequired,
};

export default ShowProfileData;

import React, {useState, useCallback, useEffect, useReducer } from "react";
import { useTranslation } from "react-i18next";
import { Button, Header } from "semantic-ui-react";

import SearchReducer, { initialState } from "../../reducers/searchReducer";
import getWord from "../../services/wordSuggest";

import SearchInputSkills from "../SearchInputSkills";

import "./skillprofile.css";

/*
 * Show list of skills related to single selected profile
 */
const ProfileSkills = ({
  addProfileSkill,
  excludeProfileSkill,
  undoExcludProfileSkill,
  suggestedSkills,
  profileData,
}) => {
  const { t } = useTranslation();

  // TODO: make sure skill arrays retured from server does not include null as array item
  const currentSkills = profileData.include_skills
    .filter((s) => s !== "null")
    .sort((a, b) => a.localeCompare(b));
  const rejectedSkills = profileData.exclude_skills
    .filter((s) => s !== "null")
    .sort((a, b) => a.localeCompare(b));

  const [searchState, dispatch] = useReducer(SearchReducer, initialState);
  //const [text, setText] = useState('');
  let currentTimeoutRef;

  // this UseEffect can be removed 
  useEffect(() => {
  }, []);

  const handleSearchChange = useCallback((event, data) => {
    if(currentTimeoutRef)
    {
      clearTimeout(currentTimeoutRef);
    }
    let lowerText= data.value.toLowerCase();
    /*let reg = /^[a-z]+$/;
    if(event.target.value != "" && reg.test(event.target.value)!=true){
      //console.log("Error found")
      setText(event.target.value)
      //error=true;
    }
    else{
      error=false;
      setText(event.target.value);
      console.log("No error")
    }
    console.log("text is:", text);
    console.log("error is:", error);
    clearTimeout(timeoutRef.current);
    if(error==true){
      toast(t("profile.capitalLetter"), {
        position: "bottom-center",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: false,
        draggable: true,
        progress: undefined,
        });
      //alert("Cannot search due to capital letter");
      //toast.error(t("profile.capitalLetter"),
      //     {position: toast.POSITION.TOP_CENTER})
    }*/
    //else{
    dispatch({ type: "START_SEARCH", query: lowerText});
    const language = t("api.microcompetenciesLanguageCode");
    currentTimeoutRef = setTimeout(() => {
      if (data.value.length === 0) {
        dispatch({ type: "CLEAN_QUERY" });
        return;
      }

      if (lowerText.length === 1){
        dispatch({
          type: "FINISH_SEARCH",
          results: []
        })
        return;
      }
      
      getWord(lowerText, "skill", language).then((skills) => {
        dispatch({
          type: "FINISH_SEARCH",
          results: skills.data.map((item) => ({ title: item })),
        });
      });
    }, 1000);
  }, []);

  const onResultSelect = (e, data) => {
    e.preventDefault();
    //console.log("onResultSelect1", data.result.title);
    dispatch({
      type: "UPDATE_SELECTION",
      value: data.result.title,
      selection: data.result.title,
    });
    let selection= data.result.title;
    searchAddbuttonHandler(selection);
  };

  const searchAddbuttonHandler = (selection) => {
    //e.preventDefault();
    //console.log("selection", selection);
    if (selection !== null) {
      dispatch({ type: "CLEAN_QUERY" });
      addProfileSkill(selection);
    }
  };

  {/*const onResultSelect = (e, data) => {
    e.preventDefault();
    dispatch({
      type: "UPDATE_SELECTION",
      value: data.result.title,
      selection: data.result.title,
    });
  };

  const searchAddbuttonHandler = (e) => {
    e.preventDefault();
    if (searchState.selection !== null) {
      dispatch({ type: "CLEAN_QUERY" });
      addProfileSkill(searchState.selection);
    }
  };*/}

  return (
    <div>
      <SearchInputSkills
        //addButtonHandler={searchAddbuttonHandler}
        state={searchState}
        handleSearchChange={handleSearchChange}
        onResultSelect={onResultSelect}
        placeholder={t("profile.searchSkills")}
      />

      {(currentSkills.length > 0 ||
        suggestedSkills.length > 0 ||
        rejectedSkills.length > 0) && (
        <>
          <div className="segment-container">
            <Header as="h3">{t("profile.currentSkills")}</Header>
            {currentSkills.length < 1 && (
              <p>{t("profile.currentSkillsStatus")}</p>
            )}
            {currentSkills
              .sort((a, b) => a.localeCompare(b))
              .map((skill, i) => (
                <Button
                  // basic
                  className="skill-item"
                  color="green"
                  key={i}
                  content={skill}
                  onClick={(e, d) => {
                    e.preventDefault();
                    excludeProfileSkill(skill);
                  }}
                />
              ))}
          </div>
          <div className="segment-container">
            <Header as="h3"> {t("profile.suggestSkills")}</Header>
            {suggestedSkills.length < 1 && (
              <p>{t("profile.suggestSkillsStatus")}</p>
            )}
            {suggestedSkills
              .sort((a, b) => a.localeCompare(b))
              .map((skill, i) => (
                <Button
                  // basic
                  className="skill-item"
                  color="teal"
                  key={i}
                  content={skill}
                  onClick={(e) => {
                    e.preventDefault();
                    addProfileSkill(skill);
                  }}
                />
              ))}
          </div>
          <div className="segment-container">
            <Header as="h3">{t("profile.rejectedSkills")}</Header>
            {rejectedSkills.length < 1 && (
              <p>{t("profile.rejectedSkillsStatus")}</p>
            )}

            {rejectedSkills
              .sort((a, b) => a.localeCompare(b))
              .map((skill, i) => (
                <Button
                  // basic
                  className="skill-item"
                  color="grey"
                  key={i}
                  content={skill}
                  onClick={(e) => {
                    e.preventDefault();
                    undoExcludProfileSkill(skill);
                  }}
                />
              ))}
          </div>
        </>
      )}
    </div>
  );
};

export default ProfileSkills;

import { Button, Header, Image, Segment } from "semantic-ui-react";

const EmptySegment = ({
  title,
  content,
  btnText,
  onClick,
  image,
  imageAlt,
  imageSize,
}) => {
  return (
    <Segment textAlign="center" clearing basic>
      <Image
        centered
        size={imageSize ? imageSize : "small"}
        src={image}
        alt={imageAlt ? imageAlt : "unspecified"}
      />
      <Header as="h1" textAlign="center" content={title} />
      <p style={{ color: "rgb(97, 97, 97)" }}>{content}</p>
      <Segment.Inline>
        <Button onClick={onClick} color="blue" content={btnText} />
      </Segment.Inline>
    </Segment>
  );
};

export default EmptySegment;

import React, { useState, useLayoutEffect } from "react";
import { Transition } from 'semantic-ui-react'
import ScrollSVG from "../../public/images/up-button.svg";

import "./ScrollUp.css";

const ScrollUp = () => {

    const [visible, setVisible] = useState(false);
    const [transition, setTransition] = useState("");

    const handleVisibleButton = () => {
        const position = window.pageYOffset;

        if (position > 600) {
            setVisible(true);
            setTransition("fade");
        } else if (position < 600) {
            setVisible(false);
            setTransition("fade");
        }

    };
  
    useLayoutEffect(() => {
      window.addEventListener("scroll", handleVisibleButton);
    }, []);

    const handleScrollUp = () => {

        window.scrollTo({ behavior: "smooth", top: 0 });
      };

    return (
        <div>
            <Transition
                visible={visible}
                animation={transition}
                duration={500}
            >
                <img 
                    src={ScrollSVG}  
                    className="scrollUp"
                    onClick={() => handleScrollUp()}
                />
            </Transition>
        </div>
    );
};

export default ScrollUp;
import React, { useCallback, useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { Icon, Button, Modal, Loader, Divider, Image } from "semantic-ui-react";
import {signinGoogle, signinHaka, signinLinkedIn, getHakaLogin, signinHakaUser} from "../../services/user";
import LoaderCubeMini from "../../components/LoaderCube/LoaderCubeMini.js";
import hakaLogo from "../../public/images/haka_logo.png";
import {
  AUTHENTICATION_DATA_KEY,
  GOOGLE_FULL_URL, HAKA_LOGIN_URL,
  LINKEDIN_FULL_URL,
  TERMS_AND_PRIVACY_URL,
} from "../../constants";


const LoginModal = ({
                      modalOpen,
                      onClose,
                      loginEsclationHandler,
                      updateLogin,
                    }) => {
  const { t } = useTranslation();
  const [loaderEnabled, setLoaderEnabled] = useState(false);
  const gState = Math.random().toString(36).substring(2);

  const checkAuthData = (data) => {
    // if new user show terms and conditions
    if (data.message === "TERMS_AND_CONDITION") {
      loginEsclationHandler({
        profile: data.profile,
        type: "SHOW_TERMS",
      });
    } else {
      // if user signed in using other oAuth method prompt to change it
      if (data.message === "CHANGE_AUTH_METHOD") {
        loginEsclationHandler({
          profile: data.profile,
          type: "SWITCH_ACCOUNT",
          newSigninMethod: data.newSigninMethod,
        });
      } else {
        updateLogin({ ...data.profile, token: data.token });
      }
    }
  };

  const windowEventListener = useCallback(async (event) => {
    const { code, state, type } = event.data;
    if (code && type && state === gState) {
      let data = null;
      setLoaderEnabled(true);
      if (type === "GOOGLE") {
        data = await signinGoogle({ code, state });
      } else if (type === "LINKEDIN") {
        data = await signinLinkedIn({ code, state });
      } else if (type === "HAKA") {
        data = await signinHakaUser(state);
      }
      if (data) {
        onClose();
        checkAuthData(data);
      }
    }
  }, []);


  useEffect(() => {
    window.addEventListener("message", windowEventListener);
    // clean up, remove listner
    return () => {
      window.removeEventListener("message", windowEventListener);
    };
  }, [windowEventListener]);

  const requestProfile = (url, windowName) => {
    const width = 450;
    const height = 730;
    const left = window.screen.width / 2 - width / 2;
    const top = window.screen.height / 2 - height / 2;
    window.open(
        url,
        windowName,
        "menubar=no,location=no,resizable=no,scrollbars=no,status=no, width=" +
        width +
        ", height=" +
        height +
        ", top=" +
        top +
        ", left=" +
        left
    );
  };

  return (
    <Modal
        open={modalOpen}
        onClose={onClose}
        centered={true}
        closeIcon
        size="mini"
        className="login-modal"
        style={{ maxWidth: "80%" }}
    >
      <Icon 
        size="huge" 
        name="users" 
        circular
        inverted
        color="blue"
        style={{ marginTop: "10px", position: "relative", top: "-40px", fontSize: "30px", marginBottom: "-40px" }}
      />
        <Divider style={{ borderColor: "rgba(0, 0, 0, 0.00)" }} />

      <Modal.Content>
        <div style={{ marginTop: "-30px", marginBottom: "30px" }}>
          <h2>{t("loginForm.title")}</h2>
        </div>
      <Button
        style={{
          padding: "15px",
          width: "70%",
        }}
        // fluid
        size="small"
        type="submit"
        color="blue"
        onClick={(e) => {
          e.preventDefault();
          window.location.replace(HAKA_LOGIN_URL);
        }}
      >
        <Image
          size="tiny"
          spaced="right"
          src={hakaLogo}
          style={{ imageRendering: "high-quality", margin: "-20px", top: "-3px" }}
        />
      </Button>
        <div className="login-modal-content">
            {/* (keep this line commented) {loaderEnabled && <Loader inline="centered" active />} }
            {loaderEnabled && <LoaderCubeMini />}
            <p style={{ marginBottom: "20px" }}>{t("user.socialSingin")} :</p>
          {/* LinkedIn login button */}
          {/* <Button
              style={{
                margin: "20px 0",
              }}
              fluid
              size="large"
              type="submit"
              color="linkedin"
              onClick={(e) => {
                e.preventDefault();
                requestProfile(
                    LINKEDIN_FULL_URL + "&state=" + gState,
                    "LINKEDIN"
                );
              }}
          >
            <Icon name="linkedin" />
            {t("loginForm.signin")}
            </Button>}}

          <Divider style={{ borderColor: "rgba(0, 0, 0, 0.03)" }} />

          {/* Terms and conditon notice */}
          <div style={{ marginTop: "20px", marginBottom: "-20px" }}>
            {t("user.termsText")}
            <a href={TERMS_AND_PRIVACY_URL} target="_blank" rel="noreferrer">
              {t("user.terms")}
            </a>
          </div>
        </div>
      </Modal.Content>
    </Modal>
  );
};

export default LoginModal;

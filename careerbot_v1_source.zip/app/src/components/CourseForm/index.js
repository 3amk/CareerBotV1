import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import { useDispatch } from "react-redux";
import { Form, Popup, Icon, Button, Segment, Input } from "semantic-ui-react";
import { getCourses } from "../../reducers/courseSearchReducer";

import { MultiSelectPureDropdown } from "../MultiSelectPureDropdown";

import { SCHOOL_LIST } from "../../constants";

const CourseForm = () => {
  const { t } = useTranslation();
  const dispatch = useDispatch();

  const [courseInput, setCourseInput] = useState("");
  const [seletedSchools, setSelectedSchools] = useState(["AMKosaaja", "Haaga-Helia", "Hamk", "Laurea", "Metropolia",  "Xamk"]);
  const [schoolError, setSchoolError] = useState(null);
  const [skillError, setSkillError] = useState(null);

  const schoolOptions = SCHOOL_LIST.map((school) => ({
    key: school,
    text: school,
    value: school,
  }));

  /*useEffect(() => {
    options: [
      {value:'1', text:'A'},
      {value:'2', text:'B'},
      {value:'3', text:'C'},
    ],
    selected: ['1', '2', '3'], // <== Here, the values of selected options
  });*/

  const handleCourseChange = (e) => {
    setCourseInput(e.target.value);
  };

  const handleSchoolChange = (e, data) => {
    setSelectedSchools(data.value);
  };

  const searchCourses = (e) => {
    e.preventDefault();

    if (courseInput.length < 2 && seletedSchools.length < 1) {
      setSchoolError({
        content: t("error.schoolError"),
        pointing: "below",
      });
      setSkillError({
        content: t("error.courseError"),
        pointing: "below",
      });
      return;
    } else if (courseInput.length < 2) {
      setSkillError({
        content: t("error.courseError"),
        pointing: "below",
      });
      setSchoolError(null);
      return;
    } else if (seletedSchools.length < 1) {
      setSchoolError({
        content: t("error.schoolError"),
        pointing: "below",
      });
      setSkillError(null);
      return;
    }

    setSchoolError(null);
    setSkillError(null);
    dispatch(getCourses(courseInput, seletedSchools));
    //setCourseInput("");
  };

  return (
    <Segment clearing>
      <Form onSubmit={searchCourses}>
      <Form.Field
            // id="form-input-control-skills"
            control={Input}
            icon="search"
            iconPosition="left"
            value={courseInput}
            placeholder={t("profile.skills")}
            onChange={handleCourseChange}
            error={skillError}
            label={{
              children: (
                <>
                  <label>{t("courses.enterSkill")}</label>
                  <Popup
                    on="click"
                    trigger={<Icon color="grey" name="question circle" />}
                    content={t("popup.course")}
                    position="bottom center"
                  />
                </>
              ),
            }}
          />
        <Form.Group widths="equal">
          <Form.Field
            id="form-select-control-profile"
            control={MultiSelectPureDropdown}
            fluid
            clearable
            options={schoolOptions}
            defaultValue={seletedSchools}
            placeholder={t("courses.school")}
            onChange={handleSchoolChange}
            error={schoolError}
            selectOnBlur={false}
            label={{
              children: (
                <>
                  <label className="label">{t("courses.selectSchool")}</label>
                  <Popup
                    on="click"
                    trigger={<Icon color="grey" name="question circle" />}
                    content={t("popup.school")}
                    position="bottom center"
                  />
                </>
              ),
            }}
          />
          <Button style={{ marginTop:"auto", padding: "12px", paddingLeft: "24px", paddingRight: "24px", float: "right", marginLeft: "auto", marginRight: "9px" }}
            type="submit"
            // width={3}
            color="blue"
            content={t("courses.search")}
            floated="right"
          />
        </Form.Group>

      </Form>
    </Segment>
  );
};

export default CourseForm;

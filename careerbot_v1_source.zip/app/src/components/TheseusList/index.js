import React, { useState, useRef } from "react";
import { Item, Button, Segment, MenuItem } from "semantic-ui-react";
import { useTranslation } from "react-i18next";
import { trimString } from "../../utils/helperFunctions";
import * as d3 from "d3";

const TheseusList = ({ theseus, theseusKeywords, activeItem, theseusType, globalType, isLoading }) => {
  const { t } = useTranslation();
  const refStart = useRef(null);

  const colorScale = d3.schemeCategory10.concat(d3.schemeCategory10).concat(d3.schemeCategory10);

  const wordHits = [];
  const keywords = [];
  const [thesisLimit] = useState(25);
  const [pages] = useState(Math.ceil(theseus.length / thesisLimit));
  const [pageLimit] = useState(Math.ceil(theseus.length / thesisLimit));
  const [currentPage, setCurrentPage] = useState(1);


  function scrollUp() {
    refStart.current.scrollIntoView();
  }

  function goToNextPage() {
    scrollUp();
    // console.log("next", currentPage, pages)
    if(currentPage!=pages){
    setCurrentPage((page) => page + 1)
  }else{
    setCurrentPage((page) => page)
  };
 }

 function goToPreviousPage() {
  scrollUp();
  // console.log("prev", currentPage, pages)
  if(currentPage!=1){
    setCurrentPage((page) => page - 1)
  }else{
    setCurrentPage((page) => page )
  };
 }

 function onChangePage(event) {
    scrollUp();
    const pageNumber = Number(event.target.textContent);

    // console.log("number", pageNumber)
    setCurrentPage(pageNumber);
 }

 const getPaginatedData = () => {
  const startIndex = currentPage * thesisLimit - thesisLimit;
  const endIndex = startIndex + thesisLimit;
  return theseus.slice(startIndex, endIndex);
 };

 const getPaginationGroup = () => {
  let start = Math.floor((currentPage - 1) / pageLimit) * pageLimit;
  // console.log("start", start);
  return new Array(pageLimit).fill().map((_, idx) => start + idx + 1);
 };
  for (var i = 0; i < theseus.length; i++){
      wordHits.push(theseus[i].word_hits);
  }
 
  theseusKeywords.data.forEach((d, i) => {
    keywords.push({
      word: theseusKeywords.data[i].word,
      color: colorScale[i]
    })
  })
  theseusKeywords.relations.forEach((d, i) => {
    keywords.push({
      word: theseusKeywords.relations[i].word,
      color: colorScale[i]
    })
  
  })

  const reformattedData = [];

  wordHits.forEach((d, i) => {  
      const data = {
        word_hits: d.map((d, i) => {
          var i = 0;
          for (i; i < keywords.length; i++)
            if (d == keywords[i].word) {
            return { word: d, color: keywords[i].color}
            } 
            else if (d !== keywords[i].word && d != "") {
              var i = i++
            } 
            else if (d == undefined) {
              return { word: "", color: "#000"}
          }
        }),
      };
          reformattedData.push(data);
  });
 
  if(theseusType==true){
  return (
    <div 
    style={{ paddingTop: "10px" }} 
    ref={refStart}>
    <Item.Group relaxed unstackable divided>
      {getPaginatedData().map((thesis, i) => (
        <Item
          key={i}
          onClick={() => {thesis.url.length > 0 && window.open(thesis.url.split(",")[0], "_blank")}}
        >
          <Item.Content>

          {thesis.url.length > 0 ? (
            <Item.Header as="a">{thesis.title}</Item.Header>
          ):(
            <Item.Header>{thesis.title}</Item.Header>
          )}
            <Item.Extra>
            <strong>{t("theseus.keywords")}: </strong>
                  {reformattedData[i].word_hits.map((d, i) =>
                    <strong style={{ color: d.color }}>
                      {d.word + " "}
                    </strong> 
                  )}
            </Item.Extra>
            <Item.Meta>
              <strong>{t("theseus.published")}: </strong>
              {thesis.published}
            </Item.Meta>
            <Item.Description>
              <strong>{t("theseus.abstract")}: </strong>
              {thesis.abstract.length < 1 ? (
                <div style={{ fontStyle: "italic" }}>{t("theseus.missingData")}</div>
              ) : (
                <div>
                  {trimString(thesis.abstract, 200)}
                </div>
              )}
            </Item.Description>
            <Item.Extra>
              <strong>{t("courses.school")}: </strong>
              {thesis.school.toUpperCase()}
            </Item.Extra>
          </Item.Content>
        </Item>
      ))}
    </Item.Group>
    {pages > 0 && (
    <div 
      className="pagination" 
      // Below throws error, className already defined
      // class="pagination__link"
      style={{ display: "flex", justifyContent: "center", paddingTop: "20px" }} 
      marginPagesDisplayed={12}>
        {/* previous button */}
        <Button
          icon="chevron left" color="blue" size="small"
          onClick={goToPreviousPage}
          className={`prev ${currentPage === 1 ? 'disabled' : ''}`}
        >
          {/* {t("theseus.previousButton")} */}
        </Button>

        {/* show page numbers */}
        {getPaginationGroup().map((item, index) => (
          <Button
            key={index}
            onClick={onChangePage}
            className={`paginationItem ${currentPage === item ? 'active' : null}`}
          >
            <span>{item}</span>
          </Button>
        ))}

        {/* next button */}
        <Button
          icon="chevron right" color="blue" size="small"
          onClick={goToNextPage}
          className={`next ${currentPage === pageLimit ? 'disabled' : ''}`}
        >
          {/* {t("theseus.nextButton")} */}
        </Button>
      </div>
    )}
    </div>
  );
}
else {
  return (
    <div 
    style={{ paddingTop: "10px" }} 
    ref={refStart}>
    <Item.Group relaxed unstackable divided>
      {getPaginatedData().map((thesis, i) => (
        <Item
          key={i}
          onClick={() => {thesis.pdf_url.length > 0 && window.open(thesis.pdf_url.split(",")[0], "_blank")}}
        >
          <Item.Content>

          {thesis.pdf_url.length > 0 ? (
            <Item.Header as="a">{thesis.title}</Item.Header>
          ):(
            <Item.Header>{thesis.title}</Item.Header>
          )}
            <Item.Extra>
            <strong>{t("theseus.keywords")}: </strong>
                  {reformattedData[i].word_hits.map((d, i) =>
                    <strong style={{ color: d.color }}>
                      {d.word + " "}
                    </strong> 
                  )}
            </Item.Extra>
            <Item.Meta>
              <strong>{t("theseus.published")}: </strong>
              {thesis.published}
            </Item.Meta>
            <Item.Description>
              <strong>{t("theseus.abstract")}: </strong>
              {thesis.abstract.length < 1 ? (
                <div style={{ fontStyle: "italic" }}>{t("theseus.missingData")}</div>
              ) : (
                <div>
                  {trimString(thesis.abstract, 200)}
                </div>
              )}
            </Item.Description>
            <Item.Extra>
              <strong>{t("courses.author")}: </strong>
              {thesis.authors.toUpperCase()}
            </Item.Extra>
          </Item.Content>
        </Item>
      ))}
    </Item.Group>
    {pages > 0 && (
    <div 
      className="pagination" 
      // Below throws error, className already defined
      // class="pagination__link"
      style={{ display: "flex", justifyContent: "center", paddingTop: "20px" }} 
      marginPagesDisplayed={12}>
        {/* previous button */}
        <Button
          icon="chevron left" color="blue" size="small"
          onClick={goToPreviousPage}
          className={`prev ${currentPage === 1 ? 'disabled' : ''}`}
        >
          {/* {t("theseus.previousButton")} */}
        </Button>

        {/* show page numbers */}
        {getPaginationGroup().map((item, index) => (
          <Button
            key={index}
            onClick={onChangePage}
            className={`paginationItem ${currentPage === item ? 'active' : null}`}
          >
            <span>{item}</span>
          </Button>
        ))}

        {/* next button */}
        <Button
          icon="chevron right" color="blue" size="small"
          onClick={goToNextPage}
          className={`next ${currentPage === pageLimit ? 'disabled' : ''}`}
        >
          {/* {t("theseus.nextButton")} */}
        </Button>
      </div>
    )}
    </div>
  );
}
};

export default TheseusList;

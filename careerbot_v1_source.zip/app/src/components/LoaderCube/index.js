import React from "react";
import { useTranslation } from "react-i18next";
import { Segment } from "semantic-ui-react";

import "./Loading.css";

const LoaderCube = () => {
    const { t } = useTranslation();
    return (
        <div className="column padless-column" style={{ paddingTop: "30px" }}>
        <div className="cube">
          <div className="side"></div>
          <div className="side"></div>
          <div className="side"></div>
          <div className="side"></div>
          <div className="side"></div>
          <div className="side"></div>
        </div>
      </div>
    );
};

export default LoaderCube;
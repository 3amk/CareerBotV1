import { Search, Label, Button, Segment, Form } from "semantic-ui-react";
import { useTranslation } from "react-i18next";

const resultRenderer = ({ title }) => (
  <Label style={{ minWidth: "100px" }} size="big" content={title} />
);

const SearchInput = ({
  addButtonHandler,
  state,
  handleSearchChange,
  onResultSelect,
  placeholder,
}) => {
  const { t } = useTranslation();

  return (
    <div style={{ display:"flex", flexWrap:"wrap"}}>
      <div style={{ marginTop: "24px", marginBottom: "8px", flexGrow:"1", width:"90%", maxWidth: "100%"}}>
      <Search
        input={{
          input: "text",
          placeholder: placeholder,
          fluid: true
        }}
        loading={state.isLoading}
        onResultSelect={onResultSelect}
        onSearchChange={handleSearchChange}
        results={state.results}
        noResultsMessage={t("profile.noResult")}
        value={state.value}
        resultRenderer={resultRenderer}
        autoFocus
        fluid
      />
      </div>
      <div style={{ flexGrow:"1"}}>
      {/* {<Segment basic clearing> */}
      <Button style={{ padding: "12px", paddingLeft: "24px", paddingRight: "24px", float: "right", margin: "24px 0px auto 0px" }}
          content={t("profile.add")}
          disabled={state.selection === null}
          onClick={addButtonHandler}
          color="blue"
          floated="right"
        />
      {/* </Segment>} */}
      </div>
    </div>
  );
};

export default SearchInput;

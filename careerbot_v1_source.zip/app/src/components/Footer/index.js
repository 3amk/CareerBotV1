import React from "react";
import { useTranslation } from "react-i18next";
import { Link } from "react-router-dom";
import { Container, Divider, Menu, Segment, Grid } from "semantic-ui-react";
import { TERMS_AND_PRIVACY_URL, ADD_NEW_COURSE} from "../../constants";

const Footer = () => {
  const { t } = useTranslation();
  const scrollTop = () => {
    window.scrollTo(0, 0);
  };
  return (
    <div className="footer-container">
      <Container>
        <Segment.Group>
          <Segment clearing>
            <Grid columns={2} divided>
              {/* <Grid.Row> */}
              <Grid.Column>
                <Menu text vertical>
                  <Menu.Item header>{t("nav.browse")}</Menu.Item>
                  {/* Home */}
                  <Menu.Item
                    onClick={scrollTop}
                    as={Link}
                    to="/"
                    name={t("nav.home")}
                    content={t("nav.home")}
                  ></Menu.Item>
                  {/* Profile */}
                  <Menu.Item
                    onClick={scrollTop}
                    as={Link}
                    to="/skills_profile"
                    name={t("nav.profile")}
                    content={t("nav.profile")}
                  ></Menu.Item>
                  {/* Jobs */}
                  <Menu.Item
                    onClick={scrollTop}
                    as={Link}
                    to="/jobs"
                    name={t("nav.job")}
                    content={t("nav.job")}
                  ></Menu.Item>
                  {/* Courses */}
                  <Menu.Item
                    onClick={scrollTop}
                    as={Link}
                    to="/courses"
                    name={t("nav.courses")}
                    content={t("nav.courses")}
                  ></Menu.Item>
                  {/* Maps */}
                  <Menu.Item
                    onClick={scrollTop}
                    as={Link}
                    to="/maps"
                    name={t("nav.maps")}
                    content={t("nav.maps")}
                  ></Menu.Item>
                  {/* Theses */}
                  <Menu.Item
                    onClick={scrollTop}
                    as={Link}
                    to="/theseus"
                    name={t("nav.theses")}
                    content={t("nav.theses")}
                  ></Menu.Item>
                </Menu>
              </Grid.Column>
              <Grid.Column>
                <Menu text vertical>
                  <Menu.Item header>3AMK</Menu.Item>
                  {/* Privacy */}
                  <Menu.Item
                    href={TERMS_AND_PRIVACY_URL}
                    target="_blank"
                    name={t("nav.privacy")}
                    content={t("nav.privacy")}
                  />
                  {/* 3AMK Homepage */}
                  <Menu.Item
                    href={"https://www.3amk.fi/"}
                    target="_blank"
                    content={t("nav.3amkhome")}
                  />
                  {/* Course Adding */}
                  <Menu.Item
                     href={ADD_NEW_COURSE}
                     target="_blank"
                     name={t("nav.addCourse")}
                     content={t("nav.addCourse")}
                  />
                  {/* Bug reporting */}
                  <Menu.Item
                    content={t("nav.report")}
                    href="mailto:careerbot@laurea.fi"
                    target="_blank"
                    style={{ paddingBottom: "70px" }}
                  />
                  {/* Headai */}
                  <Menu.Item
                    content="Powered by Headai"
                    href="https://headai.com/"
                    target="_blank"
                    style={{ fontWeight: "bold" }}
                  />
                </Menu>
              </Grid.Column>
            </Grid>
          </Segment>
        </Segment.Group> 
      </Container>
    </div>
  );
};
export default Footer;

import React from "react";
import { useTranslation } from "react-i18next";
import { Button, Modal } from "semantic-ui-react";
import { updateUserAccount } from "../../services/user";

const SwitchAccountModal = ({ modalOpen, onClose, updateLogin, esclation }) => {
  const { t } = useTranslation();

  const profile = esclation ? esclation.profile : "";
  const newSigninMethod = esclation ? esclation.newSigninMethod : "";

  const handleCancel = () => {
    onClose();
  };

  const handleLinkAccount = async () => {
    const newProfile = { ...profile, signinType: newSigninMethod };
    const user = await updateUserAccount({ profile: newProfile });
    onClose();
    if (user) {
      updateLogin({ ...user.profile, token: user.token });
    } else {
      console.log("updater error");
    }
  };

  return (
    <Modal size="small" open={modalOpen} onClose={onClose}>
      <Modal.Header>{t("switchAccount.header")}</Modal.Header>
      <Modal.Content scrolling>
        <p>
          {t("switchAccount.content", {
            signinType1: profile && profile.signinType.toUpperCase(),
            signinType2: newSigninMethod && newSigninMethod.toUpperCase(),
          })}
        </p>
      </Modal.Content>
      <Modal.Actions>
        <Button className="stacked-button" color="grey" onClick={handleCancel}>
          {t("switchAccount.cancel")}
        </Button>

        <Button className="stacked-button" primary onClick={handleLinkAccount}>
          {t("switchAccount.proceed")}
        </Button>
      </Modal.Actions>
    </Modal>
  );
};

export default SwitchAccountModal;

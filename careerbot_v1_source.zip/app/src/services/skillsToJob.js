import axios from "axios";
import { HEADAI_BASE_URL } from "../constants/index.js";
import { checkInternetConnection } from "./serviceError.js";

const getJobs = async (area, date, words) => {
  try {
    /*const config = {
      params: {
        action: "request_jobs_by_keywords",
        words: words,
        area: area,
        //time_range_start: date,
        token: process.env.REACT_APP_HEADAI_TOKEN,
      },
    };
    const response = await axios.get(HEADAI_BASE_URL, config);*/
    const response= await axios({
      method: 'get',
      url: '/api/v1/request_jobs_by_keywords',
      params: {
        words: words,
        area: area,
      }
    });
    return response.data;
  } catch (error) {
    checkInternetConnection();
  }
};

export default getJobs;

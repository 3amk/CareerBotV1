import axios from "axios";
import { HEADAI_BASE_URL } from "../constants/index.js";
import { checkInternetConnection } from "./serviceError.js";

const getWord = async (word, type, language) => {
  try {
    /*const config = {
      params: {
        action: "word_complete",
        type: type,
        word: word,
        lang: language,
        country_code: "fi",
        token: process.env.REACT_APP_HEADAI_TOKEN,
      },
    };
    const response = await axios.get(HEADAI_BASE_URL, config);*/
    const response= await axios({
      method: 'get',
      url: '/api/v1/word_complete',
      params: {
        type: type,
        word: word,
        lang: language,
      }
    });
    return response.data;
  } catch (error) {
    checkInternetConnection();
  }
};

export default getWord;

import axios from "axios";
import { checkInternetConnection } from "./serviceError.js";

/* Servie to create new user after user agree to terms */
const saveUser = async (profile) => {
  try {
    const response = await axios.post("/api/v1/auth", profile);
    return response.data;
  } catch (error) {
    checkInternetConnection();
  }
};

/* update user profile like email, name, oAuth type(signin type) */
const updateUserAccount = async (profile) => {
  try {
    const response = await axios.put("/api/v1/auth", profile);
    return response.data;
  } catch (error) {
    checkInternetConnection();
  }
};

/* Signin using google oAuth */
const signinGoogle = async (tokenId) => {
  try {
    const response = await axios.post("/api/v1/auth/google", tokenId);
    return response.data;
  } catch (error) {
    checkInternetConnection();
  }
};

/* Signin using linkedi oAuth */
const signinLinkedIn = async (data) => {
  try {
    const response = await axios.post("/api/v1/auth/linkedin", data);
    return response.data;
  } catch (error) {
    checkInternetConnection();
  }
};

const signinHaka = async () => {
  try {
    const response = await axios.get("/api/v1/auth/login");
    return response.data;
  } catch (error) {
    checkInternetConnection();
  }
};

const signinHakaUser = async (state) => {
  try {
    const response = await axios.post("/api/v1/auth/haka", state);
    return response.data;
  } catch (error) {
    checkInternetConnection();
  }
};


const logOut = async () => {
  try {
    const response = await axios.get("/api/v1/auth/logout");
    return response.data;
  } catch (error) {
    checkInternetConnection();
  }
};

const getHakaLogin = async()=> {
  try {
    const response=await axios.get('/api/v1/auth/haka');
    return response.data;
  } catch (error) {
    checkInternetConnection();
  }
};


export { saveUser, signinGoogle,signinHakaUser, updateUserAccount, logOut, signinLinkedIn,signinHaka, getHakaLogin };

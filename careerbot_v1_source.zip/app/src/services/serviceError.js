export const checkInternetConnection = (error) => {
  if (!window.navigator.onLine) {
    window.location.reload();
  }
};

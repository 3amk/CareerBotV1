import axios from "axios";
import { checkInternetConnection } from "./serviceError.js";

const requestMap = async (mapName) => {
  try {
    const response = await axios.post(`/api/v1/map`, { mapName });
    return response.data;
  } catch (error) {
    checkInternetConnection();
  }
};

const deleteMap = async (mapId) => {
  try {
    const response = await axios.delete(`/api/v1/map/${mapId}`);
    return response.data;
  } catch (error) {
    checkInternetConnection();
    return error;
  }
};

const getExampleMaps = async () => {
  try {
    const response = await axios.get("/api/v1/map/examples");
    // check if returned data is json
    if (response.headers["content-type"].indexOf("application/json") !== -1) {
      return response.data;
    } else {
      return [];
    }
  } catch (error) {
    checkInternetConnection();
    return [];
  }
};

const getMapList = async () => {
  try {
    const response = await axios.get(`/api/v1/map`);

    return response.data;
  } catch (error) {
    checkInternetConnection();
  }
};

const getMapData = async (id) => {
  try {
    const response = await axios.get(`/api/v1/map/${id}`);
    return response.data;
  } catch (error) {
    checkInternetConnection();
  }
};

export { requestMap, deleteMap, getMapList, getMapData, getExampleMaps };

import axios from "axios";
import { HEADAI_BASE_URL } from "../constants/index.js";
import { checkInternetConnection } from "./serviceError.js";

const getStaticThesisWord = async (text) => {
  try {
    /*const config = {
      params: {
        action: "get_thesis_word_statistic",
        token: process.env.REACT_APP_HEADAI_TOKEN,
        text: text,
        lang: "fi",
      },
    };
    const response = await axios.get(HEADAI_BASE_URL, config);*/
    const response= await axios({
      method: 'get',
      url: '/api/v1/get_thesis_word_statistic',
      params: {
        text: text,
      }
    });

    return response.data;
  } catch (error) {
    checkInternetConnection();
  }
};

const getStaticThesisWordGlobal = async (text) => {
  try {
        const response= await axios({
      method: 'get',
      url: '/api/v1/get_thesis_word_statistic_global',
      params: {
        text: text,
      }
    });
    return response.data;
  } catch (error) {
    checkInternetConnection();
  }
};

const getRelatedThesis = async (keywords) => {
  try {
    /*const config = {
      params: {
        action: "search_related_thesis",
        token: process.env.REACT_APP_HEADAI_TOKEN,
        keywords: keywords,
      },
    };
    const response = await axios.get(HEADAI_BASE_URL, config);*/
    const response= await axios({
      method: 'get',
      url: '/api/v1/search_related_thesis',
      params: {
        keywords: keywords,
      }
    });
    return response.data || [];
  } catch (error) {
    checkInternetConnection();
  }
};

const getRelatedArticle = async (keywords) => {
  try {
    /*const config = {
      params: {
        action: "search_related_thesis",
        token: process.env.REACT_APP_HEADAI_TOKEN,
        keywords: keywords,
      },
    };
    const response = await axios.get(HEADAI_BASE_URL, config);*/
    const response= await axios({
      method: 'get',
      url: '/api/v1/search_related_article',
      params: {
        keywords: keywords,
      }
    });
    return response.data || [];
  } catch (error) {
    checkInternetConnection();
  }
};

export { getStaticThesisWord, getStaticThesisWordGlobal, getRelatedThesis, getRelatedArticle };

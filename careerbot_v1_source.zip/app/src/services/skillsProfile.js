import axios from "axios";
import { checkInternetConnection } from "./serviceError.js";

const getSkillsProfile = async () => {
  try {
    const response = await axios.get("/api/v1/profile");
    return response.data;
  } catch (error) {
    if (
      error.response.data.message &&
      error.response.data.message.includes("jwt expired")
    ) {
      return { error: { message: "jwt expired" } };
    } else {
      checkInternetConnection();
      return null;
    }
  }
};

const getProfileData = async (profileName) => {
  try {
    const response = await axios.get("/api/v1/profile/" + profileName);
    return response.data;
  } catch (error) {
    checkInternetConnection();
  }
};

const createNewProfile = async (name) => {
  try {
    const response = await axios.post("/api/v1/profile", { profileName: name });
    return response.data;
  } catch (error) {
    checkInternetConnection();
  }
};

const updateProfile = async (newProfileData) => {
  try {
    let newObj = {
      name: newProfileData.name,
      text: newProfileData.text,
      koski_text: newProfileData.koski_text,
      include_skills: newProfileData.include_skills,
      exclude_skills: newProfileData.exclude_skills,
      courses: newProfileData.courses,
    };
    const response = await axios.put("/api/v1/profile", newObj);
    return response.data;
  } catch (error) {
    checkInternetConnection();
  }
};

const deleteProfile = async (name) => {
  try {
    const response = await axios.delete("/api/v1/profile/" + name);
    return response.data;
  } catch (error) {
    checkInternetConnection();
  }
};

export {
  getSkillsProfile,
  createNewProfile,
  getProfileData,
  updateProfile,
  deleteProfile,
};

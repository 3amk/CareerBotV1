import axios from "axios";
import { HEADAI_BASE_URL } from "../constants/index.js";
import { checkInternetConnection } from "./serviceError.js";

const getSemanticSuggestion = async (word, type, language) => {
  try {
    /*const config = {
      params: {
        action: "semantic_suggestion",
        type: type,
        word: word,
        lang: language,
        word_limit: 50,
        token: process.env.REACT_APP_HEADAI_TOKEN,
      },
    };
    const response = await axios.get(HEADAI_BASE_URL, config);*/
    const response= await axios({
      method: 'get',
      url: '/api/v1/semantic_suggestion',
      params: {
        type: type,
        word: word,
        lang: language,
      }
    });
    return response.data;
  } catch (error) {
    checkInternetConnection();
  }
};

export default getSemanticSuggestion;

import axios from "axios";
import { HEADAI_BASE_URL } from "../constants/index.js";
import { checkInternetConnection } from "./serviceError.js";

const getSchoolList = async () => {
  try {
    /*const config = {
      params: {
        action: "education_list",
        token: process.env.REACT_APP_HEADAI_TOKEN,
      },
    };
    const response = await axios.get(HEADAI_BASE_URL, config);*/
    const response= await axios({
      method: 'get',
      url: '/api/v1/education_list',
      params: {

      }
    });
    return response.data;
  } catch (error) {
    if (error.message === "Network Error") {
      checkInternetConnection(error);
    }
    return [];
  }
};

const getCourseBySkills = async (missingSkill, limit) => {
  try {
    /*const config = {
      params: {
        action: "skill_to_education",
        limit: limit,
        skill: missingSkill,
        token: process.env.REACT_APP_HEADAI_TOKEN,
      },
    };
    const response = await axios.get(HEADAI_BASE_URL, config);*/
    const response= await axios({
      method: 'get',
      url: '/api/v1/skill_to_education',
      params: {
        limit: limit,
        skill: missingSkill,
      }
    });
    return response.data;
  } catch (error) {
    checkInternetConnection();
  }
};

const getCourseByText = async (text, school) => {
  try {
    /*const config = {
      params: {
        action: "search_courses_by_text",
        text: text,
        school: school,
        token: process.env.REACT_APP_HEADAI_TOKEN,
      },
    };
    const response = await axios.get(HEADAI_BASE_URL, config);*/
    
    const response= await axios({
      method: 'get',
      url: '/api/v1/search_courses_by_text',
      params: {
        text: text,
        school: school,
      }
    });
    return response.data;
  } catch (error) {
    checkInternetConnection();
  }
};

const getCourseByCode = async (Text, school, courseId, courseCode) => {
  try {
    /*const config = {
      params: {
        action: "search_courses",
        text: Text,
        school: school,
        course_id: courseId,
        course_code: courseCode,
        token: process.env.REACT_APP_HEADAI_TOKEN,
      },
    };
    const response = await axios.get(HEADAI_BASE_URL, config);*/
    const response= await axios({
      method: 'get',
      url: '/api/v1/search_courses',
      params: {
        text: Text,
        school: school,
        course_id: courseId,
        course_code: courseCode,
      }
    });
    const data = response.data.data;
    return { data, courseId, courseCode };
  } catch (error) {
    checkInternetConnection();
  }
};

const getDegreePrograms = async (edu_organization, search_phrase) => {
  try {
    /*const config = {
      params: {
        action: "degree_program_suggestion",
        edu_organization: edu_organization,
        search_phrase: search_phrase,
        token: process.env.REACT_APP_HEADAI_TOKEN,
      },
    };
    const response = await axios.get(HEADAI_BASE_URL, config);*/
    const response= await axios({
      method: 'get',
      url: '/api/v1/degree_program_suggestion',
      params: {
        edu_organization: edu_organization,
        search_phrase: search_phrase,
      }
    });
    return response.data;
  } catch (error) {
    checkInternetConnection();
  }
};

export {
  getSchoolList,
  getCourseBySkills,
  getCourseByText,
  getDegreePrograms,
  getCourseByCode,
};

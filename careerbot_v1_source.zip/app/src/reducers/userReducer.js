import {AUTHENTICATION_DATA_KEY, HAKA_LOGIN_URL, HAKA_LOGOUT_URL} from "../constants";
import { logOut } from "../services/user";

const userReducer = (state = { data: null, isAuthorised: false }, action) => {
  switch (action.type) {
    case "LOGIN_USER":
      window.localStorage.setItem(
          AUTHENTICATION_DATA_KEY,
          JSON.stringify(action.data)
      );
      return { data: action.data, isAuthorised: true };

    case "LOGOUT_USER":
      window.localStorage.setItem(AUTHENTICATION_DATA_KEY, null);
      return { data: action.data, isAuthorised: false };
    default:
      return state;
  }
};

export const loginUser = (user) => {
  return {
    type: "LOGIN_USER",
    data: user,
  };
};

export const logoutUser = () => {
  return async (dispatch) => {
    // logout user
    dispatch({
      type: "LOGOUT_USER",
      data: null,
    });
    // // clear user profiles list
    dispatch({
      type: "CLEAR_ALL_PROFILES",
      data: [],
    });

    window.location.replace("/api/v1/auth/logout");
    /*logOut().then(() => {
     //
    });
*/

  };
};

export default userReducer;

const loginModalReducer = (state = { open: false }, action) => {
  switch (action.type) {
    case "OPEN_LOGIN_MODAL":
      return { open: true };
    case "CLOSE_LOGIN_MODAL":
      return { open: false };
    default:
      return state;
  }
};

export const closeLoginModal = () => ({ type: "CLOSE_LOGIN_MODAL" });
export const openLoginModal = () => ({ type: "OPEN_LOGIN_MODAL" });

export default loginModalReducer;

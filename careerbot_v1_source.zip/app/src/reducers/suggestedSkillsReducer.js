import getSemanticSuggestion from "../services/semanticSuggestion";

const suggestedSkillsReducer = (state = {}, action) => {
  switch (action.type) {
    case "UPDATE_SUGGESTED_SKILLS":
      return { ...state, [action.data.name]: action.data };
    default:
      return state;
  }
};

export const getSuggestedSkills = (baseSkills, profileName, language) => {
  return async (dispatch) => {
    if (baseSkills && baseSkills.length > 0) {
      const suggestion = await getSemanticSuggestion(
        baseSkills.toString(),"skill", language
      );
      const newData = { name: profileName, suggestions: suggestion.data };
      dispatch({
        type: "UPDATE_SUGGESTED_SKILLS",
        data: newData,
      });
    } else {
      return [];
    }
  };
};

export default suggestedSkillsReducer;

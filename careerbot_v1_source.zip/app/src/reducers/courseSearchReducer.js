import { getCourseByText } from "../services/courses";

const courseSearchReducer = (
  state = { courseResult: { results: null, skills: [] }, isLoading: false },
  action
) => {
  switch (action.type) {
    case "GET_COURSES":
      return { courseResult: action.data, isLoading: false };
    case "FETCHING_COURSEDATA":
      return { ...state, isLoading: true };
    default:
      return state;
  }
};

export const getCourses = (skill, selectedSchool) => {
  // Follwing commented code has been moved from here to ...\server\services\search_courses_by_text_service.mjs.
  {/*
  // delete school names with already -AMKosaaja endings - this can happen only if the user selects the school names too fastly
  for (let i=0; i<selectedSchool.length; i++){
    if(selectedSchool[i].includes("-AMKosaaja")){
      selectedSchool.splice(i,1);
    }
  }

  // update the schoolnames if "AMKosaaja" is selected
  let selectSchoolNew=[""];

  let checkFirst=selectedSchool.includes("AMKosaaja");
  if(checkFirst && selectedSchool.length>1){
    for (let i=0; i<selectedSchool.length; i++){
      if(selectedSchool[i]!="AMKosaaja"){
        selectSchoolNew[i]=selectedSchool[i]+"-AMKosaaja";
      }
    }
  }  else if(checkFirst && selectedSchool.length==1){
    selectSchoolNew=["haaga-helia-amkosaaja,metropolia-amkosaaja,hamk-amkosaaja,laurea-amkosaaja,xamk-amkosaaja"];
    }
    else {
      for (let i=0; i<selectedSchool.length; i++){
          if(selectedSchool[i]=="Hamk" || selectedSchool[i]=="Xamk"){
            selectSchoolNew[i]=selectedSchool[i]+"-AMKosaaja";
        }
      //else {
        selectSchoolNew=selectedSchool;
        //}
    }
  }

  // delete all empty strings
  selectSchoolNew = selectSchoolNew.filter(e => e !== '');
*/}
  return async (dispatch) => {
    dispatch({
      type: "FETCHING_COURSEDATA",
    });
    
    const courses = await getCourseByText(skill, selectedSchool);
    // filter out all courses that does not have valid url
    // const validResults = courses.results.filter((c) => c["url"] !== "api");
    dispatch({
      type: "GET_COURSES",
      data: { skills: courses.skills, results: courses.data },
    });
  };
};

export default courseSearchReducer;

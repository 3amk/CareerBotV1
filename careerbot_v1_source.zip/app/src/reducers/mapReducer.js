import { getExampleMaps } from "../services/maps";

const mapReducer = (
  state = { results: [], isLoading: false, isLoaded: false },
  action
) => {
  switch (action.type) {
    case "LOADED_EXAMPLE_MAPS":
      return { results: action.data, isLoading: false, isLoaded: true };
    case "FETCHING_EXAMPLE_MAPS":
      return { ...state, isLoading: true };
    default:
      return state;
  }
};

export const fetchExampleMaps = () => {
  return async (dispatch) => {
    dispatch({
      type: "FETCHING_EXAMPLE_MAPS",
      data: [],
    });
    const maps = await getExampleMaps();
    dispatch({
      type: "LOADED_EXAMPLE_MAPS",
      data: maps,
    });
  };
};

export default mapReducer;

import { getStaticThesisWord,
   getStaticThesisWordGlobal } from "../services/theseus";

const theseusKeywordsReducer = (
  state = { results: {}, isEmpty:false, isLoading: false, theseusType:false, globalType:false },
  action
) => {
  switch (action.type) {
    case "GET_THESEUSKEYWORDS":{ 
      var allKeywordsHaveZeroResults = false;
      const allResults = action.data.data;
      const nKeywords = allResults.length;
      for (var i=0; i < nKeywords; i++){
        const keywordInfo = allResults[i];
        var nResults = 0;
        for (var j=0; j < keywordInfo.stats.length; j++){
          nResults += keywordInfo.stats[i];
        }
        if (nResults != 0) break; // Almost one keyword has results to show
        if (i == nKeywords - 1 && nResults == 0) allKeywordsHaveZeroResults = true; // At the end of the loop
      }
      
      const isEmpty = allKeywordsHaveZeroResults;

      return {
        results: action.data,
        isEmpty:isEmpty,
        isLoading: false,
        theseusType:true,
        globalType:false
      }
    }
    
    case "GET_THESEUSKEYWORDSGLOBAL":{ 
      var allKeywordsHaveZeroResults = false;
      const allResults = action.data.data;
      const nKeywords = allResults.length;
      for (var i=0; i < nKeywords; i++){
        const keywordInfo = allResults[i];
        var nResults = 0;
        for (var j=0; j < keywordInfo.stats.length; j++){
          nResults += keywordInfo.stats[i];
        }
        if (nResults != 0) break; // Almost one keyword has results to show
        if (i == nKeywords - 1 && nResults == 0) allKeywordsHaveZeroResults = true; // At the end of the loop
      }
      
      const isEmpty = allKeywordsHaveZeroResults;

      return {
        results: action.data,
        isEmpty:isEmpty,
        isLoading: false,
        theseusType:false,
        globalType:true
      }
    };
    case "FETCHING_THESEUSKEYWORDS":
      return { ...state, isLoading: true };
      case "FETCHING_THESEUSKEYWORDSGLOBAL":{
      return { ...state, isLoading: true };}
    case "ROMEVE_THESEUSKEYWORDS":
      return { results: {}, isLoading: false };
    default:
      return state;
  }
};

export const getTheseusKeywords = (text) => {
  return async (dispatch) => {
    dispatch({
      type: "FETCHING_THESEUSKEYWORDS",
    });
    const keywords = await getStaticThesisWord(text);
    dispatch({
      type: "GET_THESEUSKEYWORDS",
      data: keywords,
    });
  };
};

export const getTheseusKeywordsGlobal = (text) => {
  return async (dispatch) => {
    dispatch({
      type: "FETCHING_THESEUSKEYWORDSGLOBAL",
    });
    const keywords = await getStaticThesisWordGlobal(text);
    dispatch({
      type: "GET_THESEUSKEYWORDSGLOBAL",
      data: keywords,
    });
  };
};


export const removeThesuesKeywords = () => {
  return {
    type: "ROMEVE_THESEUSKEYWORDS",
  };
};

export default theseusKeywordsReducer;

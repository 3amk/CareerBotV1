import {
  getSkillsProfile,
  createNewProfile,
  deleteProfile,
} from "../services/skillsProfile";
import { setNotification } from "./notificationReducer";

const profilesReduder = (state = [], action) => {
  switch (action.type) {
    case "NEW_PROFILE":
      return action.data;
    case "INIT_PROFILES":
      return action.data;
    case "REMOVE_PROFILE":
      return state.filter((profile) => profile.name !== action.data);
    case "CLEAR_ALL_PROFILES":
      return action.data;
    default:
      return state;
  }
};

export const addProfile = (content) => {
  return async (dispatch) => {
    const data = await createNewProfile(content);
    if (!data.error) {
      const profiles = await getSkillsProfile();
      //console.log("add profile data: ", profiles);
      dispatch({
        type: "NEW_PROFILE",
        data: profiles.data,
      });
      return;
    }
    dispatch(setNotification(`Error: ${data.error}`, 5, "error"));
  };
};

export const initializeProfiles = () => {
  return async (dispatch) => {
    const profiles = await getSkillsProfile();
    if (profiles && profiles.data !== undefined) {
      dispatch({
        type: "INIT_PROFILES",
        data: profiles.data,
      });
    } else {
      if (profiles === null || profiles.error.message === "jwt expired") {
        dispatch({
          type: "LOGOUT_USER",
          data: null,
        });
      }
      dispatch({
        type: "INIT_PROFILES",
        data: [],
      });
    }
  };
};

export const removeProfile = (profile) => {
      let data =profile;
      let buff = new Buffer(data);
      let encodedProfileName = buff.toString('base64');
  return async (dispatch) => {
    await deleteProfile(encodedProfileName);
    dispatch({
      type: "REMOVE_PROFILE",
      data: profile,
    });
    dispatch({
      type: "REMOVE_PROFILEDATA",
      data: { name: profile },
    });
  };
};

export default profilesReduder;

const initialState = { message: "", type: null };

const notificationReducer = (state = initialState, action) => {
  switch (action.type) {
    case "SET_NOTIFICATION":
      return { message: action.data.content, type: action.data.type };
    case "CLEAR_NOTIFICATION":
      return { message: null, type: false };
    default:
      return state;
  }
};

let timeoutId;

export const setNotification = (content, time, type) => {
  return async (dispatch) => {
    dispatch({
      type: "SET_NOTIFICATION",
      data: { content, type },
    });

    if (timeoutId) {
      clearTimeout(timeoutId);
    }

    timeoutId = setTimeout(() => {
      dispatch({
        type: "CLEAR_NOTIFICATION",
      });
    }, time * 1000);
  };
};

export const clearNotification = () => ({ type: "CLEAR_NOTIFICATION" });

export default notificationReducer;

import { getProfileData, updateProfile } from "../services/skillsProfile";


const profileDataReducer = (state = {}, action) => {
  switch (action.type) {
    case "GET_PROFILEDATA":
      return { ...state, [action.data.name]: action.data };
    case "UPDATE_PROFILEDATA":
      state[action.data.name] = action.data;
      return { ...state };
    case "REMOVE_PROFILEDATA":
      delete state[action.data.name];
      return { ...state };
    default:
      return state;
  }
};

export function getProfile(profileName) {
  return async (dispatch) => {
    const profile = await getProfileData(profileName);
    dispatch({
      type: "GET_PROFILEDATA",
      data: profile.data,
    });
  };
}

export function updateProfileData(profileData, profileName) {
  return async (dispatch) => {
    await updateProfile(profileData);
      let data =profileName;
      let buff = new Buffer(data);
      let encodedProfileName = buff.toString('base64');
    const profile = await getProfileData(encodedProfileName);
    dispatch({
      type: "UPDATE_PROFILEDATA",
      data: profile.data,
    });
  };
}

export default profileDataReducer;

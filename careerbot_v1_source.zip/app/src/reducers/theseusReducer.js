import { getRelatedThesis, getRelatedArticle } from "../services/theseus";

const theseusReducer = (
  state = { results: [], isLoading: false, isLoaded: false, theseusType:false, globalType:false  },
  action
) => {
  switch (action.type) {
    case "GET_THESEUS":
      return {
        results: action.data,
        isLoading: false,
        isLoaded: true,
        theseusType:true,
        globalType:false
      };
     case "GET_ARTICLE":
      return {
        results: action.data,
        isLoading: false,
        isLoaded: true,
        theseusType:false,
        globalType:true
      };
    case "FETCHING_THESEUS":
      return { ...state, isLoading: true, isLoaded: false };

    case "ROMEVE_THESEUS":
      return { results: [], isLoading: false, isLoaded: false };
    default:
      return state;
  }
};

export const getTheseus = (keywords) => {
  return async (dispatch) => {
    dispatch({
      type: "FETCHING_THESEUS",
    });
    const theseus = await getRelatedThesis(keywords);
    dispatch({
      type: "GET_THESEUS",
      data: theseus.data || [],
    });
  };
};

export const getArticle = (keywords) => {
  return async (dispatch) => {
    dispatch({
      type: "FETCHING_THESEUS",
    });
    const theseus = await getRelatedArticle(keywords);
    dispatch({
      type: "GET_ARTICLE",
      data: theseus.data || [],
    });
  };
};

export const removeThesis = () => {
  return {
    type: "ROMEVE_THESEUS",
  };
};

export default theseusReducer;

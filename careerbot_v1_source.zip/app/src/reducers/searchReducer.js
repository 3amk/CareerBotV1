/*
 * This reducer is not used with the global redux store.
 * Is is only used for local search component state management using useReducer
 */
export const initialState = {
  isLoading: false,
  results: [],
  value: "",
  selection: null,
};

function SearchReducer(state, action) {
  switch (action.type) {
    case "CLEAN_QUERY":
      return initialState;
    case "START_SEARCH":
      return { ...state, isLoading: true, value: action.query };
    case "FINISH_SEARCH":
      return { ...state, isLoading: false, results: action.results };
    case "UPDATE_SELECTION":
      return { ...state, selection: action.selection, value: action.value };

    default:
      throw new Error("Unkown Search reducer action.");
  }
}

export default SearchReducer;

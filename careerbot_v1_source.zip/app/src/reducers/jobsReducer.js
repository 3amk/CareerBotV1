import getJobs from '../services/skillsToJob'

const jobsReducer = (
  state = {
    jobResult: { results: null, response_to: [] },
    isLoading: false,
  },
  action
) => {
  switch (action.type) {
  case 'GET_JOBS':
    return { jobResult: action.data, isLoading: false }
  case 'FETCHING_JOBDATA':
    return { ...state, isLoading: true }
  default:
    return state
  }
}

export const searchJobs = (selectedArea, startDate, skills) => {
  return async (dispatch) => {
    dispatch({
      type: 'FETCHING_JOBDATA',
    })
    const jobs = await getJobs(selectedArea, startDate, skills)
    dispatch({
      type: 'GET_JOBS',
      data: jobs,
    })
  }
}

export default jobsReducer

import React, { useEffect, useState } from "react";
import { Helmet } from "react-helmet";
import { useTranslation } from "react-i18next";
import { Container, Menu, Segment } from "semantic-ui-react";

import MapList from "../components/MapList";
import ExampleMaps from "../components/ExampleMaps";
import PageHeading from "../components/PageHeading";
import mapsSVG from "../public/images/Backgrounds/Maps.svg";

/*
 * Maps page component
 */
const MapsPage = () => {
  const { t } = useTranslation();

  const [menuItems, setMenuItems] = useState([
    t("maps.example"),
    t("maps.available"),
  ]);
  const [activeItem, setActiveItem] = useState(t("maps.available"));

  useEffect(() => {
    setMenuItems([t("maps.example"), t("maps.available")]);
    setActiveItem(t("maps.available"));
  }, [t]);
  const menuItemClickHandler = (e, { name }) => {
    setActiveItem(name);
  };

  return (
    <div className="page-container">
      <div className="mapsContainer">
          <img src={mapsSVG} className="maps-bg" style={{ opacity: 0.5, height: "100%" }} />
      </div>
      <div className="maps-bg2" />
      <Container>
        <Helmet>
          <title>Semantic Maps</title>
        </Helmet>
        <PageHeading
          headingTxt={t("maps.semanticMaps")}
          contentTxt={t("maps.text")}
        />
        <div>
        <Segment style={{ boxShadow: "none", border: "none", margin: "-13px -13px -26px -13px" }}>
          <Menu color="blue" pointing secondary>
            {menuItems.map((item, i) => (
              <Menu.Item
                key={i}
                name={item}
                active={activeItem === item}
                onClick={menuItemClickHandler}
              />
            ))}
          </Menu>
        </Segment>
        </div>
        <div>
          {activeItem === menuItems[0] && <ExampleMaps />}
          {activeItem === menuItems[1] && <MapList />}
        </div>
      </Container>
    </div>
  );
};

export default MapsPage;

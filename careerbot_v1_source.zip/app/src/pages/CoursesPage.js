import React from "react";
import { Helmet } from "react-helmet";
import { Container } from "semantic-ui-react";
import { useSelector } from "react-redux";
import { useTranslation } from "react-i18next";

import CourseForm from "../components/CourseForm";
import CourseList from "../components/CourseList";
import WithLoading from "../components/WithLoading";
import KeywordComponent from "../components/KeywordComponent";
import PageHeading from "../components/PageHeading";
import coursesSVG from "../public/images/Backgrounds/Courses.svg";

const CoursesWithLoading = WithLoading(CourseList);

const CoursesPage = () => {
  const { t } = useTranslation();
  const courses = useSelector((state) => state.courseSearch);

  return (
    <div className="page-container">
      {courses.courseResult.results && 
        courses.courseResult.results.length > 0 && (
        <>
        <div className="coursesContainer">
            <img src={coursesSVG} className="courses-bg" style={{ height: "100%"}} />
        </div>
        <div className="courses-bg2" />
        </>
      )}
      <Container>
        <Helmet>
          <title>Courses</title>
        </Helmet>
        <PageHeading
          headingTxt={t("courses.heading")}
          contentTxt={t("courses.heading-content")}
        />
        <div>
          <CourseForm />
        </div>
        <div>
          <div style={{ marginTop: "30px" }}>
            {courses.courseResult.results &&
              courses.courseResult.results.length > 0 && (
                <KeywordComponent keywords={courses.courseResult.skills} />
              )}
            <CoursesWithLoading
              loadingText={t("courses.loadingText")}
              isLoading={courses.isLoading}
              loadingMessage={t("theseus.loading")}
              courses={courses.courseResult.results}
            />
          </div>
        </div>
      </Container>
    </div>
  );
};

export default CoursesPage;

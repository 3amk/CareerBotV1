import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import { Helmet } from "react-helmet";
import { useSelector } from "react-redux";
import {
  Header,
  Dropdown,
  Container,
  Form,
  Grid,
  Segment,
} from "semantic-ui-react";
import { JobSearchInput } from "../components/JobSearchInput";
import WithLoading from "../components/WithLoading";
import JobList from "../components/JobList";
import KeywordComponent from "../components/KeywordComponent";
import PageHeading from "../components/PageHeading";
import jobsSVG from "../public/images/Backgrounds/Jobs.svg";

const JobsWithLoading = WithLoading(JobList);

const JobsPage = () => {
  const { t } = useTranslation();
  const sortPredicates = ["relevancy", "lastDate"];
  const sortOptions = sortPredicates.map((p, i) => ({
    key: i,
    text: t(`jobs.${p}`),
    value: p,
  }));

  const [selectedOption, setSelectedOption] = useState(sortPredicates[0]);
  const jobs = useSelector((state) => state.jobs);

  const keywords =
    jobs.jobResult.response_to.skills_searched &&
    jobs.jobResult.response_to.skills_searched.split(",");
  const searchedSkill = keywords
    ? keywords.filter((skill) => skill !== " ")
    : [];

  const sortOptionHandler = (e, data) => {
    if (data.value !== selectedOption) setSelectedOption(data.value);
  };

  const sortedJobs =
    selectedOption === "lastDate"
      ? jobs.jobResult.results &&
        jobs.jobResult.results.sort(
          (a, b) => new Date(b.time) - new Date(a.time)
        )
      : jobs.jobResult.results && 
        jobs.jobResult.results.sort(
          (a, b) => Number(b.relevancy) - Number(a.relevancy)
        );

  return (
    <div>
      {/* Load background container, background and gradient overlay on loaded job results */}
          <>
            {sortedJobs != null && sortedJobs.length > 1 && !jobs.isLoading ? (
              <>
                <div className="jobsContainer">
                  <img src={jobsSVG} className="jobs-bg" style={{ height: "100%" }} />
                </div>
                <div className="jobs-bg2">
                </div>
                </>
            ) : (
                <div className="jobsContainer">
                </div>
            )}
          </>
      <div className="page-container">
        <Container>
          <Helmet>
            <title>Jobs</title>
          </Helmet>
          <PageHeading
            headingTxt={t("jobs.heading")}
            contentTxt={t("jobs.heading-content")}
          />
          <div>
            <JobSearchInput />
          </div>

          <div style={{ marginTop: "30px" }}>
            {searchedSkill.length > 0 && (
              <KeywordComponent keywords={searchedSkill} />
            )}
            <Grid stackable>
              <Grid.Row columns={1}>
                {/*<Grid.Column className="padless-column" width={4}>
                  {sortedJobs && sortedJobs.length > 0 && (
                    <>
                      <Segment attached="top">
                        <Header as="h4" content={t("app.filters")} />
                      </Segment>
                      <Segment attached>
                        <Form onSubmit={null}>
                          <Form.Group>
                            <Form.Field
                              width={16}
                              label={{
                                children: (
                                  <label className="label">{t("jobs.sortBy")}</label>
                                ),
                              }}
                              control={Dropdown}
                              selection
                              fluid
                              defaultValue={"relevancy"}
                              options={sortOptions}
                              onChange={sortOptionHandler}
                            />
                          </Form.Group>
                        </Form>
                      </Segment>
                    </>
                  )}
                </Grid.Column>*/}
                <Grid.Column className="padless-column">
                  <JobsWithLoading
                    loadingText={t("jobs.loadingText")}
                    isLoading={jobs.isLoading}
                    loadingMessage={t("theseus.loading")}
                    jobs={sortedJobs}
                    keywords
                  />
                </Grid.Column>
              </Grid.Row>
            </Grid>
          </div>
        </Container>
      </div>
    </div>
  );
};

export default JobsPage;

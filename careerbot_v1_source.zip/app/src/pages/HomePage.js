import React from "react";
import { useTranslation } from "react-i18next";
import { Helmet } from "react-helmet";
import {
  Container,
  Button,
  Grid,
  Image,
  Header,
  Segment,
  Divider,
  Icon,
} from "semantic-ui-react";

import homeSVG from "../public/images/Backgrounds/Home.svg";
import bannerImage from "../public/images/3amk-header-banner.png";
import resumeFolderImg from "../public/images/resume_folder.svg";
import fileSearchingImg from "../public/images/file_searching.svg";
import educationImg from "../public/images/education.svg";
import mindMapImg from "../public/images/mind_map.svg";
import dataTrendsImg from "../public/images/data_trends.svg";
import { Link } from "react-router-dom";

const HomePage = () => {
  const { t } = useTranslation();
  const scrollTop = () => {
    window.scrollTo(0, 0);
    
  };

  const appFeatures = [
    {
      image: resumeFolderImg,
      imageAlt: "resume folder",
      buttonText: t("home.buildSkillsBtnText"),
      link: "/skills_profile",
      title: t("home.buildSkillsTitle"),
      content: t("home.buildSkillsContent"),
    },
    {
      image: fileSearchingImg,
      imageAlt: "job search",
      buttonText: t("home.searchJobsBtnText"),
      link: "/jobs",
      title: t("home.searchJobsTitle"),
      content: t("home.searchJobsContent"),
    },
    {
      image: educationImg,
      imageAlt: "course search",
      buttonText: t("home.searchCoursesBtnText"),
      link: "/courses",
      title: t("home.searchCoursesTitle"),
      content: t("home.searchCoursesContent"),
    },
    {
      image: mindMapImg,
      imageAlt: "semantic map",
      buttonText: t("home.semanticMapsBtnText"),
      link: "/maps",
      title: t("home.semanticMapsTitle"),
      content: t("home.semanticMapsContent"),
    },
    {
      image: dataTrendsImg,
      imageAlt: "theseus search",
      buttonText: t("home.thesuesSearchBtnText"),
      link: "/theseus",
      title: t("home.theseusSearchTitle"),
      content: t("home.thesuesSearchContent"),
    },
  ];

  const lastFeatureIndex = appFeatures.length - 1;

  return (
    <div>
      <div className="fade-in">
        {/* Background container, image and gradient overlay */}
      <div className="homeContainer">
        <img src={homeSVG} className="home-bg" style={{height: "100%"}} />
        </div>
        </div>
      <div className="home-bg2">
        <Helmet>
          <title>CareerBot</title>
        </Helmet>
        <h1>CareerBot</h1>
        <p className="headline-subtext">{t("home.headingTitleText")}</p>
      </div>
      <div className="relative-container">
        <Container style={{ paddingTop: 60 }}>
          <Segment>
            <div className="features-container">
              {appFeatures.map((feature, i) => (
                <div key={i}>
                  <Grid
                    stackable
                    padded
                    relaxed
                    reversed={i % 2 === 0 ? null : "computer"}
                  >
                    <Grid.Row columns={2}>
                      <Grid.Column>
                        <Image
                          className="feature-image"
                          size="large"
                          centered
                          src={feature.image}
                          alt={feature.imageAlt}
                        />
                      </Grid.Column>
                      <Grid.Column verticalAlign="middle">
                        <Header as="h1" content={feature.title} />
                        <p style={{ color: "rgb(97, 97, 97)" }}>
                          {feature.content}
                        </p>
                        <Link to={feature.link}>
                          <Button
                            color="blue"
                            floated="left"
                            content={feature.buttonText}
                            onClick={scrollTop}
                          />
                        </Link>
                      </Grid.Column>
                    </Grid.Row>
                  </Grid>
                  {i < lastFeatureIndex && (
                    <div className="feature-divider">
                      <Divider section />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </Segment>
        </Container>
        {/* 3AMK banner image */}
        <div style={{ padding: "64px 0px" }}>
          <Container textAlign="center">
          <a href="https://www.3amk.fi/">
            <Image
              className="banner-image"
              size="big"
              centered
              src={bannerImage}
              alt="Banner"
              style={{ imageRendering: "high-quality" }}
            />
            </a>
            <Container text>
              <p
                style={{
                  color: "#616161",
                  fontSize: "18px",
                }}
              >
                {t("home.text")}
              </p>
            </Container>
          </Container>
        </div>
      </div>
    </div>
  );
};

export default HomePage;

import React, { useRef, useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { useDispatch, useSelector } from "react-redux";
import { Helmet } from "react-helmet";
import {
  Button,
  Container,
  Form,
  Header,
  Loader,
  Menu,
  Segment,
  TextArea,
  Icon,
  Popup,
} from "semantic-ui-react";
import ThesisKeywordContainer from "../components/ThesisKeywordContainer";
import TheseusList from "../components/TheseusList";
import NoResultSegment from "../components/NoResultSegment";
import {
  getTheseusKeywords,
  getTheseusKeywordsGlobal,
  removeThesuesKeywords,
} from "../reducers/theseusKeywordsReducer";
import { removeThesis } from "../reducers/theseusReducer";
import PageHeading from "../components/PageHeading";
import thesesSVG from "../public/images/Backgrounds/Theses.svg";
import LoaderCube from "../components/LoaderCube";

const TheseusPage = () => {
  const { t } = useTranslation();
  const [keywords, setKeywords] = useState("");
  const [formError, setFormError] = useState(null);

  const refTrend = useRef(null);
  const refThesis = useRef(null);

  const theseusKeywords = useSelector((state) => state.theseusKeywords);
  const [keywordsLoaded, setKeywordsLoaded] = useState(false);
  const [theseusType, setTheseusType] = useState(true);
  const [globalType, setGlobalType] = useState(false);
  //const [isEmpty, setIsEmpty] = useState(false);
  const theseus = useSelector((state) => state.theseus);
  const dispatch = useDispatch();


  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const errorValue = [];
  const reformattedData = [];
  var errorFilteredData = [];

  // horizontal menu items
  const [menuItems, setMenuItems] = useState([
    t("theseus.finland"),
    t("theseus.global"),
  ]);

  /* Menu items state hook funciton. This menus are My Skills, CV certificate and courses menu. */
  const [activeItem, setActiveItem] = useState("theseus.finland");
  useEffect(() => {
    setMenuItems([
      t("theseus.finland"),
      t("theseus.global"),
    ]);
    setActiveItem(t("theseus.finland"));
    theseusKeywords.isEmpty=false;
    //setIsEmpty(false);
  }, [t]);

  const menuItemClickHandler = (e, { name }) => {
    setActiveItem(name);
    if(name==t("theseus.finland")) {
      setTheseusType(true);
      setGlobalType(false);
    } else {
    setTheseusType(false)
      setGlobalType(true);
    }

  };
  // Checking data for 0 total values. Graph should not display faulty data
  if (theseusKeywords.results.data) {
   for (var x = 0; x < theseusKeywords.results.data.length; x++ ) {
      if(theseusKeywords.theseusType==true && theseusKeywords.globalType==false){
      for (var i = 0; i < theseusKeywords.results.data[0].stats[0].stats.length; i++ ) {
        const sums = theseusKeywords.results.data[x].stats[0].stats.reduce((a, b) => a + b.count, 0);
        if (sums == 0) {
          if (errorValue.indexOf(theseusKeywords.results.data[x]) === -1) errorValue.push(theseusKeywords.results.data[x])
        }
      }
    }
    if(theseusKeywords.theseusType==false && theseusKeywords.globalType==true){
     for (var i = 0; i < theseusKeywords.results.data[0].stats.length; i++ ) {
        const sums = theseusKeywords.results.data[x].stats.reduce((a, b) => a + b.count, 0);
        if (sums == 0) {
          if (errorValue.indexOf(theseusKeywords.results.data[0].stats[x]) === -1) errorValue.push(theseusKeywords.results.data[0].stats[x])
        }
        }
    }
    }
    // Checking for duplicates, results should display only once.
    if (errorValue){
      theseusKeywords.results.data.forEach((d, i) => {
        errorFilteredData = theseusKeywords.results.data.filter(val => !errorValue.includes(val));
      })
    }
  }  


  // Filtering out duplicates
  const duplicateRemoval = errorFilteredData.reduce((d, i) => {
    const x = d.find(item => item.word === i.word);
    if (!x) {
      return d.concat([i]);
    } else {
      return d;
    }
  }, []);

  // New data set to be displayed in keywords container and on graph. No duplicates and 0 sum data.
  reformattedData.push({
    data: duplicateRemoval,
    relations: theseusKeywords.results.relations,
  })

  useEffect(() => {
      if (theseusKeywords.results.data) {
        if (theseusKeywords.results.data.length > 0) {
          Object.keys(theseusKeywords.results).length !== 0 &&
            refTrend.current.scrollIntoView({
              behavior: "smooth",
              block: "nearest",
            });
        } else {
          setKeywordsLoaded(true);
          dispatch(removeThesuesKeywords());
          document.location.reload(true);
        }
      }
  }, [theseusKeywords.results, dispatch]);

  useEffect(() => {
    if ((theseus.results && theseus.results.length > 0) ) {
      (theseus.results.length !== 0 || theseus.isLoading) &&
        refThesis.current.scrollIntoView({
          behavior: "smooth",
          block: "nearest",
        });
    }
  }, [theseus.results, theseus.isLoading]);

  const handleChange = (e) => {
    setKeywords(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (keywords.length < 2) {
      setFormError({
        content: t("error.enterValidSkill"),
        pointing: "below",
      });
      return;
    }
    dispatch(removeThesis());
    let processedKeywords = keywords.split(",").map((word) => word.trim());
    processedKeywords = processedKeywords.map((w) => w.replace(/\s+/g, "_"));
    
    if(activeItem==t("theseus.finland")){
      dispatch(removeThesuesKeywords());
   dispatch(getTheseusKeywords(processedKeywords.toString()));
   //setIsEmpty(theseusKeywords.isEmpty);
   setFormError(null);
    };

    if(activeItem==t("theseus.global")){
      dispatch(getTheseusKeywordsGlobal(processedKeywords.toString()));   //// update the dispatch, reucers and backend accordingly
      //setIsEmpty(theseusKeywords.isEmpty);
      //setKeywords("");
      setFormError(null);
      };
  };

  if(theseusType==true){
  return (
    <div className="page-container">
      {/* Load background container, background and gradient overlay on loading of results, larger image for 50 results */}
      <>
        {theseus.isLoaded && (
          <>
            {theseus.results && theseus.results.length === 50 ? (
              <div>
                <div className="thesesContainer">
                <div className="fade-in">
              </div>
              <img src={thesesSVG} className="theses-bg" style={{ height: "100%" }} />
                </div>
                  <div className="theses-bg2" />
                </div>
            ) : theseus.results && theseus.results.length >= 5 ? (
              <div>
                <div className="thesesContainer">
                <div className="fade-in">
              </div>
              <img src={thesesSVG} className="theses-bg" style={{ height: "100%" }} />
                </div>
                  <div className="theses-bg2-smaller" />
                </div>
            ) : (
            <div/>
            )}
          </>
        )}
      </>
      <Container>
        <Helmet>
          <title>Theses</title>
        </Helmet>
        <PageHeading
          headingTxt={t("theseus.heading")}
          contentTxt={t("theseus.heading-content")}
        />

          <div>
            <Menu color="blue" pointing secondary>
              {menuItems.map((item, i) => (
                <Menu.Item
                  key={i}
                  name={item}
                  active={activeItem === item}
                  onClick={menuItemClickHandler}
                />
              ))}
            </Menu>
          </div>
     
        <Segment clearing>
          <Form onSubmit={handleSubmit}>
            <Form.Group>
              <div style={{ marginBottom: "16px", width: "100%" }}>
                <Form.Field
                  control={TextArea}
                  onChange={handleChange}
                  value={keywords}
                  label={t("theseus.skillLabelThesis")}
                  placeholder={t("theseus.skillPlaceholder")}
                  error={formError}
                  rows="1"
                />
              </div>
            </Form.Group>
            <Button
              color="blue"
              content={t("theseus.submitThesis")}
              floated="right"
            />
          </Form>
        </Segment>
        <div style={{ marginTop: "30px" }}>
          <div ref={refTrend}>
            <ThesisKeywordContainer
              resultsOriginal={theseusKeywords.results}
              results={reformattedData[0]}
              isEmpty={theseusKeywords.isEmpty}
              theseusType={theseusKeywords.theseusType}
              globalType={theseusKeywords.globalType}
              isLoading={theseusKeywords.isLoading}
              loaded={keywordsLoaded}
            />
          </div>
          <div style={{ marginTop: "30px" }} ref={refThesis}>
            {theseus.isLoading ? (
              <Segment style={{ border: "0px", boxShadow: "none", overflow: "hidden" }}>
                <LoaderCube />
                <div style={{ padding: "50px 0px 50px 0px" }}>
                  <h4 className="loading-text">{t("theseus.spinnerThesis")}</h4>
                  <p className="loading-message">{t("loading.loadingMessage")}</p>
                </div>
              </Segment>
            ) : (
              <>
                {theseus.isLoaded && (
                  <>
                    {theseus.results && theseus.results.length > 0 ? (
                      <Segment.Group>
                        <Segment>
                        <Header as="h4" content={theseus.results.length + " " + t("theseus.thesisresulttext")} />
                        </Segment>
                        <Segment>
                          <TheseusList theseus={theseus.results} theseusKeywords={theseusKeywords.results} theseusType={theseus.theseusType} globalType={theseus.globalType} />
                        </Segment>
                      </Segment.Group>
                    
                    ) : (
                      // Does not always load with filtered data
                      <NoResultSegment message={t("theseus.noResult")} />
                    )}
                  </>
                )}
              </>
            )}
            {/* Error filled data will not set loading from API, not the most elegant of solutions, but this will bring back the no results segment. */}
            {theseusKeywords.results.data &&
            theseusKeywords.results.data != undefined && 
            theseusKeywords.results.data.length > 0 && 
            theseusKeywords.isLoading != true &&
            errorValue.length > 0 && 
            theseusKeywords.isEmpty != false && (
              <NoResultSegment message={t("theseus.noResult")} />
            )}
          </div>
        </div>
      </Container>
    </div>
  );
}
if(globalType==true){
  return (
    <div className="page-container">
      {/* Load background container, background and gradient overlay on loading of results, larger image for 50 results */}
      <>
        {theseus.isLoaded && (
          <>
            {theseus.results && theseus.results.length === 50 ? (
              <div>
                <div className="thesesContainer">
                <div className="fade-in">
              </div>
              <img src={thesesSVG} className="theses-bg" style={{ height: "100%" }} />
                </div>
                  <div className="theses-bg2" />
                </div>
            ) : theseus.results && theseus.results.length >= 5 ? (
              <div>
                <div className="thesesContainer">
                <div className="fade-in">
              </div>
              <img src={thesesSVG} className="theses-bg" style={{ height: "100%" }} />
                </div>
                  <div className="theses-bg2-smaller" />
                </div>
            ) : (
            <div/>
            )}
          </>
        )}
      </>
      <Container>
        <Helmet>
          <title>Theses</title>
        </Helmet>
        <PageHeading
          headingTxt={t("theseus.heading")}
          contentTxt={t("theseus.heading-content")}
        />

          <div>
            <Menu color="blue" pointing secondary>
              {menuItems.map((item, i) => (
                <Menu.Item
                  key={i}
                  name={item}
                  active={activeItem === item}
                  onClick={menuItemClickHandler}
                />
              ))}
            </Menu>
          </div>
     
        <Segment clearing>
          <Form onSubmit={handleSubmit}>
            <Form.Group>
              <div style={{ marginBottom: "16px", width: "100%" }}>
                <Form.Field
                  control={TextArea}
                  onChange={handleChange}
                  value={keywords}
                  label={t("theseus.skillLabelArticle")}
                  placeholder={t("theseus.skillPlaceholder")}
                  error={formError}
                  rows="1"
                />
              </div>
            </Form.Group>
            <Button
              color="blue"
              content={t("theseus.submitArticle")}
              floated="right"
            />
          </Form>
        </Segment>
        <div style={{ marginTop: "30px" }}>
          <div ref={refTrend}>
            <ThesisKeywordContainer
              resultsOriginal={theseusKeywords.results}
              results={reformattedData[0]}
              isEmpty={theseusKeywords.isEmpty}
              theseusType={theseusKeywords.theseusType}
              globalType={theseusKeywords.globalType}
              isLoading={theseusKeywords.isLoading}
              loaded={keywordsLoaded}
            />
          </div>
          <div style={{ marginTop: "30px" }} ref={refThesis}>
            {theseus.isLoading ? (
              <Segment style={{ border: "0px", boxShadow: "none", overflow: "hidden" }}>
                <LoaderCube />
                <div style={{ padding: "50px 0px 50px 0px" }}>
                  <h4 className="loading-text">{t("theseus.spinnerArticle")}</h4>
                  <p className="loading-message">{t("loading.loadingMessage")}</p>
                </div>
              </Segment>
            ) : (
              <>
                {theseus.isLoaded && (
                  <>
                    {theseus.results && theseus.results.length > 0 ? (
                      <Segment.Group>
                        <Segment>
                        <Header as="h4" content={theseus.results.length + " " + t("theseus.thesisresulttext")} />
                        </Segment>
                        <Segment>
                          <TheseusList theseus={theseus.results} theseusKeywords={theseusKeywords.results} theseusType={theseus.theseusType} globalType={theseus.globalType} />
                        </Segment>
                      </Segment.Group>
                    
                    ) : (
                      // Does not always load with filtered data
                      <NoResultSegment message={t("theseus.noResultArticle")} />
                    )}
                  </>
                )}
              </>
            )}
            {/* Error filled data will not set loading from API, not the most elegant of solutions, but this will bring back the no results segment. */}
            {theseusKeywords.results.data &&
            theseusKeywords.results.data != undefined && 
            theseusKeywords.isLoading != true &&
            theseusKeywords.isEmpty != false &&
            errorValue.length > 0 && (
              <NoResultSegment message={t("theseus.noResultArticle")} />
            )}
          </div>
        </div>
      </Container>
    </div>
  );
}
};

export default TheseusPage;

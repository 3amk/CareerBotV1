import React from "react";
import { Helmet } from "react-helmet";
import { useTranslation } from "react-i18next";
import { Link } from "react-router-dom";
import { Button, Header, Image, Segment } from "semantic-ui-react";

import PageNotFoundImg from "../public/images/not_found.svg";

const NotFoundPage = () => {
  const { t } = useTranslation();
  return (
    <div className="page-container">
      <Helmet>
        <title>Page Not Found</title>
      </Helmet>
      <Segment textAlign="center" clearing basic>
        <Image
          centered
          size="medium"
          src={PageNotFoundImg}
          alt="page not found"
        />
        <Header
          as="h1"
          textAlign="center"
          content={t("app.pageNotFoundTitle")}
        />
        <p style={{ color: "rgb(97, 97, 97)" }}>
          {t("app.pageNotFoundContent")}
        </p>
        <Segment.Inline>
          <Link to="/">
            <Button color="blue" content={t("nav.home")} />
          </Link>
        </Segment.Inline>
      </Segment>
    </div>
  );
};

export default NotFoundPage;

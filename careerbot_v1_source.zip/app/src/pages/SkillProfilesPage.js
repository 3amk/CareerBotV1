import React, { useEffect, useState } from "react";
import { Helmet } from "react-helmet";
import { useDispatch, useSelector } from "react-redux";
import { useTranslation } from "react-i18next";
import { Container, Button, Dropdown, Segment, Header} from "semantic-ui-react";

import { initializeProfiles, addProfile } from "../reducers/profilesReducers";
import { openLoginModal } from "../reducers/loginModalReducer";
import { setNotification } from "../reducers/notificationReducer";

import ShowProfileData from "../components/ShowProfileData";
import CreateProfileModal from "../components/ShowProfileData/CreateProfileModal";
import EmptySegment from "../components/EmptySegment";
import secureLoginImg from "../public/images/secure_login.svg";
import PageHeading from "../components/PageHeading";
import { deleteProfile } from "../services/skillsProfile";
import skillsSVG from "../public/images/Backgrounds/Skills.svg";


const SkillsProfilePage = () => {
  const { t } = useTranslation();
  const dispatch = useDispatch();

  const user = useSelector((state) => state.user);
  const profiles = useSelector((state) => state.profiles);
  // States for recognising if new profile created, new profile loaded after creation
  const [newProfile, setNewProfile] = useState(false);
  const [profileName, setProfileName] = useState("");
  const [selectedProfile, setSelectedProfile] = useState(
    profiles.length > 0 ? profiles[0].name : null
  );
  // Orders profiles in dropdown from newest to oldest, uses API's id to order
  const reformattedData = profiles.sort((a,b) => (a.id < b.id));
  // create new profile modal
  const [modalOpen, setModalOpen] = useState(false);

  // set selected profile after list of skill profiles change
  useEffect(() => {
    if (user.isAuthorised && profiles.length === 0) {
      setSelectedProfile(null);
    } if (user.isAuthorised && newProfile == true) {
      setSelectedProfile(profileName);
    } else if (user.isAuthorised && newProfile == false && profiles.length > 0) {
      setSelectedProfile(profiles[0].name);
    }
  }, [profiles]);

  // semantif-ui-react From handler (drop down list of profiles)
  const profileChangeHandler = (_, data) => {
    if (data.value !== selectedProfile) {
      setSelectedProfile(data.value);
    }
  };

  const createNewProfile = (profileName) => {
    const filtered = profiles.filter((p) => p.name === profileName);
    if (filtered.length === 0) {

      let data = profileName;
      let buff = new Buffer(data);
      let encodedProfileName = buff.toString('base64');

      dispatch(addProfile(encodedProfileName));
      dispatch(initializeProfiles());
      dispatch(
        setNotification(
          `${t("notification.newProfile")} "${profileName}" `,
          5,
          "success"
        )
      );
      setProfileName(data);
      setNewProfile(true);
      setModalOpen(false);
    } else {
      dispatch(setNotification(profileName + " " + t("profile.profileAlreadyExist"), 3, "error"));
      setModalOpen(false);
    }
  };

  return (
    <div className="page-container">
      {/* Load background container, background and overlay if skills loaded */}
      {selectedProfile !== null && (
        <>
          <div className="skillsContainer">
              <img src={skillsSVG} className="skills-bg" style={{ height: "100%" }} />
          </div>
            <div className="skills-bg2">
          </div>
        </>
      )}
      <Container>
        {/* Page title */}
        <Helmet>
          <title>Skills Profile</title>
        </Helmet>
        <PageHeading
          headingTxt={t("profile.skillsTitle")}
          contentTxt={t("profile.skillsContent")}
        />
        
        {/* Page body */}
        {/* If user not logged in show message login to create profiles */}
        {!user.isAuthorised ? (
          <EmptySegment
            image={secureLoginImg}
            imageAlt="secure login"
            title={t("app.notLoggedIn")}
            content={t("profile.notAuthorisedText")}
            btnText={t("loginForm.title")}
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              dispatch(openLoginModal());
            }}
          />
        ) : (
          <div>
            {/* show list of user's profiles if there are any */}
            <Segment clearing>
            <Header as="h3">{t("profile.selectProfile")}</Header>
            <div style={{ marginBottom: "16px" }}>
                <Dropdown
                  aria-label="select profile"
                  placeholder={t("profile.selectProfile")}
                  value={selectedProfile}
                  options={reformattedData.map((p, i) => ({
                    key: i,
                    value: p.name,
                    text: p.name,
                  }))}
                  onChange={profileChangeHandler}
                  noResultsMessage="Try creating new skill profile."
                  selection
                  fluid
                  defaultUpward
                  // allowAdditions
                  // search
                  // onAddItem={(e, { value }) => createNewProfile(value)}
                />
              </div>
              <Button
                floated="right"
                primary
                content={t("profile.createProfile")}
                onClick={(e, d) => {
                  e.preventDefault();
                  setModalOpen(true);
                }}
              />
            </Segment>
            {/* If user have more than 0 profiles and a profile is selected show profile data */}
            {selectedProfile !== null && (
              <ShowProfileData selectedProfile={selectedProfile} />
            )}
            {/* create new profile modal */}
            <CreateProfileModal
              modalOpen={modalOpen}
              onClose={() => setModalOpen(false)}
              createNewProfile={createNewProfile}
            />
          </div>
        )}
      </Container>
    </div>
  );
};

export default SkillsProfilePage;

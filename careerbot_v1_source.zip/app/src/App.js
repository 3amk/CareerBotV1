import React, { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import { createBrowserHistory } from "history";
import { useDispatch, useSelector } from "react-redux";

import { initializeProfiles } from "./reducers/profilesReducers";
import { loginUser } from "./reducers/userReducer";
import { setNotification } from "./reducers/notificationReducer";
import { closeLoginModal } from "./reducers/loginModalReducer";

import JobsPage from "./pages/JobsPage";
import CoursesPage from "./pages/CoursesPage";
import HomePage from "./pages/HomePage";
import MapsPage from "./pages/MapsPage";
import SkillProfilesPage from "./pages/SkillProfilesPage";
import TheseusPage from "./pages/TheseusPage";
import NotFoundPage from "./pages/NotFoundPage";
import NavBar from "./components/Navbar";
import LoginModal from "./components/LoginModal";
import Alert from "./components/Alert";
import TermsModal from "./components/TermsandConditions";
import SwitchAccountModal from "./components/SwitchAccountModal";
import BannerMessage from "./components/BannerMessage";
import {signinHakaUser} from "./services/user";
import { APP_SETTINGS_KEY, AUTHENTICATION_DATA_KEY } from "./constants";

import ScrollUp from "./components/ScrollUp";

const history = createBrowserHistory();


// Temporary banners
// This is hacky way to determine the banner message depending on the server url location
/* === Banner Message components and fucntion ==== */
const prodBannerMessage = () => {
  return (
    <div className="header">
      {/*Please note that this is MVP and under development.*/}
    </div>
  );
};
const devBannerMessage = () => {
  const link = <a href="https://prod-3amk-ai.rahtiapp.fi/">CLICK HERE</a>;
  return (
    <div className="header">
      This is development environment which is constantly updated and used for
      testing. For using 3AMK careerbot, please {link}
    </div>
  );
};
// Disabling prodBannerMessage on the customer
const getBannerMessage = () => {
  if (process.env.NODE_ENV === "production") {
    if (window.location.origin.includes("prod")) {
      return prodBannerMessage;
    } else {
      return devBannerMessage;
    }
  } else {
    return devBannerMessage;
  }
};
/* === END BANNER MESSAGE === */

// Google analytics is not been used during the production
//React.lazy(() => initAnalytics());

/* Start of App */
const App = () => {
  const { t } = useTranslation();
  const dispatch = useDispatch();

  const user = useSelector((state) => state.user);
  const notification = useSelector((state) => state.notification);
  const loginModal = useSelector((state) => state.loginModal);

  // used to keep open state of Terms modal
  const [openTermsModal, setOpenTermsModal] = useState(false);
  // used to keep open state of Switch account modal
  const [openSwitchAccountModal, setOpenSwitchAccountModal] = useState(false);
  // escalation object to be passed to Terms or Switch account modals from Login modal
  const [esclation, setEsclation] = useState(null);

  const BannerMessageChild = getBannerMessage();
  const [showBanner, setShowBanner] = useState(true);

  // check app settings
  useEffect(() => {
    let appSettings = window.localStorage.getItem(APP_SETTINGS_KEY);
    if (appSettings) {
      appSettings = JSON.parse(appSettings);
      if (!appSettings.showBanner) setShowBanner(appSettings.showBanner);
    }
  }, []);

  // check if there is loggedin user and update store
  useEffect(() => {
    if (!user.isAuthorised) {
      const loggedUserJSON = window.localStorage.getItem(
        AUTHENTICATION_DATA_KEY
      );
      if (loggedUserJSON) {
        const user = JSON.parse(loggedUserJSON);
        if (user) {
          dispatch(loginUser(user));
        }
      }
    }
  }, [dispatch, user.isAuthorised]);

  // initialize/load profiles if user is loggedin
  useEffect(() => {
    if (user.isAuthorised) {
      dispatch(initializeProfiles());
    }
  }, [dispatch, user.isAuthorised]);

  useEffect(()=>{
    const hakaLoginEffect = async ()=>{
      const data  = await signinHakaUser({state:"43257425235721643267"});
      if (data) {
        checkAuthDataHaka(data, loginEsclationHandler, updateLogin);
      }
    }
    hakaLoginEffect();

  },[]);

  const checkAuthDataHaka = (data, loginEsclationHandler, updateLogin) => {
    // if new user show terms and conditions
    if (data.message === "TERMS_AND_CONDITION") {
      loginEsclationHandler({
        profile: data.profile,
        type: "SHOW_TERMS",
      });
    } else {
      // if user signed in using other oAuth method prompt to change it
      if (data.message === "CHANGE_AUTH_METHOD") {
        loginEsclationHandler({
          profile: data.profile,
          type: "SWITCH_ACCOUNT",
          newSigninMethod: data.newSigninMethod,
        });
      } else {
        updateLogin({ ...data.profile, token: data.token });
      }
    }
  };

  // update user login after login process esclation is complete
  const updateLogin = (user) => {
    dispatch(loginUser(user));
    dispatch(
      setNotification(
        `${t("notification.login")} ${user.firstName}`,
        3,
        "success"
      )
    );
  };

  const loginEsclationHandler = (newEsclation) => {
    setEsclation(newEsclation);
    if (newEsclation.type === "SHOW_TERMS") {
      setOpenTermsModal(true);
    } else {
      setOpenSwitchAccountModal(true);
    }
  };

  const closeBanner = (e) => {
    e.preventDefault();
    setShowBanner(false);
    let appSettings = window.localStorage.getItem(APP_SETTINGS_KEY);
    if (appSettings) {
      appSettings = JSON.parse(appSettings);
      appSettings.showBanner = false;
      window.localStorage.setItem(
        APP_SETTINGS_KEY,
        JSON.stringify(appSettings)
      );
    } else {
      window.localStorage.setItem(
        APP_SETTINGS_KEY,
        JSON.stringify({ showBanner: false })
      );
    }
  };

  // TODO: optimize notification/Alert, find ways to queue notification instead of set timeout

  return (
    <div>
      {/* Show notification if message is set on store (state), the message will be cleared using setTimeout.  */}
      {notification.message && notification.type === "success" && (
        <Alert messageDescription={notification.message} color="#03991f" />
      )}
      {notification.message && notification.type === "error" && (
        <Alert messageDescription={notification.message} color="#fc3b05" />
      )}
      {notification.message && notification.type === "alert" && (
        <Alert messageDescription={notification.message} color="#fbbd08" />
      )}

      {/* Switch accout modal will be open if Login modal escalte login process with new sign in type. If user login with existig email but different
      oAuth provider, ask user to switch login type. Switch accout modal state is controlled by App component state.
       */}
      <SwitchAccountModal
        modalOpen={openSwitchAccountModal}
        onClose={() => setOpenSwitchAccountModal(false)}
        updateLogin={updateLogin}
        esclation={esclation}
      />
      {/* Terms modal will be open if Login modal escalte login process with new user signup. If user is signing up show terms modal.
      Terms modal state is controlled by App component state.
       */}
      <TermsModal
        modalOpen={openTermsModal}
        onClose={() => setOpenTermsModal(false)}
        esclation={esclation}
        updateLogin={updateLogin}
      />

      {/* Show login modal after a user press login button on any part/page of the app. Login modal will escalte login process to other modals in 2 cases,
      if user is signing up for the first time, or if exstiting user signed in using different oAuth provider than previously. Login modal state is controlled in Redux store.
       */}
      {loginModal.open && (
        <LoginModal
          modalOpen={loginModal.open}
          onClose={() => dispatch(closeLoginModal())}
          loginEsclationHandler={loginEsclationHandler}
          updateLogin={updateLogin}
        />
      )}

      {showBanner && (
        <BannerMessage
          BannerMessageChild={BannerMessageChild}
          onClose={closeBanner}
        />
      )}
      <Router>
        <NavBar user={user}>
          <Switch>
            <Route exact path="/">
              <HomePage />
            </Route>
            <Route path="/jobs">
              <JobsPage />
            </Route>
            <Route path="/courses">
              <CoursesPage />
            </Route>
            <Route path="/maps">
              <MapsPage />
            </Route>
            <Route path="/skills_profile">
              <SkillProfilesPage />
            </Route>
            <Route path="/theseus">
              <TheseusPage />
            </Route>
            <Route component={NotFoundPage} />
          </Switch>
        </NavBar>
      </Router>
      <ScrollUp/>
    </div>
  );
};

export default App;

import React from "react";
import ReactDom from "react-dom";
import { Provider } from "react-redux";
import "./i18n";
import store from "./store";
import App from "./App";

import "react-datepicker/dist/react-datepicker.css";
import "semantic-ui-css/semantic.min.css";
import "./index.css";

import { fetchExampleMaps } from "./reducers/mapReducer";

/*
 * fetch example maps on first load of Homepage for instant experience when navigating to Maps page
 * this might contribute to minor first page load performance reduction
 */
store.dispatch(fetchExampleMaps());

// scroll to top of page on refresh
window.onbeforeunload = function () {
  window.scrollTo(0, 0);
};

ReactDom.render(
  <Provider store={store}>
    <React.Suspense fallback="Loading...">
      <App />
    </React.Suspense>
  </Provider>,
  document.getElementById("root")
);

import { createStore, combineReducers, applyMiddleware } from "redux";
import thunk from "redux-thunk";
import { composeWithDevTools } from "redux-devtools-extension";

import profilesReducer from "./reducers/profilesReducers";
import profileDataReducer from "./reducers/profileDataReducer";
import notificationReducer from "./reducers/notificationReducer";
import jobsReducer from "./reducers/jobsReducer";
import courseSearchReducer from "./reducers/courseSearchReducer";
import userReducer from "./reducers/userReducer";
import mapReducer from "./reducers/mapReducer";
import theseusKeywordsReducer from "./reducers/theseusKeywordsReducer";
import theseusReducer from "./reducers/theseusReducer";
import loginModalReducer from "./reducers/loginModalReducer";
import suggestedSkillsReducer from "./reducers/suggestedSkillsReducer";

const reducer = combineReducers({
  profiles: profilesReducer,
  profileData: profileDataReducer,
  notification: notificationReducer,
  jobs: jobsReducer,
  courseSearch: courseSearchReducer,
  user: userReducer,
  exampleMap: mapReducer,
  theseusKeywords: theseusKeywordsReducer,
  theseus: theseusReducer,
  loginModal: loginModalReducer,
  suggestedSkills: suggestedSkillsReducer,
});

const store = createStore(reducer, composeWithDevTools(applyMiddleware(thunk))); //use composeWithDevTools for redux dev tool

export default store;
